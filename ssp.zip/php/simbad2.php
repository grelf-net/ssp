<?php
try
{
	$id = $_REQUEST ['obj'];
	header("Content-Type: text/xml");

	if (!ereg ('^[A-Za-z0-9_\-\+\. \'\xb0]+$', $id))
	{
		echo '<?xml version="1.0" encoding="utf-8"?><error>Invalid:' . $id . '</error>';
		exit;
	}

	echo file_get_contents ('http://simbad.u-strasbg.fr/simbad/sim-script?script=' . urlencode ("output console=off script=off\nvotable v1 {MAIN_ID,COO}\nvotable open v1\n" . $id . "\nvotable close"));
}
catch (Exception $ex)
{
	echo '<?xml version="1.0" encoding="utf-8"?><error>Exception:' . $ex . '</error>';
}
?>