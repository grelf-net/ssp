<?php
$id = $_REQUEST ['obj'];

if (!ereg ('^[A-Za-z0-9_\-\+\. \'\xb0]+$', $id))
{
  echo 'Invalid id';
  exit;
}

$script = "votable v1 {MAIN_ID,COO}\nvotable open v1\n" . $id . "\nvotable close";
header("Content-Type: text/xml");
echo file_get_contents('http://simbad.u-strasbg.fr/simbad/sim-script?script=' . urlencode($script));
?>