'use strict';

function Moon()
{ this.name = "Moon";
  this.symbol = '';
  this.kind = 'M';
  this.colour = '#fff';
}
  
// Moon position using Chapront's theory as given in Meeus Astronomical Algorithms p337
Moon.prototype.at = function(jd)
{ var T = (jd - JD2000) / 36525.0; // centuries
  var T2 = T * T;
  var T3 = T2 * T;
  var T4 = T3 * T;
  var LdashDegs = in360(218.3164477 +
                        481267.88123421 * T -
                        0.0015786 * T2 +
                        T3 / 538841.0 -
                        T4 / 65194000.0);
  var DDegs = in360(297.8501921 +
                    445267.1114034 * T -
                    0.0018819 * T2 +
                    T3 / 545868.0 -
                    T4 / 113065000.0);
  var MDegs = in360(357.5291092 +
                    35999.0502909 * T -
                    0.0001536 * T2 +
                    T3 / 24490000.0);
  var MdashDegs = in360(134.9633964 +
                        477198.8675055 * T +
                        0.0087414 * T2 +
                        T3 / 69699.0 -
                        T4 / 14712000.0);
  var FDegs = in360(93.2720950 +
                    483202.0175233 * T -
                    0.0036539 * T2 -
                    T3 / 3526000.0 +
                    T4 / 863310000.0);
  var A1Degs = in360(119.75 + 131.849 * T);
  var A2Degs = in360(53.09 + 479264.290 * T);
  var A3Degs = in360(313.45 + 481266.484 * T);
  var E = 1.0 - 0.002516 * T - 0.0000074 * T2;
  var E2 = E * E;
  var sigma_l = 0.0;
  var sigma_r = 0.0;
  var sigma_b = 0.0;
  var table47aLength = TABLE47A.length;
  if (table47aLength % 6 !== 0)
  { alert("table47a has wrong number of elements: " + table47aLength);
  }
  for (var i = 0; i < table47aLength; i += 6)
  {
    var nD = TABLE47A[i];
    var nM = TABLE47A[i + 1];
    var nMdash = TABLE47A[i + 2];
    var nF = TABLE47A[i + 3];
    var arg = nD * DDegs + nM * MDegs + nMdash * MdashDegs + nF * FDegs;
    if (1 === nM || -1 === nM)
    { sigma_l += TABLE47A[i + 4] * E * sinDegs(arg);
      sigma_r += TABLE47A[i + 5] * E * cosDegs(arg);
    }
    else
    if (2 === nM || -2 === nM)
    { sigma_l += TABLE47A[i + 4] * E2 * sinDegs(arg);
      sigma_r += TABLE47A[i + 5] * E2 * cosDegs(arg);
    }
    else
    { sigma_l += TABLE47A[i + 4] * sinDegs(arg);
      sigma_r += TABLE47A[i + 5] * cosDegs(arg);
    }
  }
  var table47bLength = TABLE47B.length;
  if (table47bLength % 5 !== 0)
  { alert("table47b has wrong number of elements: " + table47bLength);
  }
  for (var i = 0; i < table47bLength; i += 5)
  { var nD = TABLE47B[i];
    var nM = TABLE47B[i + 1];
    var nMdash = TABLE47B[i + 2];
    var nF = TABLE47B[i + 3];
    var arg = nD * DDegs + nM * MDegs + nMdash * MdashDegs + nF * FDegs;
    if (1 === nM || -1 === nM)
    { sigma_b += TABLE47B[i + 4] * E * sinDegs(arg);
    }
    else
    if (2 === nM || -2 === nM)
    { sigma_b += TABLE47B[i + 4] * E2 * sinDegs(arg);
    }
    else
    { sigma_b += TABLE47B[i + 4] * sinDegs(arg);
    }
  }
  sigma_l += 3958.0 * sinDegs (A1Degs) +
             1962.0 * sinDegs (LdashDegs - FDegs) +
             318.0 * sinDegs (A2Degs);
  sigma_b += 382.0 * sinDegs (A3Degs) -
              2235.0 * sinDegs (LdashDegs) +
              175.0 * sinDegs (A1Degs - FDegs) +
              175.0 * sinDegs (A1Degs + FDegs) +
              127.0 * sinDegs (LdashDegs - MdashDegs) -
              115.0 * sinDegs (LdashDegs + MdashDegs);
  this.lambdaDegs = LdashDegs + sigma_l / 1.0e6;
  this.betaDegs = sigma_b / 1.0e6;
  this.deltaKm = 385000.56 + sigma_r / 1.0e3;
  var sinLambda = sinDegs (this.lambdaDegs);
  var cosLambda = cosDegs (this.lambdaDegs);
  var sinBeta = sinDegs (this.betaDegs);
  var cosBeta = cosDegs (this.betaDegs);
  // Obliquity of the ecliptic:
  var epsilonDegs = 23.0 + 26.0 / 60.0 +
         (21.448 - 46.8150 * T - 0.00059 * T2 + 0.001813 * T3) / 3600.0;
  var sinEpsilon = sinDegs (epsilonDegs);
  var cosEpsilon = cosDegs (epsilonDegs);
  var raDegs = in360 (
      atan2Degs(sinLambda * cosEpsilon - sinBeta * sinEpsilon / cosBeta, cosLambda));
  this.raHrs = raDegs / 15.0;
  this.decDegs = asinDegs(sinBeta * cosEpsilon + cosBeta * sinEpsilon * sinLambda);
  var iDegs = 180.0 - DDegs - 6.289 * sinDegs(MdashDegs) +
                            2.100 * sinDegs(MDegs) -
                            1.274 * sinDegs(2.0 * DDegs - MdashDegs) -
                            0.658 * sinDegs(2.0 * DDegs) -
                            0.214 * sinDegs(2.0 * MdashDegs) -
                            0.110 * sinDegs(DDegs);
  this.phaseDegs = iDegs;
  this.illumFrac = 0.5 * (1.0 + cosDegs(iDegs));
  if (GD.topocentric)
  { var adj = topoAdjust(jd, this.raHrs, this.decDegs, this.deltaKm * KM_TO_AU);
    this.raHrs = adj.raHrs;
    this.decDegs = adj.decDegs;
  }
};

/** Get a comma-separated string comprising RA hours, Dec degrees, phase degrees,
* illumination fraction, geocentric longitude degrees, geocentric latitude degrees,
* geocentric distance km. */
Moon.prototype.getData = function()
{ return this.raHours + ',' .
         this.decDegs + ',' .
         this.phaseAngleDegs + ',' .
         this.illuminatedFraction + ',' .
         this.lambdaDegs + ',' .
         this.betaDegs + ',' .
         this.deltaKm + ',';
}; // getData

const TABLE47A = 
[
  0.0, 0.0, 1.0, 0.0, 6288774.0, -20905355.0,
  2.0, 0.0, -1.0, 0.0, 1274027.0, -3699111.0,
  2.0, 0.0, 0.0, 0.0, 658314.0, -2955968.0,
  0.0, 0.0, 2.0, 0.0, 213618.0, -569925.0,
  0.0, 1.0, 0.0, 0.0, -185116.0, 48888.0,
  0.0, 0.0, 0.0, 2.0, -114332.0, -3149.0,
  2.0, 0.0, -2.0, 0.0, 58793.0, 246158.0,
  2.0, -1.0, -1.0, 0.0, 57066.0, -152138.0,
  2.0, 0.0, 1.0, 0.0, 53322.0, -170733.0,
  2.0, -1.0, 0.0, 0.0, 45758.0, -204586.0,
  0.0, 1.0, -1.0, 0.0, -40923.0, -129620.0,
  1.0, 0.0, 0.0, 0.0, -34720.0, 108743.0,
  0.0, 1.0, 1.0, 0.0, -30383.0, 104755.0,
  2.0, 0.0, 0.0, -2.0, 15327.0, 10321.0,
  0.0, 0.0, 1.0, 2.0, -12528.0, 0.0,
  0.0, 0.0, 1.0, -2.0, 10980.0, 79661.0,
  4.0, 0.0, -1.0, 0.0, 10675.0, -34782.0,
  0.0, 0.0, 3.0, 0.0, 10034.0, -23210.0,
  4.0, 0.0, -2.0, 0.0, 8548.0, -21636.0,
  2.0, 1.0, -1.0, 0.0, -7888.0, 24208.0,
  2.0, 1.0, 0.0, 0.0, -6766.0, 30824.0,
  1.0, 0.0, -1.0, 0.0, -5163.0, -8379.0,
  1.0, 1.0, 0.0, 0.0, 4987.0, -16675.0,
  2.0, -1.0, 1.0, 0.0, 4036.0, -12831.0,
  2.0, 0.0, 2.0, 0.0, 3994.0, -10445.0,
  4.0, 0.0, 0.0, 0.0, 3861.0, -11650.0,
  2.0, 0.0, -3.0, 0.0, 3665.0, 14403.0,
  0.0, 1.0, -2.0, 0.0, -2689.0, -7003.0,
  2.0, 0.0, -1.0, 2.0, -2602.0, 0.0,
  2.0, -1.0, -2.0, 0.0, 2390.0, 10056.0,
  1.0, 0.0, 1.0, 0.0, -2348.0, 6322.0,
  2.0, -2.0, 0.0, 0.0, 2236.0, -9884.0,
  0.0, 1.0, 2.0, 0.0, -2120.0, 5751.0,
  0.0, 2.0, 0.0, 0.0, -2069.0, 0.0,
  2.0, -2.0, -1.0, 0.0, 2048.0, -4950.0,
  2.0, 0.0, 1.0, -2.0, -1773.0, 4130.0,
  2.0, 0.0, 0.0, 2.0, -1595.0, 0.0,
  4.0, -1.0, -1.0, 0.0, 1215.0, -3958.0,
  0.0, 0.0, 2.0, 2.0, -1110.0, 0.0,
  3.0, 0.0, -1.0, 0.0, -892.0, 3258.0,
  2.0, 1.0, 1.0, 0.0, -810.0, 2616.0,
  4.0, -1.0, -2.0, 0.0, 759.0, -1897.0,
  0.0, 2.0, -1.0, 0.0, -713.0, -2117.0,
  2.0, 2.0, -1.0, 0.0, -700.0, 2354.0,
  2.0, 1.0, -2.0, 0.0, 691.0, 0.0,
  2.0, -1.0, 0.0, -2.0, 596.0, 0.0,
  4.0, 0.0, 1.0, 0.0, 549.0, -1423.0,
  0.0, 0.0, 4.0, 0.0, 537.0, -1117.0,
  4.0, -1.0, 0.0, 0.0, 520.0, -1571.0,
  1.0, 0.0, -2.0, 0.0, -487.0, -1739.0,
  2.0, 1.0, 0.0, -2.0, -399.0, 0.0,
  0.0, 0.0, 2.0, -2.0, -381.0, -4421.0,
  1.0, 1.0, 1.0, 0.0, 351.0, 0.0,
  3.0, 0.0, -2.0, 0.0, -340.0, 0.0,
  4.0, 0.0, -3.0, 0.0, 330.0, 0.0,
  2.0, -1.0, 2.0, 0.0, 327.0, 0.0,
  0.0, 2.0, 1.0, 0.0, -323.0, 1165.0,
  1.0, 1.0, -1.0, 0.0, 299.0, 0.0,
  2.0, 0.0, 3.0, 0.0, 294.0, 0.0,
  2.0, 0.0, -1.0, -2.0, 0.0, 8752
]; // $table47a

const TABLE47B = 
[
0.0, 0.0, 0.0, 1.0, 5128122.0,
0.0, 0.0, 1.0, 1.0, 280602.0,
0.0, 0.0, 1.0, -1.0, 277693.0,
2.0, 0.0, 0.0, -1.0, 173237.0,
2.0, 0.0, -1.0, 1.0, 55413.0,
2.0, 0.0, -1.0, -1.0, 46271.0,
2.0, 0.0, 0.0, 1.0, 32573.0,
0.0, 0.0, 2.0, 1.0, 17198.0,
2.0, 0.0, 1.0, -1.0, 9266.0,
0.0, 0.0, 2.0, -1.0, 8822.0,
2.0, -1.0, 0.0, -1.0, 8216.0,
2.0, 0.0, -2.0, -1.0, 4324.0,
2.0, 0.0, 1.0, 1.0, 4200.0,
2.0, 1.0, 0.0, -1.0, -3359.0,
2.0, -1.0, -1.0, 1.0, 2463.0,
2.0, -1.0, 0.0, 1.0, 2211.0,
2.0, -1.0, -1.0, -1.0, 2065.0,
0.0, 1.0, -1.0, -1.0, -1870.0,
4.0, 0.0, -1.0, -1.0, 1828.0,
0.0, 1.0, 0.0, 1.0, -1794.0,
0.0, 0.0, 0.0, 3.0, -1749.0,
0.0, 1.0, -1.0, 1.0, -1565.0,
1.0, 0.0, 0.0, 1.0, -1491.0,
0.0, 1.0, 1.0, 1.0, -1475.0,
0.0, 1.0, 1.0, -1.0, -1410.0,
0.0, 1.0, 0.0, -1.0, -1344.0,
1.0, 0.0, 0.0, -1.0, -1335.0,
0.0, 0.0, 3.0, 1.0, 1107.0,
4.0, 0.0, 0.0, -1.0, 1021.0,
4.0, 0.0, -1.0, 1.0, 833.0,
0.0, 0.0, 1.0, -3.0, 777.0,
4.0, 0.0, -2.0, 1.0, 671.0,
2.0, 0.0, 0.0, -3.0, 607.0,
2.0, 0.0, 2.0, -1.0, 596.0,
2.0, -1.0, 1.0, -1.0, 491.0,
2.0, 0.0, -2.0, 1.0, -451.0,
0.0, 0.0, 3.0, -1.0, 439.0,
2.0, 0.0, 2.0, 1.0, 422.0,
2.0, 0.0, -3.0, -1.0, 421.0,
2.0, 1.0, -1.0, 1.0, -366.0,
2.0, 1.0, 0.0, 1.0, -351.0,
4.0, 0.0, 0.0, 1.0, 331.0,
2.0, -1.0, 1.0, 1.0, 315.0,
2.0, -2.0, 0.0, -1.0, 302.0,
0.0, 0.0, 1.0, 3.0, -283.0,
2.0, 1.0, 1.0, -1.0, -229.0,
1.0, 1.0, 0.0, -1.0, 223.0,
1.0, 1.0, 0.0, 1.0, 223.0,
0.0, 1.0, -2.0, -1.0, -220.0,
2.0, 1.0, -1.0, -1.0, -220.0,
1.0, 0.0, 1.0, 1.0, -185.0,
2.0, -1.0, -2.0, -1.0, 181.0,
0.0, 1.0, 2.0, 1.0, -177.0,
4.0, 0.0, -2.0, -1.0, 176.0,
4.0, -1.0, -1.0, -1.0, 166.0,
1.0, 0.0, 1.0, -1.0, -164.0,
4.0, 0.0, 1.0, -1.0, 132.0,
1.0, 0.0, -1.0, -1.0, -119.0,
4.0, -1.0, 0.0, -1.0, 115.0,
2.0, -2.0, 0.0, 1.0, 107.0
]; // $table47b
