// graphics.js by Graham Relf 2013 Jun 25
'use strict';

function drawLine (g2, x0, y0, x1, y1, style)
{ g2.strokeStyle = style;
  g2.beginPath ();
  g2.moveTo (x0, y0);
  g2.lineTo (x1, y1);
  g2.closePath ();
  g2.stroke ();
}

function drawCross(g2, x0, y0, r, style)
{ drawLine(g2, x0 - r, y0, x0 + r, y0, style);
  drawLine(g2, x0, y0 - r, x0, y0 + r, style);
}

function fillArc (g2, xCentre, yCentre, radius, startRad, endRad, anticlock, style)
{ if (radius > 0)
  { g2.fillStyle = style;
    g2.beginPath ();
    g2.arc (xCentre, yCentre, radius, startRad, endRad, anticlock);
    g2.closePath ();
    g2.fill();
  }
  else error('Arc radius=' + radius);
}

function fillCircle (g2, xCentre, yCentre, radius, style)
{ if (radius > 0)
  { g2.fillStyle = style;
    g2.beginPath ();
    g2.arc (xCentre, yCentre, radius, 0, TWO_PI, false);
    g2.closePath ();
    g2.fill();
  }
  else error('Circle radius=' + radius);
}

function fillEllipse (g2, xCentre, yCentre, rx, ry, style)
{ g2.fillStyle = style;
  g2.save ();
  g2.translate (-xCentre, -yCentre);
  var scale = ry / rx;
  g2.scale (1, scale);
  g2.beginPath ();
  g2.arc (0, 0, rx, 0, TWO_PI, false);
  g2.closePath ();
  g2.translate (xCentre, yCentre);
  g2.restore ();
  g2.fill ();
}

function strokeCircle (g2, xCentre, yCentre, radius, style)
{ g2.strokeStyle = style;
  g2.beginPath ();
  g2.arc (xCentre, yCentre, radius, 0, TWO_PI, false);
  g2.closePath ();
  g2.stroke();
}
