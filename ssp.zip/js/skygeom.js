'use strict';

function degs2hours(degs) { return degs / 15.0; }
function hours2degs(hours) { return hours * 15.0; }

function RA(hours) { this.hours = hours; }
function Dec(degs) { this.degs = degs; }
function Epoch(year) { this.year = year; }

function SkyPoint(ra, dec, epoch)
{ this.ra = ra;
  this.dec = dec;
  this.epoch = epoch;
}

RA.prototype.getHour = function()
{ return Math.floor(this.hours);
};

RA.prototype.getMinute = function()
{ var wholeMins = Math.floor(this.hours * 60);
  return wholeMins % 60;
};

RA.prototype.getSecond = function()
{ var totalMins = this.hours * 60;
  var minFrac = totalMins - Math.floor(totalMins);
  return minFrac * 60;
};

RA.prototype.toString = function()
{ return form02(this.getHour(), 0) + 'h' +
         form02(this.getMinute(), 0) + 'm' +
         form02(this.getSecond(), 2) + 's';
};

RA.prototype.toHTMLString = function()
{ return form02(this.getHour(), 0) + sup('h') +
         form02(this.getMinute(), 0) + sup('m') +
         form02(this.getSecond(), 2) + sup('s');
};

Dec.prototype.getSign = function()
{ return this.degs >= 0 ? '+' : '-';
};

/** 0..90 */
Dec.prototype.getDegree = function()
{ return Math.floor(Math.abs(this.degs));
};

Dec.prototype.getMinute = function()
{ var wholeMins = Math.floor(Math.abs(this.degs) * 60);
  return wholeMins % 60;
};

Dec.prototype.getSecond = function()
{ var totalMins = Math.abs(this.degs) * 60;
  var minFrac = totalMins - Math.floor(totalMins);
  return minFrac * 60;
};

Dec.prototype.toHTMLString = function()
{ return this.getSign() +
    form02(this.getDegree(), 0) + '&deg;' +
    form02(this.getMinute(), 0) + '&#39;' +
    form02(this.getSecond(), 1) + '&quot;';
};

Dec.prototype.toString = function()
{ return this.getSign() +
    form02(this.getDegree(), 0) + '\u00b0' +
    form02(this.getMinute(), 0) + "'" +
    form02(this.getSecond(), 1) + '"';
};

function form02(n, f)
{ if (n < 10) return '0' + n.toFixed(f);
  return n.toFixed(f);
}

function sup(s) { return '<sup>' + s + '</sup>'; }

Epoch.prototype.toString = function()
{ return 'J' + this.year.toFixed(1);
}; // Epoch.toString

Epoch.prototype.getJulianDate = function()
{ var years = this.year - 2000.0;
  return 2451545.0 + years * 365.25;
}; // Epoch.getJulianDate

SkyPoint.prototype.toString = function()
{
  return 'RA ' + this.ra.toString() +
         ' Dec ' + this.dec.toString() +
         '(' + this.epoch.toString() + ')';
}; // SkyPoint.toString

/** Returns 3D array of rectangular coordinates, assuming a unit sphere. */
SkyPoint.prototype.getXYZ = function()
{ var raDegs = hours2degs(this.ra.hours);
  var decDegs = this.dec.degs;
  var cosDec = cosDegs(decDegs);
  return [ cosDegs(raDegs) * cosDec,
    sinDegs(raDegs) * cosDec,
    sinDegs(decDegs) ];
} // getXYZ

/** This adjusts the fields of the current object to the given new epoch,
  * low accuracy version.
  * Uses the approximate formulae:<br>
  * Annual precession in RA = 3.0730 + 1.3362.sin(RA).tan(Dec) seconds of time<br>
  * Annual precession in Dec = 20.043.cos(RA) seconds of arc. */
SkyPoint.prototype.changeEpochLowAccuracy = function(newEpoch)
{ var dY = newEpoch.year - this.epoch.year;
  if (0.0001 > Math.abs(dY)) return;
  var raHours = this.ra.hours;
  var decDegs = this.dec.degs;
  var Tcenturies = (this.epoch.year - 2000.0) / 100.0;
  var dRaSecs = dY * (3.07496 + 0.00186 * Tcenturies +  
    (1.3362 - 0.00057 * Tcenturies) * sinDegs(raDegs) * tanDegs(decDegs));
  var newRA = new RA(raHours + dRaSecs / 3600.0);
  var dDecSecs = dY * (20.0431 - 0.0085 * Tcenturies) * cosDegs(raDegs);
  var newDec = new Dec(decDegs + dDecSecs / 3600.0);
  this.ra = newRA;
  this.dec = newDec;
  this.epoch = newEpoch;
}; // SkyPoint.changeEpochLowAccuracy

/** This adjusts the fields of the current object to the given new epoch,
  * high accuracy version.
  * Uses the method given in Astronomical Algorithms by Jean Meeus (2nd edition,
  *  corrected Aug 09),
  * Chapter 21 (Precession), the section headed "Rigorous method". */
SkyPoint.prototype.changeEpoch = function(newEpoch)
{ var jd0 = this.epoch.getJulianDate();
  var jd = newEpoch.getJulianDate();
  var _T = (jd0 - 2451545.0) / 36525.0;
  var t = (jd - jd0) / 36525.0;
  var _T2 = _T * _T;
  var t2 = t * t;
  var t3 = t2 * t;
  var zetaDegs = ((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
               (0.30188 - 0.000344 * _T) * t2 + 0.017998 * t3) / 3600.0;
  var zDegs = ((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
            (1.09468 + 0.000066 * _T) * t2 + 0.018203 * t3) / 3600.0;
  var thetaDegs = ((2004.3109 - 0.85330 * _T - 0.000217 * _T2) * t -
                (0.42665 + 0.000217 * _T) * t2 - 0.041833 * t3) / 3600.0;
  var ra0Degs = hours2degs(this.ra.hours);
  var dec0Degs = this.dec.degs;
  var cosDec0 = cosDegs(dec0Degs);
  var sinDec0 = sinDegs(dec0Degs);
  var ra0zetaDegs = in360(ra0Degs + zetaDegs);
  var cosDaz = cosDec0 * cosDegs(ra0zetaDegs);
  var cosTheta = cosDegs(thetaDegs);
  var sinTheta = sinDegs(thetaDegs);
  var _A = cosDec0 * sinDegs(ra0zetaDegs);
  var _B = cosTheta * cosDaz - sinTheta * sinDec0;
  var _C = sinTheta * cosDaz + cosTheta * sinDec0;
  var raDegs = zDegs + atan2Degs (_A, _B);
  var decDegs = 0.0;
  if (dec0Degs > -85.0 && dec0Degs < 85.0)
  {
    decDegs = asinDegs(_C);
  }
  else // Near a pole:
  {
    decDegs = acosDegs(Math.sqrt(_A * _A + _B * _B));
  }
  this.ra = new RA(degs2hours(in360(raDegs)));
  this.dec = new Dec(decDegs);
  this.epoch = newEpoch;
}; // SkyPoint.changeEpoch

/** Returns an array of 3 fractions of a day, representing respectively the
  * local times of rising, transit and setting for the given object altitude
  * (h0) and latitude. Uses the method in J.Meeus "Astronomical Algorithms"
  * (2nd Edn), Chapter 15.
  * The JD for which these are required is NOT assumed to be for 0h UT -
  * any JD is adjusted as necessary.
  * The rising and setting times are set to -1.0 if the point is circumpolar
  * at the given latitude.
  * This version of the method is really intended for finding twilight times,
  * where h0 is set to -6, -12 or -18 for civil, nautical or astronomical
  * twilight. */
SkyPoint.prototype.calculateRiseTransitSet = function(jd, h0Degs, longitudeDegs, latitudeDegs)
{ var jd0 = Math.round(jd) - 0.5; // 0.5 converts to 0h UT
  var T = (jd - 2451545.0) / 36525;
  var T2 = T * T;
  var T3 = T * T2;
  var theta0Degs = in360 (
         280.46061837 +
         360.98564736629 * (jd0 - 2451545.0) +
         0.000387933 * T2 - T3 / 38710000.0);
  var deltaDegs = this.dec.degs;
  var sinPhiSinDelta = sinDegs(latitudeDegs) * sinDegs(deltaDegs);
  var cosPhiCosDelta = cosDegs(latitudeDegs) * cosDegs(deltaDegs);
  var cosH0 = (sinDegs(h0Degs) - sinPhiSinDelta) / cosPhiCosDelta;
  var m0 = (hours2degs(this.ra.hours) - theta0Degs) / 360.0;
  var m1, m2;

  if (cosH0 < -1.0 || cosH0 > 1.0)
  {
    m1 = m2 = -1.0;
  }
  else
  {
    H0360 = acosDegs(cosH0) / 360.0;
    m1 = in01(m0 - H0360);
    m2 = in01(m0 + H0360);
  }

  var dayFractions = [m1, in01(m0), m2];
  return dayFractions;
}; // SkyPoint.calculateRiseTransitSet

function in01(x)
{
  if (x > 1.0) return x - 1.0;
  if (x < 0.0) return x + 1.0;
  return x;
} // in01

SkyPoint.prototype.calculateSeparation = function(other)
{ var dRaDegs = hours2degs(this.ra.hours - other.ra.hours);
  var thisDecDegs = this.dec.degs;
  var otherDecDegs = other.dec.degs;
  var cosD1 = cosDegs(otherDecDegs);
  var cosD2 = cosDegs(thisDecDegs);
  var cosDa = cosDegs(dRaDegs);
  var sinD1 = sinDegs(otherDecDegs);
  var sinD2 = sinDegs(thisDecDegs);
  var sinDa = sinDegs(dRaDegs);
  var xx = cosD1 * sinD2 - sinD1 * cosD2 * cosDa;
  var yy = cosD2 * sinDa;
  var zz = sinD1 * sinD2 + cosD1 * cosD2 * cosDa;
  var sepnDegs = atan2Degs(Math.sqrt (xx * xx + yy * yy), zz);
  return sepnDegs;
}; // SkyPoint.calculateSeparation

