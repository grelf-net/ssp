// charts.js by Graham Relf, revised 2025 May - July
// Star charts and comet plots for use by ecliptic.js
'use strict';

let DEC00, DEC01, DEC02, DEC03, DEC04, DEC05, DEC06, DEC07, DEC08,
    DEC09, DEC10, DEC11, DEC12, DEC13, DEC14, DEC15, DEC16, DEC17,
    DEC18, DEC19, DEC20, DEC21, DEC22, DEC23, DEC24, DEC25, DEC26,
    DEC27, DEC28, DEC29, DEC30, DEC31, DEC32, DEC33, DEC34, DEC35;
let decLoaded = new Array(36);

function degsToIdx(decDegs)
{ return Math.floor((decDegs + 90) / 5); }

function loadDecScript(idx)//index to the file
{ var fname = "data/dec";
  if (idx < 10) fname += "0";
  fname += idx + ".js";
  var tag = document.createElement('script');
  tag.type = "text/javascript";
  tag.onerror = function() { alert("Could not load " + tag.src); };
  tag.onload = tag.onreadystatechange = function() 
  { decLoaded[idx] = true; 
  };
  tag.src = fname;
  document.body.appendChild(tag);
}

function plotRDT(objName)//comet plot
{ for (var i = 0; i < objects.length; i++)
  { if (objects[i].name === objName)
    { if (objects[i].kind !== 'C' && objects[i].kind !== 'A') return;//B7: A
      var obj = objects[i];
      GD.plot = new Plot(obj);
  } }
  var jd = GD.cal.getJD();//B7
  GD.elChart.innerHTML =
    '<select id="midJD" style="float:right" onchange="setMidDate()">' + 
    '<option value="tau">Around perihelion</option>' +//B7
    '<option value="cal">Around ' + jdToDate(jd) + '</option></select>' + //B7
    '<canvas id="rdtplot" width="' + GD.plot.wd + '" height="' + GD.plot.ht +
    '" style="border:0"/>';
  GD.plot.show(0);//B7: 0
  location.assign('#chart');
}

function setMidDate()
{ GD.plot.rdt = [];
  GD.plot.show(document.getElementById("midJD").selectedIndex);
}

function Plot(obj)//For RDT plots
{ this.obj = obj;
  this.wd = 750; // px
  this.ht = 750;
  this.xL = 100; this.xR = 700;
  this.yT = 100; this.yB = 700;// Square plot
  this.maxR = Math.floor(obj.qAU) + 2.5;
  this.scale = (this.xR - this.xL) / this.maxR;
  this.rdt = [];
}

Plot.prototype.show = function(idx)//B7: idx
{ var cnv = document.getElementById("rdtplot");
  var g2 = cnv.getContext("2d");
  g2.font = 'bold 14px monospace';// sans-serif';
  g2.fillStyle = '#fff';
  g2.fillRect(0, 0, this.wd, this.ht);
  g2.strokeStyle = '#000';
  g2.beginPath();
  g2.moveTo(this.xL, this.yT);
  g2.lineTo(this.xL, this.yB);
  g2.lineTo(this.xR, this.yB);
  g2.stroke();
  this.calcCurves(idx === 0 ? this.obj.tauJD : GD.cal.getJD());//B7
  var n = this.rdt.length;
  if (n < 3)
  { error("Sorry, plot is not possible, distance too large?");
    return;
  }
  var mv, mvs = []; 
  this.mvMin = 100;
  this.mvMax = -100;
  for (var i = 0; i < n; i++)
  { if (this.obj.kind === 'A')//B7:
      mv = this.obj.h + 5 * log10(this.rdt[i].d) + this.obj.g * log10(this.rdt[i].r)
    else mv = 5 * log10(this.rdt[i].r * this.rdt[i].d);//:B7
    mvs.push(mv);
    if (mv < this.mvMin) this.mvMin = mv;
    if (mv > this.mvMax) this.mvMax = mv;
  }
  g2.fillStyle = '#000';
  var tx;
  if (this.obj.kind === 'A') tx = this.obj.symbol + ' ' + this.obj.name;//B7:
  else tx = this.obj.name;
  g2.fillText(tx, this.xL, 40);//:B7
  for (i = 0; i < n; i += n / 10)
  { var jd = this.rdt[Math.floor(i)].t;
    var y = this.jdToY(jd);
    g2.fillText(jdToDate(jd), 20, y);
    drawLine(g2, this.xL, y, this.xR, y, '#ccc');
  }
  var odd = false;
  for (i = 0; i < this.maxR; i += 0.25, odd = !odd)
  { var x = this.auToX(i);
    drawLine(g2, x, this.yT, x, this.yB, '#ccc');
    if (!odd) g2.fillText(i.toFixed(2), x - 20, this.yB + 20);//only every 0.5
  }
  g2.fillText("AU", this.xR + 20, this.yB + 20);
  g2.fillStyle = '#0aa';
  g2.fillText("brighter", this.xL, this.yB + 40);
  g2.fillText("fainter", this.xR - 50, this.yB + 40);
  g2.fillStyle = '#000';
  drawLine(g2, this.xL, this.yT - 20, this.xL + 50, this.yT - 20, '#fa0');
  g2.fillText("r (from Sun) AU", this.xL + 55, this.yT - 20);
  drawLine(g2, this.xL + 200, this.yT - 20, this.xL + 250, this.yT - 20, '#4f4');
  g2.fillText("\u0394 (from Earth) AU", this.xL + 255, this.yT - 20);
  drawLine(g2, this.xL + 420, this.yT - 20, this.xL + 470, this.yT - 20, '#0aa');
  var tx = "H + 5.log(\u0394) + G.log(r)";//B7: A
  if (this.obj.kind === 'C') tx = "log(r.\u0394)";
  g2.fillText(tx, this.xL + 475, this.yT - 20);
  g2.strokeStyle = "#fa0";
  g2.beginPath();
  g2.moveTo(this.auToX(this.rdt[0].r), this.jdToY(this.rdt[0].t));
  for (i = 1; i < n; i++)
  { g2.lineTo(this.auToX(this.rdt[i].r), this.jdToY(this.rdt[i].t));
  }
  g2.stroke();
  g2.strokeStyle = "#4f4";
  g2.beginPath();
  g2.moveTo(this.auToX(this.rdt[0].d), this.jdToY(this.rdt[0].t));
  for (i = 1; i < n; i++)
  { g2.lineTo(this.auToX(this.rdt[i].d), this.jdToY(this.rdt[i].t));
  }
  g2.stroke();
  g2.strokeStyle = "#0aa";
  g2.beginPath();
  g2.moveTo(this.mvToX(mvs[0]), this.jdToY(this.rdt[0].t));
  for (i = 1; i < n; i++)
  { g2.lineTo(this.mvToX(mvs[i]), this.jdToY(this.rdt[i].t));
  }
  g2.stroke();
};

Plot.prototype.auToX = function(au)
{ return this.xL + au * this.scale; 
};

Plot.prototype.mvToX = function(mv)
{ return this.xL + (mv - this.mvMin) * (this.xR - this.xL) / (this.mvMax - this.mvMin);
};

Plot.prototype.jdToY = function(jd)
{ return this.yT + (jd - this.jdMin) * (this.yB - this.yT) / (this.jdMax - this.jdMin);  
};

Plot.prototype.calcCurves = function(tauJD)
{ var jd = tauJD;
  do
  { jd--;
    this.calcRandDelta(jd);
    this.jdMin = jd;
  }
  while (this.obj.rAU < this.maxR && Math.abs(jd - tauJD) < 365);
  do
  { this.rdt.push({r:this.obj.rAU, d:this.obj.deltaAU, t:jd});
    jd++;
    this.calcRandDelta(jd);
    this.jdMax = jd;
  }
  while (this.obj.rAU < this.maxR && Math.abs(jd - tauJD) < 365);
};

Plot.prototype.calcRandDelta = function(jd)
{ var earth2000 = new EarthJ2000(jd);
  var xyz = earth2000.getHeliocentricCoordinates();
  var sunDxJ2000 = -xyz[0];
  var sunDyJ2000 = -xyz[1];
  var sunDzJ2000 = -xyz[2];
  var sunX = sunDxJ2000
            + 0.000000440360 * sunDyJ2000
            - 0.000000190919 * sunDzJ2000;
  var sunY = -0.000000479966 * sunDxJ2000
            + 0.917482137087 * sunDyJ2000
            - 0.397776982902 * sunDzJ2000;
  var sunZ =  0.397776982902 * sunDyJ2000
            + 0.917482137087 * sunDzJ2000;
  var xyz = this.obj.getHeliocentricPositionAU(jd); // sets rAU
  if (null !== xyz)
  { var dx = xyz.x + sunX;
    var dy = xyz.y + sunY;
    var dz = xyz.z + sunZ;
    this.obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var dLight = 0.0057755183 * this.obj.deltaAU; // days
    xyz = this.obj.getHeliocentricPositionAU (jd - dLight); // sets rAU
    this.obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
  else error("Could not compute deltaAU");
};

function showChart(objName)//finder chart
{ var done = false;
  var halfWd = 2.5;//degrees
  for (var i = 0; i < objects.length && !done; i++)
  { if (objects[i].name === objName)
    { GD.chart = new Chart(objects[i], halfWd);
      var raHrs = objects[i].raHrs;
      var decDegs = objects[i].decDegs;
      var dRa = halfWd / (12 * cosDegs(decDegs));
      GD.raMin = (raHrs - dRa) % 24;
      if (GD.raMin < 0) GD.raMin += 24;
      GD.raMax = (raHrs + dRa) % 24;
      if (GD.raMax < 0) GD.raMax += 24;
      // The chart fits within 1 or 2 consecutive Dec bands:
      GD.decMin = decDegs - halfWd;
      GD.decMax = decDegs + halfWd;
      GD.idx1 = degsToIdx(GD.decMin);
      GD.idx2 = degsToIdx(GD.decMax);
      loadDecScript(GD.idx1);
      if (GD.idx1 !== GD.idx2)
      { loadDecScript(GD.idx2);
      }
      done = true;
      awaitScripts();
} } }

function awaitScripts()
{ if (!decLoaded[GD.idx1] || !decLoaded[GD.idx2])
  { setTimeout(awaitScripts, 100);
    return;
  }
  showChartB();
}

function findStars(idx)
{ var decData;
  switch (idx)
  {
case 0: decData = DEC00; break;
case 1: decData = DEC01; break;
case 2: decData = DEC02; break;
case 3: decData = DEC03; break;
case 4: decData = DEC04; break;
case 5: decData = DEC05; break;
case 6: decData = DEC06; break;
case 7: decData = DEC07; break;
case 8: decData = DEC08; break;
case 9: decData = DEC09; break;
case 10: decData = DEC10; break;
case 11: decData = DEC11; break;
case 12: decData = DEC12; break;
case 13: decData = DEC13; break;
case 14: decData = DEC14; break;
case 15: decData = DEC15; break;
case 16: decData = DEC16; break;
case 17: decData = DEC17; break;
case 18: decData = DEC18; break;
case 19: decData = DEC19; break;
case 20: decData = DEC20; break;
case 21: decData = DEC21; break;
case 22: decData = DEC22; break;
case 23: decData = DEC23; break;
case 24: decData = DEC24; break;
case 25: decData = DEC25; break;
case 26: decData = DEC26; break;
case 27: decData = DEC27; break;
case 28: decData = DEC28; break;
case 29: decData = DEC29; break;
case 30: decData = DEC30; break;
case 31: decData = DEC31; break;
case 32: decData = DEC32; break;
case 33: decData = DEC33; break;
case 34: decData = DEC34; break;
case 35: decData = DEC35; break;
  }
  if (Math.abs(GD.raMax - GD.raMin) < 10)//not crossing 0h to 23h
  { GD.chart.crossingRA0 = false;
    for (var i = 0; i < decData.length; i += 4)
    { var raHrs = decData[i + 1];
      var decDegs = decData[i + 2];
      if (raHrs >= GD.raMin && raHrs <= GD.raMax
       && decDegs >= GD.decMin && decDegs <= GD.decMax)
      { var name = decData[i] ? decData[i] : "";
        GD.chart.stars.push({name:name, raHrs:raHrs, decDegs:decDegs, mV:decData[i + 3]});
  } } }
  else
  { GD.chart.crossingRA0 = true;
    for (var i = 0; i < decData.length; i += 4)
    { var raHrs = decData[i + 1];
      var decDegs = decData[i + 2];
      if ((raHrs <= GD.raMin || raHrs >= GD.raMax)
       && decDegs >= GD.decMin && decDegs <= GD.decMax)
      { var name = decData[i] ? decData[i] : "";
        GD.chart.stars.push({name:name, raHrs:raHrs, decDegs:decDegs, mV:decData[i + 3]});
} } } }

function findNGC()
{ var i = Math.floor(GD.decMin / 10 + 8), j = NGCIDX[i] * 4;
  while (NGC[j + 3] < GD.decMax)
  { var neb = {ngc:NGC[j], m:NGC[j + 1], raHrs:NGC[j + 2] / 15, decDegs:NGC[j + 3]};
    var v = calcSepnVector(GD.chart.obj, neb);
    if (v.sepnDegs < 3 && v.sepnDegs > 0.01)//Near the current object but not it
    { var ss = v.sepnDegs * GD.chart.scale;
      neb.xx = GD.chart.cx + ss * sinDegs(v.paDegs); // PA anticlock from N
      neb.yy = GD.chart.cy + ss * cosDegs(v.paDegs); // so effectively -90
      var id = (neb.m.length > 0) ? "M" + neb.m : neb.ngc;
      GD.chart.labels.push({name:id, pt:new Point(neb.xx + 10, neb.yy + 4)});
      GD.chart.ngc.push(neb);
    }
    j += 4;
} }

function showChartB()
{ var obj = GD.chart.obj;
  GD.decMin -= 0.5;
  GD.decMax += 0.5;
  GD.chart.caption = getFullObjName(obj) + ' ' + dateTimeHTML(' ') + ' ' +
    new RA(obj.raHrs).toString() + ' ' + new Dec(obj.decDegs).toString();
  if (GD.topocentric) { GD.chart.caption += ' (topocentric)'; }
  else { GD.chart.caption += ' (geocentric)'; }
  GD.nearest = obj;
  showData();
  GD.chart.show();
  location.assign('#chart');
}

function Chart(obj, halfWdDegs)//For finder charts
{ this.obj = obj;
  this.halfWdDegs = halfWdDegs;
  this.zoomed = false;
  this.stars = null;
  this.wd = 750; // px
  this.ht = 850;
  this.x0 = this.y0 = this.margin = 60;
  this.x1 = this.y1 = this.wd - this.margin;//Square plot
  this.cx = this.cy = (this.x0 + this.x1) / 2;//Plot centre
  this.scale = (this.x1 - this.x0) / (halfWdDegs * 2);
  this.mousedown = false;
  this.nearestLabel = null;
  // For magnitudes, magToR():
  this.rMax = 10;
  this.mMax = 12.5;
  this.slope = (this.rMax - 1) / (this.mMax + 1);
  this.rNakedEye = this.magToR(6);
  GD.elChart.innerHTML =
    'Finder chart. Labels can be dragged. (Firefox: right click to save on disc) ' +
    '<span id="chzoom"></span><br/><canvas id="finder" width="' + this.wd + 
    '" height="' + this.ht + '" style="border:0"/>';
  this.elZoom = document.getElementById("chzoom");
  this.elZoom.innerHTML = '<button onclick="GD.chart.zoomIn()">Zoom in</button>';
  this.cnv = document.getElementById('finder');
  this.cnv.addEventListener('mousedown', this.down, false);
  this.cnv.addEventListener('mousemove', this.move, false);
  this.cnv.addEventListener('mouseup', this.up, false);
  this.g2 = this.cnv.getContext('2d');
  this.g2.font = 'bold 14px monospace';
 }

Chart.prototype.zoomIn = function()
{ this.halfWdDegs = 1;
  this.scale = (this.x1 - this.x0) / (this.halfWdDegs * 2);
  this.elZoom.innerHTML = '<button onclick="GD.chart.zoomOut()">Zoom out</button>';
  this.zoomed = true;
  this.show();
};

Chart.prototype.zoomOut = function()
{ this.halfWdDegs = 2.5;
  this.scale = (this.x1 - this.x0) / (this.halfWdDegs * 2);
  this.elZoom.innerHTML = '<button onclick="GD.chart.zoomIn()">Zoom in</button>';
  this.zoomed = false;
  this.show();
};

Chart.prototype.show = function()
{ this.labels = [];
  this.stars = [];
  findStars(GD.idx1);
  if (GD.idx1 !== GD.idx2)
  { findStars(GD.idx2);
  }
  this.ngc = [];
  findNGC();
  this.calcStars();
  this.calcNears();
  this.calcGrid();
  this.drawAll();
};

Chart.prototype.drawAll = function()
{ this.g2.fillStyle = '#fff';
  this.g2.fillRect(0, 0, this.wd, this.ht);
//B4  if (this.obj.kind !== 'X')
  {//Red rings:
    var name = this.obj.name;
    var obj = {raHrs:this.obj.raHrs, decDegs:this.obj.decDegs};
    var jd0 = GD.cal.getJD();
    for (var jd = jd0 - 10; jd <= jd0 + 10; jd++)
    { var ms1970 = (jd - JD_1970_0) * DAY_MS;
      GD.cal.date = new Date(ms1970);
      getData();
      var i, v, ss, xx, yy;
      for (i = 0; i < objects.length; i++)
      { if (objects[i].name === name 
         && objects[i].kind !=="X")//B4
        { v = calcSepnVector(obj, objects[i]);
          ss = v.sepnDegs * this.scale;
          xx = this.cx + ss * sinDegs(v.paDegs);//PA anticlock from N
          yy = this.cy + ss * cosDegs(v.paDegs);//so effectively -90
          if (jd === jd0 - 1) fillCircle(this.g2, xx, yy, 3, '#f00');//AV
          strokeCircle(this.g2, xx, yy, 3, '#f00');
      } } 
      for (i = 1; i < this.nears.length; i++)//AV:
      { var nio = this.nears[i].obj;// note that [0] has no .obj
        if (nio.kind === "A" || nio.kind === "C" || nio.kind === "P")
        { v = calcSepnVector(obj, nio);
          ss = v.sepnDegs * this.scale;
          xx = this.cx + ss * sinDegs(v.paDegs);//PA anticlock from N
          yy = this.cy + ss * cosDegs(v.paDegs);//so effectively -90
          if (jd === jd0 - 1) fillCircle(this.g2, xx, yy, 3, '#f00');
          strokeCircle(this.g2, xx, yy, 3, '#f00');
      } }//:AV
    }
    var ms1970 = (jd0 - JD_1970_0) * DAY_MS;
    GD.cal.date = new Date(ms1970);//to jd0
    GD.cal.setFields();
    this.g2.fillStyle = '#f00';
    this.g2.fillText(
"Red rings at daily intervals, up to 10 days either side, solid dot previous day", 10, 40);
  }
  this.g2.fillStyle = '#000';
  this.g2.fillText(this.caption, 10, 20);
  this.drawGrid();
  this.drawStars();
  this.drawNGC();
  this.drawNears();
  this.drawKey();
  this.imData = this.g2.getImageData(0, 0, this.wd, this.ht);//AU
  this.drawLabels();
};

Chart.prototype.calcNears = function()
{ this.nears = [];
  this.nears[0] = {x:this.cx, y:this.cy};
  this.labels.push({name:getFullObjName(this.obj), pt:new Point(this.cx + 10, this.cy + 4)});
  for (var i = 0; i < objects.length; i++)
  { if (!(this.obj === objects[i]))
    { var v = calcSepnVector(this.obj, objects[i]);
      if (this.halfWdDegs >= v.sepnDegs)
      { var ss = v.sepnDegs * this.scale;
        var xx = this.cx + ss * sinDegs(v.paDegs); // PA anticlock from N
        var yy = this.cy + ss * cosDegs(v.paDegs); // so effectively -90
        this.nears[this.nears.length] = {x:xx, y:yy, obj:objects[i]};//AV: obj
        this.labels.push({name:getFullObjName(objects[i]), pt:new Point(xx + 10, yy + 4)});
  } } }
};

function getFullObjName(obj)
{ if (obj.kind === 'A') return obj.symbol + ' ' + obj.name;
  return obj.name;
}

Chart.prototype.drawNears = function()
{ this.g2.fillStyle = '#000';
  for (var i = 0; i < this.nears.length; i++)
  { var obj = this.nears[i];
    strokeCircle(this.g2, obj.x, obj.y, 7, '#000');
  }
};

Chart.prototype.drawLabels = function()
{ this.g2.fillStyle = '#000';//B7
  for (var i = 0; i < this.labels.length; i++)
  { var tx = this.labels[i];
    this.g2.fillText(tx.name, tx.pt.x, tx.pt.y);
  }
};

Chart.prototype.calcGrid = function()
{ if (this.decDegsLo < -85 || this.decDegsHi > 85) return;//No grid at poles
  this.dLo = Math.floor(this.decDegsLo) + 1;
  this.dHi = Math.floor(this.decDegsHi);
  this.rLo = Math.floor(this.raHrsLo * 15) + 1; // degs
  this.rHi = Math.floor(this.raHrsHi * 15);
  this.grid = new Array(this.dHi - this.dLo + 1);
  var i, j, r, d;
  // Calculate intersection points:
  if (this.crossingRA0)
  { this.rLo = 0;
    this.rHi = 360;
  }
  for (i = 0, d = this.dLo; d <= this.dHi; d++, i++)
  { this.grid[i] = [];//new Array(this.rHi - this.rLo + 1);
    for (j = 0, r = this.rLo; r <= this.rHi; r++, j++)
    { var v = calcSepnVector(this.obj, {raHrs:r / 15, decDegs:d});
      var ss = v.sepnDegs * this.scale;
      var xx = this.cx + ss * sinDegs(v.paDegs); // PA anticlock from N
      var yy = this.cy + ss * cosDegs(v.paDegs); // so effectively -90
      this.grid[i].push(new Point(xx, yy));//[j] = new Point(xx, yy);
  } }
};

Chart.prototype.drawGrid = function()
{ if (this.decDegsLo < -85 || this.decDegsHi > 85) return;//No grid at poles
  var i, j, r, d, pt0, pt1, ra, txt, x, prevX = 1000;
  // Draw RA lines:
  for (j = 0, r = this.rLo; r <= this.rHi; r++, j++)
  { for (i = 0, d = this.dLo; d < this.dHi; d++, i++)
    { pt0 = this.grid[i][j];
      pt1 = this.grid[i + 1][j];
      drawLine(this.g2, pt0.x, pt0.y, pt1.x, pt1.y, '#666');
    }
    ra = new RA((r % 360) / 15);
    txt = ra.getHour() + 'h' + ra.getMinute() + 'm';
    x = pt0.x - 30;
    if (prevX - x > 50)//avoid text overlap
    { this.g2.fillText(txt, x, this.y0);
      this.g2.fillText(txt, x, this.y1 + 30);
      prevX = x;
    }
  }
  this.g2.fillText('RA (J2000)', this.x1 - 90, this.y1 + 50);
  // Draw Dec lines:
  for (i = 0, d = this.dLo; d <= this.dHi; d++, i++)
  { for (j = 0, r = this.rLo; r < this.rHi; r++, j++)
    { pt0 = this.grid[i][j];
      pt1 = this.grid[i][j + 1];
      drawLine(this.g2, pt0.x, pt0.y, pt1.x, pt1.y, '#666');
    }
    txt = d + '\u00b0';
    this.g2.fillText(txt, this.x0 - 40, pt0.y);
    this.g2.fillText(txt, this.x1 + 10, pt0.y);
  }
  this.g2.fillText('Dec', 6, pt1.y + 20);
  this.g2.fillText('(J2000)', 6, pt1.y + 40);
};

Chart.prototype.calcStars = function()
{ if (null === this.stars || this.stars.length < 2) { error('No stars'); return; }
  this.x = [];
  this.y = [];
  this.r = [];
  this.mv = [];//B7
  var xx, yy;
  for (var i = 0; i < this.stars.length - 1; i++)
  { var star = this.stars[i];
    var v = calcSepnVector(this.obj, star);
    var ss = v.sepnDegs * this.scale;
    this.x[i] = xx = this.cx + ss * sinDegs(v.paDegs); // PA anticlock from N
    this.y[i] = yy = this.cy + ss * cosDegs(v.paDegs); // so effectively -90
    this.r[i] = Math.max(this.magToR(star.mV),1);
    this.mv[i] = star.mV;//B7
    if (star.name.length > 0)
      this.labels.push({name:greekify(star.name), pt:new Point(xx + 10, yy + 4)});
    if (i === 0)
    { this.decDegsLo = this.decDegsHi = star.decDegs;
      this.raHrsLo = this.raHrsHi = star.raHrs;
    }
    else
    { if (star.decDegs < this.decDegsLo) this.decDegsLo = star.decDegs;
      else if (star.decDegs > this.decDegsHi) this.decDegsHi = star.decDegs;
      if (star.raHrs < this.raHrsLo) this.raHrsLo = star.raHrs;
      else if (star.raHrs > this.raHrsHi) this.raHrsHi = star.raHrs;
  } }
};

Chart.prototype.magToR = function(mag)
{ return this.rMax - this.slope * (mag + 1);
};

Chart.prototype.drawStars = function()
{ for (var i = 0; i < this.x.length; i++)
  { var r = this.r[i];
    fillCircle(this.g2, this.x[i], this.y[i], r, '#999');
    if (r >= this.rNakedEye)
      drawCross(this.g2, this.x[i], this.y[i], r * 2, '#999');
  }
  this.g2.fillStyle = '#000';
};

Chart.prototype.drawNGC = function()
{ this.g2.strokeStyle = '#000';
  for (var i = 0; i < this.ngc.length; i++)
  { var neb = this.ngc[i];
    this.g2.strokeRect(neb.xx - 3, neb.yy - 3, 7, 7);
  }
};

Chart.prototype.drawKey = function()
{ this.g2.fillStyle = '#fff';
  this.g2.fillRect(0, this.y1 + 60, this.cnv.width, this.cnv.height);
  this.g2.fillStyle = '#000';
  this.g2.fillText(
'Magnitudes (Hipparcos/Tycho) - Shift+click near a star to see magnitude in red', this.x0, this.y1 + 80);
  var yt = this.y1 + 100;
  var ym = yt + 20;
  for (var m = 0, xx = this.x0 + 20; m <= this.mMax; m++, xx += 40)
  { this.g2.fillStyle = '#000';
    this.g2.fillText(m, xx - 5, yt);
    var r = this.magToR(m);
    fillCircle(this.g2, xx, ym, r, '#999');
    if (r >= this.rNakedEye) drawCross(this.g2, xx, ym, r * 2, '#999');
  }
  var year = new Date().getFullYear();
  this.g2.fillStyle = '#000';
  this.g2.fillText('Copyright \u00a9 Graham Relf, UK, ' + year, this.x0, ym + 35);
};

// T. Pauwels method, AA p115
function calcSepnVector(obj1, obj2)
{ var dRaRad = (obj2.raHrs - obj1.raHrs) * HRS_TO_RADS;
  var cosDa = Math.cos(dRaRad);
  var sinDa = Math.sin(dRaRad);
  var cosD1 = cosDegs(obj1.decDegs);
  var sinD1 = sinDegs(obj1.decDegs);
  var cosD2 = cosDegs(obj2.decDegs);
  var sinD2 = sinDegs(obj2.decDegs);
  var x = cosD1 * sinD2 - sinD1 * cosD2 * cosDa;
  var y = cosD2 * sinDa;
  var z = sinD1 * sinD2 + cosD1 * cosD2 * cosDa;
  var s = atan2Degs(Math.sqrt(x * x + y * y), z);
	var p = in360(atan2Degs(-sinDa, cosD2 * sinD1 / cosD1 - sinD2 * cosDa));
  return {sepnDegs:s, paDegs:p};
}

Chart.prototype.getMousePt = function(ev)
{	if (ev.pageX || ev.pageY)
    return new Point(ev.pageX - this.cnv.offsetLeft, ev.pageY - this.cnv.offsetTop);
  return new Point(ev.clientX + document.body.scrollLeft +
    document.documentElement.scrollLeft - this.cnv.offsetLeft,
	  ev.clientY + document.body.scrollTop  +
    document.documentElement.scrollTop  - this.cnv.offsetTop);
};

// NB: The following listeners are not given the current chart as this.

// onMousedown listener
Chart.prototype.down = function(ev)
{	var pt = GD.chart.getMousePt(ev);
  if (ev.shiftKey) GD.chart.showStarMag(pt);//B7
  else
  { GD.chart.nearestLabel = GD.chart.findNearestLabel(pt);
    GD.chart.mousedown = true;
} };

// onMouseup listener
Chart.prototype.up = function(ev)
{ GD.chart.mousedown = false;
  GD.chart.nearestLabel = null;
};

// onMove listener
Chart.prototype.move = function(ev)
{ if (GD.chart.mousedown && null !== GD.chart.nearestLabel)
  {	var pt = GD.chart.getMousePt(ev);
    GD.chart.nearestLabel.pt = pt;
//AU:    GD.chart.drawAll
    GD.chart.g2.putImageData(GD.chart.imData, 0, 0);
    GD.chart.drawLabels();//:AU
  }
};

Chart.prototype.findNearestLabel = function(pt)
{ var minD = 10000, nearest = null;
  for (var i = 0; i < this.labels.length; i++)
  { var tx = this.labels[i];
    var d = pt.distance(tx.pt);
    if (d < minD)
    { minD = d;
      nearest = tx;
  } }
  if (minD < 50) return nearest;
  return null;
};

Chart.prototype.showStarMag = function(pt)//B7
{ var minD = 10000, nearest = null;
  for (var i = 0; i < this.x.length; i++)
  { var d = pt.distance({x:this.x[i], y:this.y[i]});
    if (d < minD)
    { minD = d;
      nearest = i;
  } }
  if (minD < 50)
  { this.g2.fillStyle = '#f00';
    this.g2.fillText(this.mv[nearest], this.x[nearest] + 10, this.y[nearest]);
} };

//For star names: Greek letter abbreviations -> Unicode Greek letters
function greekify(tx)
{ for (var i = 0; i < SEQS.length; i++)
  { var pos = tx.indexOf(SEQS[i]);
    if (-1 !== pos)
    { tx = tx.replace(SEQS[i], ESCS[i]);
  } }
  return tx;
}

const SEQS =
[ "alp", "alf", "bet", "gam", "del", "eps", "zet", "eta",
  "the", "iot", "kap", "lam", "mu", "nu",
  "ksi", "omi", "pi", "rho", "sig", "tau", "ups", "phi",
  "chi", "psi", "ome"];

const ESCS =
[ "\u03b1", "\u03b1", "\u03b2", "\u03b3", "\u03b4", "\u03b5", "\u03b6", "\u03b7",
  "\u03b8", "\u03b9", "\u03ba", "\u03bb", "\u03bc", "\u03bd",
  "\u03be", "\u03bf", "\u03c0", "\u03c1", "\u03c3", "\u03c4", "\u03c5", "\u03c6",
  "\u03c7", "\u03c8", "\u03c9"];
