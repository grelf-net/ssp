'use strict';

const J2000 = new Epoch(2000);

function getData()
{ if (!GD.cal) return;
  var jd = GD.cal.getJD();
  var earth = new Earth(jd);
  sunL.rAU = earth.radiusVectorAU;
  sunR.rAU = sunL.rAU;
  GD.eclipticObliquityDegs = earth.eclipticObliquityDegs;
  cosEpsilon = cosDegs(GD.eclipticObliquityDegs);
  sinEpsilon = sinDegs(GD.eclipticObliquityDegs);
  var xyz = earth.getHeliocentricCoordinates();
  var sunDx = -xyz[0];
  var sunDy = -xyz[1];
  var sunDz = -xyz[2];
  //Rotate from ecliptic to equatorial coordinates to get RA and Dec:
  var dXeq = sunDx;
  var dYeq = sunDy * cosEpsilon - sunDz * sinEpsilon;
  var dZeq = sunDy * sinEpsilon + sunDz * cosEpsilon;
  var sunRaRad = Math.atan2(dYeq, dXeq);
  sunL.decDegs = atan2Degs(dZeq, Math.sqrt(dXeq * dXeq + dYeq * dYeq));
  sunL.raHrs = 12 * sunRaRad / Math.PI;
  if (sunL.raHrs < 0) sunL.raHrs += 24;
  sunR.raHrs = sunL.raHrs;
  sunR.decDegs = sunL.decDegs;
  var sunRiseSet = calcRiseTransitSet(jd, -0.8333, sunL.raHrs, sunL.decDegs);
  var astroTwilight = calcRiseTransitSet(jd, -18, sunL.raHrs, sunL.decDegs);
  twilightDegs = (sunRiseSet[0] - astroTwilight[0]) * 360;
  moon.at(jd);
  mercury.at(jd, earth);
  venus.at(jd, earth);
  mars.at(jd, earth);
  jupiter.at(jd, earth);
  saturn.at(jd, earth);
  uranus.at(jd, earth);
  neptune.at(jd, earth);
  var earth2000 = new EarthJ2000(jd);
  var xyz = earth2000.getHeliocentricCoordinates();
  var sunDxJ2000 = -xyz[0];
  var sunDyJ2000 = -xyz[1];
  var sunDzJ2000 = -xyz[2];
  var sunX = sunDxJ2000
            + 0.000000440360 * sunDyJ2000
            - 0.000000190919 * sunDzJ2000;
  var sunY = -0.000000479966 * sunDxJ2000
            + 0.917482137087 * sunDyJ2000
            - 0.397776982902 * sunDzJ2000;
  var sunZ =  0.397776982902 * sunDyJ2000
            + 0.917482137087 * sunDzJ2000;
  var iNearest = -1;// needed due to redefining objects array
  if (GD.nearest !== null)
  { for (var i = 0; i < objects.length; i++)
    {
      if (GD.nearest === objects[i])
      { iNearest = i;
        break;
  } } }
  objects = 
  [sunL,sunR,moon,mercury,venus,mars,jupiter,saturn,uranus,neptune,pluto,
   ceres, pallas, juno, vesta];
  for (var k = 0; k < addedObjects.length; k++)
  { objects.push(addedObjects[k]);
  }
  if (iNearest >= 0) GD.nearest = objects[iNearest];
  for (var j = 0; j < objects.length; j++)
  { var obj = objects[j];
    switch (obj.kind)
    {
    case 'P':
      if (obj.name !== 'Pluto') break;
      // Pluto drops through as asteroid...
    case 'A':
    case 'C':
      if (obj.getHeliocentricPositionAU) // In case not yet fully loaded
      { var xyz = obj.getHeliocentricPositionAU(jd); // sets rAU
        if (null !== xyz)
        { var dx = xyz.x + sunX;
          var dy = xyz.y + sunY;
          var dz = xyz.z + sunZ;
          obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
          var dLight = 0.0057755183 * obj.deltaAU; // days
          xyz = obj.getHeliocentricPositionAU (jd - dLight); // sets rAU
          obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
          var dot = dx * xyz.x + dy * xyz.y + dz * xyz.z;
          obj.phaseDegs = acosDegs(dot / (obj.rAU * obj.deltaAU));
          obj.decDegs = atan2Degs(dz, Math.sqrt(dx * dx + dy * dy));
          obj.raHrs = 12 * Math.atan2(dy, dx) / Math.PI;
          if (obj.raHrs < 0) obj.raHrs += 24;
          if (GD.topocentric)
          { var adj = topoAdjust(jd, obj.raHrs, obj.decDegs, obj.deltaAU);
            obj.raHrs = adj.raHrs;
            obj.decDegs = adj.decDegs;
          }
        }
      }
      // No other cases relevant
    }
  }
  showUserText();
  showPlot();
}
