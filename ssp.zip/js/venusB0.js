'use strict';

function Venus()
{ Planet.call(this);
  this.name = "Venus";
  this.symbol = 'V';
  this.kind = 'P';
  this.colour = '#0ff';
  this.eqRkm = 6052;
}
Venus.prototype = Object.create(Planet.prototype);
Venus.prototype.constructor = Venus;

Venus.prototype.at = function(observerJED, earth)
{ this.earth = earth;
  this.observerJED = observerJED;
  this.deltaAU = 1; // First guess
  this.calcPosition(observerJED - this.lightTimeDays(this.deltaAU));
  this.adjustForLightTime(earth);
  var skyPt = this.getSkyPoint(earth, J2000);
  this.raHrs = skyPt.ra.hours;
  this.decDegs = skyPt.dec.degs;
};

Venus.prototype.calcLDegs = function(tau)
{ var l0 = this.sumSeries(VENUS_L0, tau);
  var l1 = this.sumSeries(VENUS_L1, tau);
  var l2 = this.sumSeries(VENUS_L2, tau);
  var l3 = this.sumSeries(VENUS_L3, tau);
  var l4 = this.sumSeries(VENUS_L4, tau);
  var l5 = this.sumSeries(VENUS_L5, tau);
  return rad2deg ((((((l5 * tau + l4) * tau + l3) * tau
            + l2) * tau + l1) * tau + l0) * 1.0e-8);
}; // calcLDegs

Venus.prototype.calcBDegs = function(tau)
{ var b0 = this.sumSeries(VENUS_B0, tau);
  var b1 = this.sumSeries(VENUS_B1, tau);
  var b2 = this.sumSeries(VENUS_B2, tau);
  var b3 = this.sumSeries(VENUS_B3, tau);
  var b4 = this.sumSeries(VENUS_B4, tau);
  return rad2deg (((((b4 * tau + b3) * tau + b2) * tau + b1) * tau + b0) * 1.0e-8);
}; // calcBDegs

Venus.prototype.calcRAU = function(tau)
{ var r0 = this.sumSeries(VENUS_R0, tau);
  var r1 = this.sumSeries(VENUS_R1, tau);
  var r2 = this.sumSeries(VENUS_R2, tau);
  var r3 = this.sumSeries(VENUS_R3, tau);
  var r4 = this.sumSeries(VENUS_R4, tau);
  return ((((r4 * tau + r3) * tau + r2) * tau + r1) * tau + r0) * 1.0e-8;
}; // calcRAU

const VENUS_L0 = 
[
1, 317614667, 0, 0,
2, 1353968, 5.5931332, 10213.2855462,
3, 89892, 5.30650, 20426.57109,
4, 5477, 4.4163, 7860.4194,
5, 3456, 2.6996, 11790.6291,
6, 2372, 2.9938, 3930.2097,
7, 1664, 4.2502, 1577.3435,
8, 1438, 4.1575, 9683.5946,
9, 1317, 5.1867, 26.2983,
10, 1201, 6.1536, 30639.8566,
11, 769, 0.816, 9437.763,
12, 761, 1.950, 529.691,
13, 708, 1.065, 775.523,
14, 585, 3.998, 191.448,
15, 500, 4.123, 15720.839,
16, 429, 3.586, 19367.189,
17, 327, 5.677, 5507.553,
18, 326, 4.591, 10404.734,
19, 232, 3.163, 9153.904,
20, 180, 4.653, 1109.379,
21, 155, 5.570, 19651.048,
22, 128, 4.226, 20.775,
23, 128, 0.962, 5661.332,
24, 106, 1.537, 801.821
];

const VENUS_L1 = 
[
1, 1021352943053.0, 0, 0,
2, 95708, 2.46424, 10213.28555,
3, 14445, 0.51625, 20426.57109,
4, 213, 1.795, 30639.857,
5, 174, 2.655, 26.298,
6, 152, 6.106, 1577.344,
7, 82, 5.70,191.45,
8, 70, 2.68, 9437.76,
9, 52, 3.60, 775.52,
10, 38, 1.03, 529.69,
11, 30, 1.25, 5507.55,
12, 25, 6.11, 10404.73
];

const VENUS_L2 = 
[
1, 54127, 0, 0,
2, 3891, 0.3451, 10213.2855,
3, 1338, 2.0201, 20426.5711,
4, 24, 2.05, 26.30,
5, 19, 3.54, 30639.86,
6, 10, 3.97, 775.52,
7, 7, 1.52, 1577.34,
8, 6, 1.00, 191.45
];

const VENUS_L3 = 
[
1, 136, 4.804, 10213.286,
2, 78, 3.67, 20426.57,
3, 26, 0, 0
];

const VENUS_L4 = 
[
1, 114, 3.1416, 0,
2, 3, 5.21, 20426.57,
3, 2, 2.51, 10213.29
];

const VENUS_L5 = 
[
1, 1, 3.14, 0
];

const VENUS_B0 = 
[
1, 5923638, 0.2670278, 10213.2855462,
2, 40108, 1.14737, 20426.57109,
3, 32815, 3.14159, 0,
4, 1011, 1.0895, 30639.8566,
5, 149, 6.254, 18073.705,
6, 138, 0.860, 1577.344,
7, 130, 3.672, 9437.763,
8, 120, 3.705, 2352.866,
9, 108, 4.539, 22003.915
];

const VENUS_B1 = 
[
1, 513348, 1.803643, 10213.285546,
2, 4380, 3.3862, 20426.5711,
3, 199, 0, 0,
4, 197, 2.530, 30639.857
];

const VENUS_B2 = 
[
1, 22378, 3.38509, 10213.28555,
2, 282, 0, 0,
3, 173, 5.256, 20426.571,
4, 27, 3.87, 30639.86
];

const VENUS_B3 = 
[
1, 647, 4.992, 10213.286,
2, 20, 3.14, 0,
3, 6, 0.77, 20426.57,
4, 3, 5.44, 30639.86
];

const VENUS_B4 = 
[
1, 14, 0.32, 10213.29
];

const VENUS_R0 = 
[
1, 72334821, 0, 0,
2, 489824, 4.021518, 10213.285546,
3, 1658, 4.9021, 20426.5711,
4, 1632, 2.8455, 7860.4194,
5, 1378, 1.1285, 11790.6291,
6, 498, 2.587, 9683.595,
7, 374, 1.423, 3930.210,
8, 264, 5.529, 9437.763,
9, 237, 2.551, 15720.839,
10, 222, 2.013, 19367.189,
11, 126, 2.728, 1577.344,
12, 119, 3.020, 10404.734
];

const VENUS_R1 = 
[
1, 34551, 0.89199, 10213.28555,
2, 234, 1.772, 20426.571,
3, 234, 3.142, 0
];

const VENUS_R2 = 
[
1, 1407, 5.0637, 10213.2855,
2, 16, 5.47, 20426.57,
3, 13, 0, 0
];

const VENUS_R3 = 
[
1, 50, 3.22, 10213.29
];

const VENUS_R4 = 
[
1, 1, 0.92, 10213.29
];
