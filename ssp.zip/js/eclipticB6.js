// ecliptic.js by Graham Relf, revised 2025 May - July, 2026 April
'use strict';
const IMWD = 798, IMHT = 270, HALF_IMWD = IMWD / 2, HALF_IMHT = IMHT / 2;
const PX_PER_DEG = IMWD / 360.0;
const SCALE_HT = 10;//RA & Elong scales
const HALF_SCALE_HT = SCALE_HT / 2;
const DEC_MAX = 50, DEC_MIN = -DEC_MAX, DEC_RANGE = DEC_MAX - DEC_MIN;
const X0 = 0, Y0 = IMHT / 2;
const UPPER_SCALE_Y0 = 0, LOWER_SCALE_Y0 = IMHT - SCALE_HT;
const SUN_RADIUS = 10; // px
const SUN_DIAMETER = SUN_RADIUS * 2;
const HORIZON_LENGTH = IMHT / 2;//px
const NIGHT_COLOUR = '#000', SCALE_COLOUR = '#fff', EQUATOR_COLOUR = '#0f0';
const CONSTELLATION_COLOUR = '#999', STATIC_COLOUR = '#00f', HORIZON_COLOUR = '#0f0';
const TWILIGHT_COLOUR = '#ccc', ECLIPTIC_COLOUR = '#99f';
const FONT = 'bold 10px sans-serif';
const OBS_LIST_HEAD = 'Observing list (copy and paste into spreadsheet)<br/>' +
'<table><tr><th>Date/time (UTC)</th><th>JD</th><th>Object</th>' +
'<th>RA (J2000)</th><th>Dec (J2000)</th></tr>';
const HELP_SELECT_A = '<p>Drop the list down by clicking the arrow at the right. Then either scroll down the long list to find the object you want or start to type its name. Click on it when  found.</p>';
const HELP_SELECT_C = '<p>Drop one list down by clicking the arrow at the right. Then scroll down the long list to find the comet you want. Click on it when  found.</p>';
const KM_TO_AU = 6.68458134e-9;

function jdToDate(jd)
{ var ms = (jd - JD_1970_0) * 86400000;
  var d = new Date(ms);
  return d.getUTCFullYear() + "-" + (1 + d.getUTCMonth()) + "-" + d.getUTCDate();
}

// Global Data
const GD = { cnv:null, g2:null, latDegs:55, longDegs:0, ht_m:0, cal:null,
northView:true, topocentric:false, nearest:null, selection:null, chart:null,
elObsList:null, obsList:OBS_LIST_HEAD, elData:null, elChart:null,
eclipticObliquityDegs:23.5};

let objects = [], addedObjects = [], cosEpsilon, sinEpsilon, twilightDegs, 
sunL, sunR, moon, mercury, venus, mars, jupiter, saturn, uranus, neptune, pluto,
ceres, pallas, juno, vesta;

function run()
{ for (var i = 0; i < 36; i++) decLoaded[i] = false;//in charts.js
  GD.elData = document.getElementById('data');
  GD.elObsList = document.getElementById('obsList');
  GD.elChart = document.getElementById('chart');
	GD.cnv = document.getElementById('plot');
  GD.cnv.addEventListener('click', handleClick, false);
  GD.cnv.addEventListener('mousemove', handleMove, false);
  GD.cal = new Calendar('Calendar', getAndShowData);
  getCookies();
  sunL = {name:'Sun', symbol:'', kind:'S', colour:'#ff0'};
  sunR = {name:'Sun', symbol:'', kind:'S', colour:'#ff0'};
  moon = new Moon();
  mercury = new Mercury();
  venus = new Venus();
  mars = new Mars();
  jupiter = new Jupiter();
  jupiter.moonLink = "jupiter.html";
  saturn = new Saturn();
  saturn.moonLink = "saturn.html";
  uranus = new Uranus();
  neptune = new Neptune();
  pluto = new Orbit('Pluto', 'P', 'P', '#0ff', 1990, 10, 9.71643,
    29.80651303494526, 0.2566687011667356, 116.1890224972339, 110.3600311387948,
    17.09558287650895, 2454648.5, -0.52, 0.15);
  pluto.eqRkm = 1150;
  ceres = createAsteroid("Ceres=1");
  pallas = createAsteroid("Pallas=2");
  juno = createAsteroid("Juno=3");
  vesta = createAsteroid("Vesta=4");
  setTopo();
  getData();
  classifyComets();
}

function getAndShowData()
{ getData();
  showData();
}

function addAsteroid()
{ GD.nearest = null;
  var n = ASTEROIDS.length;
  GD.selection = [];
  var s = '<select id="asterSel" class="control" onchange="addAsteroidB()">' +
    '<option>Select an asteroid...</option>';
  for (var na = 0, i = 0; i < n; i += 10, na++)
  { if (n > 0)
    { GD.selection.push(ASTEROIDS[i]);
      s += '<option value="' + ASTEROIDS[i] + '">' + ASTEROIDS[i] + '</option>';
  } }
  s += '</select><br/>' + HELP_SELECT_A +
'OR <input type="button" class="control" value="Add all ' +
na + ' asteroids" onclick="addAsteroids()"/><br/>' +
'(those at opposition brighter than magnitude 15 recently and in the coming year)<br/>' +
'OR <input type="button" class="control" value="List appulses" onclick="checkAppulses()"/><br/>' +
'OR <input type="button" class="control" value="Add some TNOs" onclick="addTNOS()"/><br/>' +
'(Trans-Neptunian Objects)' +
DATA_REVISED;
  GD.elData.innerHTML = s;
}

function addAsteroidB()
{ var el = document.getElementById('asterSel');
  var id = GD.selection[el.selectedIndex - 1];
  var a = createAsteroid(id);
  if (null !== a)
  { addedObjects.push(a);
    getData();
} }

function addAsteroids()
{ GD.nearest = null;
  for (var i = 0; i < ASTEROIDS.length; i +=10)
  { var a = createAsteroid(ASTEROIDS[i]);
    if (null !== a)
    { addedObjects.push(a);
  } }
  getData();
}

function createAsteroid(id)
{ for (var i = 0; i < objects.length; i++)
  { if (id.startsWith(objects[i].name))
    { //error(id + ' already added');
      return null;
  } }
  for (i = 0; i < addedObjects.length; i++)
  { if (addedObjects[i].name === id) return null;
  }
  for (i = 0; i < ASTEROIDS.length; i += 10)
  { if (ASTEROIDS[i] === id) break;
  }
  var omegaDegs = ASTEROIDS[i + 4];
  var periArgDegs = ASTEROIDS[i + 5];
  var periLongDegs = omegaDegs + periArgDegs;
  var meanAnomalyDegs = ASTEROIDS[i + 7];
  var meanLongDegs = periLongDegs + meanAnomalyDegs;
  var parts = id.split('=');
  var name = parts[0], symbol = parts[1];
  return createOrbit(name, symbol, 'A', '#f00',
parseFloat(ASTEROIDS[i + 6]),//epochJD,
parseFloat(ASTEROIDS[i + 1]),//e,
parseFloat(ASTEROIDS[i + 2]),//aAU,
parseFloat(ASTEROIDS[i + 3]),//iDegs,
omegaDegs, periLongDegs, meanLongDegs,
parseFloat(ASTEROIDS[i + 9]),//h
parseFloat(ASTEROIDS[i + 8]));//g
}

function addTNOS()
{ GD.nearest = null;
  for (var i = 0; i < TNOS.length; i +=10)
  { var a = createTNO(TNOS[i]);
    if (null !== a)
    { addedObjects.push(a);
  } }
  getData();
}
function createTNO(id)
{ for (var i = 0; i < objects.length; i++)
  { if (objects[i].name === id)
    { error(id + ' already added');
      return null;
  } }
  for (var i = 0; i < TNOS.length; i += 10)
  {
    if (TNOS[i] === id) break;
  }
  var omegaDegs = TNOS[i + 4];
  var periArgDegs = TNOS[i + 5];
  var periLongDegs = omegaDegs + periArgDegs;
  var meanAnomalyDegs = TNOS[i + 7];
  var meanLongDegs = periLongDegs + meanAnomalyDegs;
  var parts = id.split('=');
  var name = parts[0], symbol = parts[1];
  return createOrbit(name, symbol, 'A', '#fd6',
parseFloat(TNOS[i + 6]),//epochJD,
parseFloat(TNOS[i + 1]),//e,
parseFloat(TNOS[i + 2]),//aAU,
parseFloat(TNOS[i + 3]),//iDegs,
omegaDegs, periLongDegs, meanLongDegs,
parseFloat(TNOS[i + 9]),//h
parseFloat(TNOS[i + 8]));//g
}

const PINDEX = [], NINDEX = [], IINDEX = [];

function classifyComets()//Once near start
{ var n = COMETS.length;
  for (var i = 0; i < n; i += 13)
  { if (COMETS[i].charAt(1) === '/') NINDEX.push(i);
    else if (COMETS[i].charAt(1) === 'I') IINDEX.push(i);//Change when IINDEX.length > 9
    else PINDEX.push(i);
} }

function addComet()
{ GD.nearest = null;
  var nn = NINDEX.length, np = PINDEX.length, ni = IINDEX.length;
  var n = COMETS.length, name, i;
  GD.selectionP = [];
  GD.selectionN = [];
  GD.selectionI = [];
  var s = '<select id="cometSelP" class="control2" onchange="addCometP()">' +
    '<option>Select a periodic comet...</option>';
  for (i = 0; i < np; i++)
  { name = COMETS[PINDEX[i]];
    GD.selectionP.push(name);
    s += '<option value="' + name + '">' + name + '</option>';
  }
  s += '</select><br/>' + '<select id="cometSelN" class="control2" onchange="addCometN()">' +
    '<option>Select a non-periodic comet...</option>';
  for (i = nn - 1; i >= 0; i--)
  { name = COMETS[NINDEX[i]];
    GD.selectionN.push(name);
    s += '<option value="' + name + '">' + name + '</option>';
  }
  s += '</select><br/>' + '<select id="cometSelI" class="control2" onchange="addCometI()">' +
    '<option>Select an interstellar comet...</option>';
  for (i = 0; i < ni; i++)
  { name = COMETS[IINDEX[i]];
    GD.selectionI.push(name);
    s += '<option value="' + name + '">' + name + '</option>';
  }
  s += '</select><br/>' + HELP_SELECT_C +
    'OR <input type="button" class="control" value="Add all ' +
    Math.round(n / 13) + ' comets" onclick="addComets()"/><br/>' +
    '(those currently listed as observable by the Minor Planet Center)' +
    DATA_REVISED;
  GD.elData.innerHTML = s;
}

function addCometP()
{ GD.nearest = null;
  var el = document.getElementById('cometSelP');
  var name = GD.selectionP[el.selectedIndex - 1];
  for (var i = 0; i < COMETS.length; i += 13)
  { if (COMETS[i] === name)
    { addedObjects.push(createComet(i));
  } }
  getData();
}

function addCometN()
{ GD.nearest = null;
  var el = document.getElementById('cometSelN');
  var name = GD.selectionN[el.selectedIndex - 1];
  for (var i = 0; i < COMETS.length; i += 13)
  { if (COMETS[i] === name)
    { addedObjects.push(createComet(i));
  } }
  getData();
}

function addCometI()
{ GD.nearest = null;
  var el = document.getElementById('cometSelI');
  var name = GD.selectionI[el.selectedIndex - 1];
  for (var i = 0; i < COMETS.length; i += 13)
  { if (COMETS[i] === name)
    { addedObjects.push(createComet(i));
  } }
  getData();
}

function addComets()
{ for (var i = 0; i < COMETS.length; i += 13)
  { addedObjects.push(createComet(i));
  }
  GD.nearest = null;
  getData();
}

function createComet(i)
{ return new Orbit(COMETS[i], 'C', 'C', '#0f0',
COMETS[i + 2], COMETS[i + 3], COMETS[i+4],//tauY, tauM, tauD
COMETS[i + 5], COMETS[i + 6], COMETS[i+7],//qAU, e, periArgDegs
COMETS[i + 8], COMETS[i + 9], COMETS[i+10],//omegaDegs, iDegs, epochJD
COMETS[i + 11], COMETS[i + 12]);//h, g ??? 
}

function addKreutz ()
{ GD.nearest = null;
  var nowJD = GD.cal.getJD ();
  var offsets = [ 50, 100, 150, 300, 600, 1000 ];
  for (var i = 0; i < offsets.length; i++)
  { var offsetDays = offsets [i];
    var periJD = nowJD + offsetDays;
    var msSince1970 = (periJD - JD_1970_0) * DAY_MS;
    var tau = new Date(msSince1970);
    var tauD = tau.getUTCDate() + tau.getUTCHours() / 24 + tau.getUTCMinutes() / 1440 +
    tau.getUTCSeconds() / 84600;
    addedObjects.push(new Orbit(
      "Kreutz (C/1963 R1) " + offsetDays + "d from perihelion",
      "" + offsetDays, "C", "#f00",
      tau.getUTCFullYear(), tau.getUTCMonth() + 1, tauD,
      .005065, 1, 86.1601, 7.9393, 144.5821, JD2000, 0, 0));
    addedObjects.push(new Orbit(
      "Kreutz (C/1965 S1) " + offsetDays + "d from perihelion",
      "" + offsetDays, "C", "#0f0",
      tau.getUTCFullYear(), tau.getUTCMonth() + 1, tauD,
      .007786, 1, 69.04859999999999, 346.9947, 141.8642, JD2000, 0, 0));
    addedObjects.push(new Orbit(
      "Kreutz (C/2011 W3) " + offsetDays + "d from perihelion",
      "" + offsetDays, "C", "#00f",
      tau.getUTCFullYear(), tau.getUTCMonth() + 1, tauD,
      .005540668006330437, 1, 53.69400174361243, 326.6072988932971,
      134.4540420267504, JD2000, 0, 0));
  }
  GD.nearest = null;
  getData ();
}

function addStatic()
{ GD.nearest = null;
  GD.elData.innerHTML = 
'<p>Enter only numbers:</p>' +
'<p>Messier number: <input type="text" id="messierNo" maxlength="3" size="6" onchange="addMessier()"/><br/>' +
'<input type="button" class="control" value="Add Messier" onclick="addMessier()"/></p>' +
'<p>OR <input type="button" class="control" value="Add all Messier" onclick="addAllM()"/></p>' +
'<p>OR NGC number: <input type="text" id="ngcNo" maxlength="4" size="6" onchange="addNGC()"/><br/>' +
'<input type="button" class="control" value="Add NGC" onclick="addNGC()"/></p>';
}

function addMessier()
{ var mNo = document.getElementById('messierNo').value;
  for (var i = 1; i < NGC.length; i += 4)
  { if (NGC[i] === mNo)
    { var x = {name:"M" + mNo, symbol:'', kind:'X', colour:'#ff0',
               raHrs:NGC[i + 1] / 15, decDegs:NGC[i + 2]};
      addedObjects.push(x);
      getData();
      GD.nearest = x;
      return;
  } }
  error("M" + mNo + " not found");
}

function addAllM()
{ GD.nearest = null;
  for (var i = 1; i < NGC.length; i += 4)
  { if (NGC[i].length > 0)
    { var x = {name:"M" + NGC[i], symbol:'', kind:'X', colour:'#ff0',
               raHrs:NGC[i + 1] / 15, decDegs:NGC[i + 2]};
      addedObjects.push(x);
  } }
  getData();
}

function addNGC()
{ var ngcNo = document.getElementById('ngcNo').value;
  for (var i = 0; i < NGC.length; i += 4)
  { if (NGC[i] === ngcNo)
    { var x = {name:"NGC" + ngcNo, symbol:'', kind:'X', colour:'#ff0',
               raHrs:NGC[i + 2] / 15, decDegs:NGC[i + 3]};
      addedObjects.push(x);
      getData();
      GD.nearest = x;
      return;
  } }
  error("NGC" + ngcNo + " not found");
}

function addToObsList()
{ GD.obsList += '<tr><td>' + GD.cal.date.getUTCFullYear() + ' ' +
GD.cal.form.month.options[GD.cal.date.getUTCMonth()].value + ' ' +
GD.cal.date.getUTCDate() + ' ' + GD.cal.date.getUTCHours() + ':' +
GD.cal.date.getUTCMinutes() + ':' + GD.cal.date.getUTCSeconds() + '</td><td>' +
GD.cal.getJD().toFixed(5) + '</td><td>';
if (GD.nearest.kind === 'A') GD.obsList += GD.nearest.symbol + ' '; 
GD.obsList += GD.nearest.name + '</td><td>' +
new RA(GD.nearest.raHrs).toHTMLString() + '</td><td>' +
new Dec(GD.nearest.decDegs).toHTMLString() + '</td></tr>';
  showObsList();
}

function clearChart()
{ GD.elChart.innerHTML = 'Chart/table area';
  showUserText();
}

function clearObj()
{ GD.nearest = null;
  addedObjects = [];
  appUncheckAll();
  showUserText();
  getData();
}

function clearObsList()
{ GD.obsList = OBS_LIST_HEAD;
  showObsList ();
}

function changeLat()
{ var form = document.forms['formLatLong'];
  GD.latDegs = parseFloat(form.inLat.value);
  var elNS = form.selectNS;
  if ('S' === elNS.options[elNS.selectedIndex].value) { GD.latDegs = -GD.latDegs; }
  var expiry = new Date();
  expiry.setFullYear(expiry.getFullYear() + 1);
  document.cookie = 'latitude=' + GD.latDegs + ';expires=' + expiry.toGMTString();
  showPlot();
}

function changeLong()
{ var form = document.forms['formLatLong'];
  GD.longDegs = parseFloat(form.inLong.value);
  var elEW = form.selectEW;
  if ('W' === elEW.options[elEW.selectedIndex].value) { GD.longDegs = -GD.longDegs; }
  var expiry = new Date();
  expiry.setFullYear(expiry.getFullYear() + 1);
  document.cookie = 'longitude=' + GD.longDegs + ';expires=' + expiry.toGMTString();
  showPlot();
}

function error(msg){ GD.elData.innerHTML = '<h3>Error</h3><p>' + msg + '</p>'; }

function getCookies()
{ var cookies = document.cookie.split(';');
  var form = document.forms['formLatLong'];
  for (var i = 0; i < cookies.length; i++)
  { var cookie = cookies[i];
    var posEq = cookie.indexOf('=', 0);
    if (-1 !== posEq)
    { var name = cookie.substring(0, posEq);
      if (-1 !== name.indexOf('latitude'))
      { GD.latDegs = parseFloat(cookie.substring(posEq + 1));
        form.inLat.value = Math.abs(GD.latDegs);
        if (GD.latDegs >= 0)
        { form.selectNS.selectedIndex = 0;
          setNorth();
        }
        else
        { form.selectNS.selectedIndex = 1;
          setSouth();
        }
      }
      if (-1 !== name.indexOf('longitude'))
      { GD.longDegs = parseFloat(cookie.substring(posEq + 1));
        form.inLong.value = Math.abs(GD.longDegs);
        form.selectEW.selectedIndex = (GD.longDegs >= 0) ? 0 : 1;
} } } }

function setGeo()
{ document.getElementById("geo").checked = true;
  document.getElementById("topo").checked = false;
  GD.topocentric = false;
  getData();
}

function setTopo()
{ document.getElementById("geo").checked = false;
  document.getElementById("topo").checked = true;
  GD.topocentric = true;
  // Jean Meeus AA Chap 11:
  var f = 1 / 298.257;
  var ba = 1.0 - f;
  var u = Math.atan2(ba * tanDegs(GD.latDegs), 1);
  GD.sinPhi = Math.sin(GD.latDegs);
  GD.cosPhi = Math.cos(GD.latDegs);
  GD.rhoSinPhiDash =  ba * Math.sin(u) + GD.ht_m * GD.sinPhi / 6378140.0;
  GD.rhoCosPhiDash = Math.cos(u) + GD.ht_m * GD.cosPhi / 6378140.0;
  getData();
}

function setNorth()
{ document.getElementById("north").checked = true;
  document.getElementById("south").checked = false;
  GD.northView = true;
  getData();
}

function setSouth()
{ document.getElementById("north").checked = false;
  document.getElementById("south").checked = true;
  GD.northView = false;
  getData();
}

function showData()
{ var s = '&nbsp;';
  if (null !== GD.nearest)
  { var nearest = GD.nearest;
    var jd = GD.cal.getJD();
    var h0 = -0.5667;
    s = '<strong>';
    if (nearest.kind === 'A') s += nearest.symbol + ' ';
    s += nearest.name;
    if (nearest.kind === 'X' && nearest.name.startsWith("M"))
    { var mNo = parseInt(nearest.name.substring(1));
      var i = (mNo - 1) * 2;
      s += " " + MNAMES[i + 1];
      switch (MNAMES[i])
      { case "pn": s += " planetary nebula"; break;
        case "oc": s += " open cluster"; break;
        case "gc": s += " globular cluster"; break;
        case "g": s += " galaxy"; break;
        case "n": s += " nebula"; break;
    } }
    s += '</strong>';
    if (nearest.moonLink)
    { s += '&nbsp; <a href="https://grelf.net/' + nearest.moonLink + '?jd=' + jd;
      s += '" target="_blank">Find moons</a>';
    }
    s +='<br/>' + dateTimeHTML('<br/>') +
'<span title="Right ascension (RA)">' +
new RA(nearest.raHrs).toHTMLString() + '</span> <span title="Declination (Dec)">' +
new Dec(nearest.decDegs).toHTMLString() + '</span> (J2000.0)<br/>';
    var theta0Degs = toMeanSiderealTimeAtGreenwichDegs (jd);
    var _HDegs = in360(theta0Degs - GD.longDegs - nearest.raHrs * 15);
/*    s += '<span title="Hour angle is time after meridian transit">Hour angle = ' +
new RA(_HDegs / 15).toHTMLString() + '</span><br/>';*/
    var cosH = cosDegs(_HDegs);
    var sinDec = sinDegs(nearest.decDegs);
    var cosDec = cosDegs(nearest.decDegs);
    var sinPhi = sinDegs(GD.latDegs);
    var cosPhi = cosDegs(GD.latDegs);
    var aziDegs = atan2Degs(sinDegs(_HDegs), cosH * sinPhi - sinDec * cosPhi / cosDec);
    var altDegs = asinDegs(sinPhi * sinDec + cosPhi * cosDec * cosH);
    s += '<span title="Azimuth is measured from S via W">Azimuth = ' +
aziDegs.toFixed(2) + '&deg;, altitude = ' +
altDegs.toFixed(2) + '&deg;</span><br/>';
    switch (nearest.kind)
    {
    case 'M':
      var f = (nearest.deltaKm - 356371) / (406720 - 356371);
      s += '<span title="&Delta; = distance from Earth">&Delta; = ' +
nearest.deltaKm.toFixed() + 'km (= ' +
f.toFixed(2) + ' apo-peri range)</span><br/>' +
'Phase = ' + nearest.phaseDegs.toFixed(2) + '&deg;';
      h0 = 0.125;
      break;
    case 'S':
      h0 = -0.8333;
      break;
    case 'C':
      if (nearest.e < 1)
      { var a = nearest.qAU / (1 - nearest.e);
        var p = (Math.sqrt(TWO_PI_ON_K_SQ * a * a * a) / 365.25);
        if (!Number.isNaN(p)) s += 'Period = ' + p.toFixed(1) + ' years<br/>';
      }
      // then drop through...
    case 'A':
      s += 'phase = ' + nearest.phaseDegs.toFixed(2) + '&deg;, ' +
'<span title="mV = estimated visual magnitude">mV = ' + 
calcMv(nearest).toFixed(1) + '(est.)</span><br/>' +
'<span title="T = Time of perihelion">T = JD' + nearest.tauJD.toFixed(5) +
' (' + jdToDate(nearest.tauJD) + ')' + '</span><br/>' +
'<span title="q = perihelion distance">' +
'q = ' + nearest.qAU.toFixed(2) + 'au</span>, ' +
'<span title="e = orbital eccentricity">' +
'e = ' + nearest.e.toFixed(5) + '</span><br/>' +
'<span title="Distances: r from Sun, &Delta; from Earth">' +
'r = ' + nearest.rAU.toFixed(2) + 'au, ' +
'&Delta; = ' + nearest.deltaAU.toFixed(2) + 'au</span>';
      break;
    case 'P':
      var diamDegs = 2 * atan2Degs(nearest.eqRkm * KM_TO_AU, nearest.deltaAU);
      if (nearest.name === "Pluto")
      { s += 'phase = ' + nearest.phaseDegs.toFixed(2) + '&deg;, ' +
'<span title="mV = estimated visual magnitude">mV = ' + 
calcMv(nearest).toFixed(1) + '(est.)</span><br/>';
      }
      s += '<span title="Distances: r from Sun, &Delta; from Earth">' +
'r = ' + nearest.rAU.toFixed(2) + 'au, ' +
'&Delta; = ' + nearest.deltaAU.toFixed(2) + 'au</span><br/>' +
'Equatorial diameter = ' + (diamDegs * 3600).toFixed(1) + '&quot;';
    }
    var rts = calcRiseTransitSet(jd, h0, nearest.raHrs, nearest.decDegs);
    var polar = (rts[0] === rts[2]);
    s += '<br/>Local mean times of<br/>&nbsp;&nbsp;rising: ';
    s += (polar) ? 'n/a' : fracToHM(rts[0]);
    s += '<br/>&nbsp;&nbsp;transit: ' + fracToHM(rts[1]) +
         '<br/>&nbsp;&nbsp;setting: ';
    s += (polar) ? 'n/a' : fracToHM(rts[2]);
    if (nearest.kind === 'S')
    { var twi = calcRiseTransitSet(jd, -6.0, nearest.raHrs, nearest.decDegs);
      s += '<br/>&nbsp;&nbsp;civil twilight: ';
      if (twi[0] === twi[2]) s += 'n/a'; 
      else s += fracToHM(twi[0]) + ', ' + fracToHM(twi[2]);
      twi = calcRiseTransitSet(jd, -12.0, nearest.raHrs, nearest.decDegs);
      s += '<br/>&nbsp;&nbsp;nautical twilight: ';
      if (twi[0] === twi[2]) s += 'n/a'; 
      else s += fracToHM(twi[0]) + ', ' + fracToHM(twi[2]);
      twi = calcRiseTransitSet(jd, -18.0, nearest.raHrs, nearest.decDegs);
      s += '<br/>&nbsp;&nbsp;astron. twilight: ';
      if (twi[0] === twi[2]) s += 'n/a'; 
      else s += fracToHM(twi[0]) + ', ' + fracToHM(twi[2]);
    }
    else
    { s += '<br/>' + calcSepnDegs(nearest, sunL).toFixed(1) + '&deg; from Sun';
    }
    if (nearest.kind !== 'M')
    { s += '<br/>' + calcSepnDegs(nearest, moon).toFixed(1) + '&deg; from Moon';
    }
    for (var i = 0; i < objects.length; i++)
    { var obj = objects[i];
      if (obj !== nearest && obj.kind !== 'S' && obj.kind !== 'M'
       && -1 === obj.name.indexOf('Kreutz'))
      { var sepnDegs = calcSepnDegs(nearest, obj);
        if (5 > sepnDegs)
        { var n = (1 > sepnDegs) ? 4 : 1;
          s += '<br/>' + sepnDegs.toFixed(n) + '&deg; from ' + obj.name;
    } } }
    s += '<br/>';
    if (nearest.name.indexOf('Kreutz') === 0)
    { s +=
'<input type="button" class="control" value="Tabulate Kreutz" onclick="showKreutz()"/>';
    }
    s +=
'<input type="button" class="control" value="Add to observing list" ' +
'onclick="addToObsList()"/>' +
'<input type="button" class="control" value="Show finder chart" onclick="showChart(' +
"'" + nearest.name.replace("'", "\\'") + "'" + ')"/>';
    if (nearest.kind === "C")//AB && nearest.qAU < 2)
    { s +=
'<input type="button" class="control" value="Plot r, &Delta; against t" onclick="plotRDT(' +
"'" + nearest.name.replace("'", "\\'") + "'" + ')"/> <a href="#a_rd" class="intLink">?</a>';
    }
    GD.elData.innerHTML = s;
  }
  else showUserText();
}

function fracToHM(dayFrac)
{ if (dayFrac < 0) dayFrac += 1;
  else if (dayFrac  > 1) dayFrac -= 1;
  var f24 = dayFrac * 24;
  var h = Math.floor(f24);
  var m = ((f24 - h) * 60).toFixed();
  if (m === 60) { h++; m -= 60; }
  return h + sup('h') + m + sup('m');
}

function dateTimeHTML(newline)
{ return GD.cal.date.getUTCFullYear() + ' ' +
GD.cal.form.month.options [GD.cal.date.getUTCMonth()].value + ' ' +
GD.cal.date.getUTCDate() + ' ' + GD.cal.date.getUTCHours() + ':' +
GD.cal.date.getUTCMinutes() + ':' + GD.cal.date.getUTCSeconds() + ' UTC' + newline +
'JD ' + GD.cal.getJD().toFixed(5) + newline;
}

function showKreutz()
{ var s = 'Kreutz orbits at ' + dateTimeHTML('<br/>') +
'<table><tr><th>Orbit</th><th>RA (J2000)</th><th>Dec (J2000)</th>' +
'<th>r (au)</th><th>&Delta; (au)</th></tr>';
  var nK = 0;
  for (var i = 0; i < objects.length; i++)
  { var obj = objects[i];
    if (0 === obj.name.indexOf('Kreutz'))
    { nK++;
      s += '<tr><td>' + obj.name +
'</td><td>' + new RA(obj.raHrs).toHTMLString() +
'</td><td>' + new Dec(obj.decDegs).toHTMLString() +
'</td><td>' + obj.rAU.toFixed(2) +
'</td><td>' + obj.deltaAU.toFixed(2) + '</td></tr>';
    }
  }
  if (nK > 0)
  { GD.elChart.innerHTML = s +'</table>';
    GD.elData.innerHTML = 'Scroll down for Kreutz table';
  }
}

function showObsList() { GD.elObsList.innerHTML = GD.obsList + '</table>'; }

function showPlot()
{ GD.g2 = GD.cnv.getContext('2d');
  GD.g2.font = FONT;
  GD.g2.fillStyle = NIGHT_COLOUR;
  GD.g2.fillRect(0, 0, IMWD, IMHT);
  drawEcliptic();
  drawScales();
  drawConstellations();
  drawHorizon();
  for (var i = 0; i < objects.length; i++) drawObject(objects[i]);
  if (null !== GD.cal) GD.cal.setDateCaption();
  if (null !== GD.nearest) showData();
}

function showUserText()
{ GD.elData.innerHTML =
'<p>Click the mouse near an object to see its details and further options here.</p>' +
'<p>Local twilight times can be found among the details for the Sun.</p>' +
'<p>We use a cookie on this page but only to store your latitude and longitude on ' +
'your own system, to avoid you having to set them every time.</p>' +
'<p>For further help scroll down and read the rest of this page. Question marks ' +
'among the controls here are links to relevant explanations.</p>' + DATA_REVISED;
}

function topoAdjust(jd, geoRaHrs, geoDecDegs, deltaAU)
{ var theta0Degs = toMeanSiderealTimeAtGreenwichDegs(jd);
  var _HDegs = in360(theta0Degs - GD.longDegs - geoRaHrs * 15);
  var sinH = sinDegs(_HDegs);
  var cosH = cosDegs(_HDegs);
  var sinPi = sinDegs(8.794 / 3600.0) /deltaAU;
  var cosDec = cosDegs(geoDecDegs);
  var sinDec = sinDegs(geoDecDegs);
  var dRADegs = atan2Degs(-GD.rhoCosPhiDash * sinPi * sinH,
               cosDec - GD.rhoCosPhiDash * sinPi * cosH);
  var cosDRA = cosDegs(dRADegs);
  var decDegs = atan2Degs((sinDec - GD.rhoSinPhiDash * sinPi) * cosDRA,
                cosDec - GD.rhoCosPhiDash * sinPi * cosH);
  var raHrs = in360(geoRaHrs * 15 + dRADegs) / 15;
  return {raHrs:raHrs, decDegs:decDegs};
}

// J.Meeus AA Chapter 12
function toMeanSiderealTimeAtGreenwichDegs(jd)
{ var dJD = jd - JD2000;
  var _T = dJD / 36525;
  var _Tsq = _T * _T;
  return in360(280.46061837 + 360.98564736629 * dJD +
    0.000387933 * _Tsq - (_T * _Tsq) / 38710000);
}

function xFromRaHours(raHrs)
{ var dx = PX_PER_DEG * in360((sunL.raHrs - raHrs) * 15);
  if (GD.northView) return X0 + dx;
  return X0 + IMWD - dx;
}

function yFromDecDegs(decDegs)
{ var dy = PX_PER_DEG * decDegs;
  if (GD.northView) return Y0 - dy;
  return Y0 + dy;
}

function drawEcliptic()
{ GD.g2.strokeStyle = ECLIPTIC_COLOUR;
  GD.g2.beginPath();
  var raHr = sunL.raHrs;
  var decDegs = GD.eclipticObliquityDegs * sinDegs(raHr * 15);
  var x = xFromRaHours(raHr), y = yFromDecDegs(decDegs);
  var prevX = x;
  GD.g2.moveTo(x, y);
  for (var i = 0; i < 48; i++)
  { raHr -= 0.5;
    decDegs = GD.eclipticObliquityDegs * sinDegs(raHr * 15);
    x = xFromRaHours(raHr); y = yFromDecDegs(decDegs);
    if (Math.abs(x - prevX) < HALF_IMWD)
    { GD.g2.lineTo(x, y);
    }
    prevX = x;
  }
  GD.g2.stroke();
}

const	CONSTELLATIONS = [
['And',1,40],['Phe',1,-45],['Cet',1.4,-10],['Scl',.7,-32],['Ari',2.7,21],
['For',2.8,-32],['Per',3.7,43],['Tau',4.1,15],['Eri',4,-20],['Ori',5.7,5],
['Lep',5.7,-20],['Col',5.9,-36],['Aur',6,41],['Gem',7.1,22],['CMi',7.7,0],
['Mon',7.1,-6],['CMa',6.8,-22],['Pup',8,-30],['Cnc',8.8,20],['Hya',9,-10],
['LMi',10.5,35],['Leo',10.7,18],['Sex',10.2,-1],['Ant',10.3,-33],
['Crt',11.5,-17],['Crv',12.4,-19],['Vir',13,0],['Com',12.8,22],['Cen',13,-40],
['CVn',13.2,40],['Boo',14.2,24],['Lib',15.2,-13],['CrB',15.9,32],
['Sco',16.2,-28],['Her',17.4,30],['Oph',17.2,-6],['Lyr',18.8,38],
['CrA',18.8,-40],['Sgr',19.2,-28],['Aql',19.8,2],['Vul',20.2,25],
['Del',20.7,12],['Cyg',20.8,40],['Cap',21,-19],['PsA',22.2,-30],
['Aqr',22.8,-12],['Peg',22.7,23],['Psc',.5,8]];

function drawConstellations()
{ GD.g2.fillStyle = CONSTELLATION_COLOUR;
  for (var i = 0; i < CONSTELLATIONS.length; i++)
  { GD.g2.fillText(CONSTELLATIONS[i][0],
      xFromRaHours(CONSTELLATIONS[i][1]) - 15,
      yFromDecDegs(CONSTELLATIONS[i][2]) - 3);
  }
}

function drawSun()
{ var dy = PX_PER_DEG * sunL.decDegs;
  if (GD.northView) dy = -dy;
  var y = Y0 + dy;
  sunL.plotPt = new Point(X0, y);
  fillCircle(GD.g2, X0, y, SUN_RADIUS, sunL.colour);
  sunR.plotPt = new Point(X0 + IMWD, y);
  fillCircle(GD.g2, X0 + IMWD, y, SUN_RADIUS, sunR.colour);
}

function drawMoon()
{ var x = xFromRaHours(moon.raHrs);
  var y = yFromDecDegs(moon.decDegs);
  moon.plotPt = new Point(x, y);
/* Moon phase info
Elong phaseDegs	illumFrac
  0	 180 0.0
 90	  90 0.5
180	 	 0 1.0
270	 -90 0.5
360	-180 0.0*/
  // Complete outline of moon:
  if (moon.phaseDegs > 150 || moon.phaseDegs < -150)
  { strokeCircle(GD.g2, x, y, SUN_RADIUS, moon.colour);
  }
  var r2 = SUN_RADIUS * SUN_RADIUS;
  var xr, xd, xx, yy, yr;
  var ff = moon.illumFrac;
  for (yr = -SUN_RADIUS; yr <= SUN_RADIUS; yr++)
  { xr = Math.sqrt(r2 - yr * yr);
    xd = xr * 2;
    yy = Math.round(y + yr);
    if ((GD.northView && moon.phaseDegs >= 0)
     || (!GD.northView && moon.phaseDegs < 0))
    { xx = Math.round(x + xr);
      drawLine(GD.g2, xx, yy, Math.round(xx - ff * xd), yy, moon.colour);
    }
    else
    { xx = Math.round(x - xr);
      drawLine(GD.g2, xx, yy, Math.round(xx + ff * xd), yy, moon.colour);
} } }

function drawObject(obj)
{ switch (obj.kind)
  {
  case 'S': drawSun(); break;
  case 'M': drawMoon(); break;
  default:
    var x = xFromRaHours(obj.raHrs);
    var y = yFromDecDegs(obj.decDegs);
    obj.plotPt = new Point(x, y);
    GD.g2.fillStyle = obj.colour;
    if (obj.decDegs > DEC_MAX)
    { drawLine(GD.g2, x, SCALE_HT, x, SCALE_HT * 2, obj.colour);
      GD.g2.fillText(obj.symbol, x + 4, SCALE_HT * 2);
    }
    else
    if (obj.decDegs < DEC_MIN)
    { drawLine(GD.g2, x, IMHT, x, IMHT - SCALE_HT * 2, obj.colour);
      GD.g2.fillText(obj.symbol, x + 4, IMHT - SCALE_HT);
    }
    else
    { fillCircle(GD.g2, x, y, 2, obj.colour);
      if (obj.decDegs > 0)
      { GD.g2.fillText(obj.symbol, x - 4, y - 6);
      }
      else
      { GD.g2.fillText(obj.symbol, x - 4, y + 16);
} } } }

function drawScales()
{ //Equator & meridian:
  drawLine(GD.g2, X0, Y0, X0 + IMWD, Y0, EQUATOR_COLOUR);
  GD.g2.fillStyle = EQUATOR_COLOUR;
  GD.g2.fillText('equator', X0 + SUN_DIAMETER, Y0 - 2);
  drawLine(GD.g2, X0 + HALF_IMWD, 0, X0 + HALF_IMWD, IMHT, EQUATOR_COLOUR);
  //Dec scale left & right:
  for (var dec = DEC_MIN; dec <= DEC_MAX; dec += 10)
  { var y = yFromDecDegs(dec);
    drawLine(GD.g2, 0, y, HALF_SCALE_HT, y, SCALE_COLOUR);
    drawLine(GD.g2, IMWD - HALF_SCALE_HT, y, IMWD - 1, y, SCALE_COLOUR);
  }
  //RA scale top:
  { var upperY = UPPER_SCALE_Y0 + SCALE_HT;
    for (var raHrs = 0; raHrs < 24; raHrs += 2)
    { var x = xFromRaHours(raHrs);
      if (x > 16 && x < IMWD - 10)
      { drawLine(GD.g2, x, UPPER_SCALE_Y0, x, upperY, SCALE_COLOUR);
        GD.g2.fillText(raHrs + 'h', x + 4, upperY);
    } }
    GD.g2.fillText('RA', X0 + 2, upperY);
  }
  //Elongation scale at bottom:
  { var lowerY = IMHT - 2;
    for (var degs = 30; degs < 360; degs += 30)
    { x = Math.round(PX_PER_DEG * degs);
      drawLine(GD.g2, x, LOWER_SCALE_Y0, x, lowerY, SCALE_COLOUR);
      if (GD.northView)
      { GD.g2.fillText((360 - degs) + '\u00b0', x + 4, lowerY);
      }
      else
      { GD.g2.fillText(degs + '\u00b0', x + 4, lowerY);
    } }
    GD.g2.fillText('E elongation', X0 + 2, lowerY);
} }

function drawHorizon()//& twilight
{ var y, dx, dy;
	var colatitudeDegs = 90.0 - GD.latDegs;
  if (!GD.northView) colatitudeDegs = -colatitudeDegs;
  //Within (ant)arctic circle:
  if (90 < Math.abs(GD.latDegs - sunL.decDegs) //(ant)arctic summer
   || 90 < Math.abs(GD.latDegs + sunL.decDegs))//(ant)arctic winter
  { y = Y0;//Put horizon through end of equator instead of Sun
  }
  else if (GD.northView)
  { y = Y0 - PX_PER_DEG * sunL.decDegs;
  }
  else
  { y = Y0 + PX_PER_DEG * sunL.decDegs;
  }
  dx = HORIZON_LENGTH * cosDegs(colatitudeDegs);
  dy = HORIZON_LENGTH * sinDegs(colatitudeDegs);
  drawLine(GD.g2, -dx, y - dy, dx, y + dy, HORIZON_COLOUR);
  drawLine(GD.g2, IMWD - 1 + dx, y - dy, IMWD - 1 - dx, y + dy, HORIZON_COLOUR);
  if (twilightDegs > 0.0)
  { var twilightOffset = twilightDegs * PX_PER_DEG;
    var dxTwilight = -twilightOffset * sinDegs(colatitudeDegs);
    var dyTwilight = twilightOffset * cosDegs(colatitudeDegs);
    if (!GD.northView)
    { dxTwilight = -dxTwilight;
      dyTwilight = -dyTwilight;
    }
    drawLine(GD.g2, -dx - dxTwilight, y - dy - dyTwilight,
      dx - dxTwilight, y + dy - dyTwilight, TWILIGHT_COLOUR);
    drawLine(GD.g2, IMWD - 1 + dx + dxTwilight, y - dy - dyTwilight,
      IMWD - 1 - dx + dxTwilight, y + dy - dyTwilight, TWILIGHT_COLOUR);
} }

function Point(x, y)
{ this.x = x;
  this.y = y;
}

Point.prototype.distance = function(other)
{ var dx = this.x - other.x;
  var dy = this.y - other.y;
  return Math.sqrt(dx * dx + dy * dy);
};

//Set these fields of obj before calling this: h, g, rAU, deltaAU, phaseDegs
function calcMv(obj)
{ if (obj.g === 0) return 0;
  switch (obj.kind)
  {
  case 'P':
  case 'A':
    var logtanPhase2 = Math.log(tanDegs (0.5 * obj.phaseDegs));
    var tanB1 = Math.exp(logtanPhase2 * 0.63);
    var tanB2 = Math.exp(logtanPhase2 * 1.22);
    var phi1 = Math.exp(-3.33 * tanB1);
    var phi2 = Math.exp(-1.87 * tanB2);
    var hAlpha = obj.h - 2.5 * log10((1 - obj.g) * phi1 + obj.g * phi2);
    return hAlpha + 5 * log10(obj.rAU * obj.deltaAU);
  case 'C': return obj.h + 5 * log10(obj.deltaAU) + obj.g * log10(obj.rAU);
  }
  return 0;
}

/* Returns an array of 3 fractions of a day, representing respectively the
local times of rising, transit and setting for the given object altitude (h0)
and latitude. Uses the method in J.Meeus AA (2nd Edn) Chapter 15.
The JD for which these are required is NOT assumed to be for
0h UT - any JD is adjusted as necessary. The rising and setting times are set
to -1.0 if the point is circumpolar at the given latitude.
This version is really intended for finding twilight times, where
h0 is -6, -12 or -18 for civil, nautical or astronomical twilight. */
function calcRiseTransitSet(jd, h0Degs, raHrs, decDegs)
{ var theta0Degs = meanSiderealTimeAtGreenwichDegs(jd);
  var sinPhiSinDelta = sinDegs(GD.latDegs) * sinDegs(decDegs);
  var cosH0Degs = (sinDegs(h0Degs) - sinPhiSinDelta) /
    (cosDegs(GD.latDegs) * cosDegs(decDegs));
  var _H0Degs = acosDegs(cosH0Degs);
  var m0 = (raHrs * 15 + GD.longDegs - theta0Degs) / 360;
  var m1, m2;
  if (cosH0Degs < -1.0 || cosH0Degs > 1.0) { m1 = m2 = -1.0; }
  else
  { var _H0360 = _H0Degs / 360.0;
    m1 = in01(m0 - _H0360);
    m2 = in01(m0 + _H0360);
  }
  return [m1, in01(m0), m2];//day fractions
}

function in01(x)
{ if (x > 1.0) return x - 1.0;
  if (x < 0.0) return x + 1.0;
  return x;
}

function calcSepnDegs(obj1, obj2)
{ var dRaRad = (obj2.raHrs - obj1.raHrs) * HRS_TO_RADS;
  var cosDa = Math.cos(dRaRad);
  var sinDa = Math.sin(dRaRad);
  var cosD1 = cosDegs(obj1.decDegs);
  var sinD1 = sinDegs(obj1.decDegs);
  var cosD2 = cosDegs(obj2.decDegs);
  var sinD2 = sinDegs(obj2.decDegs);
  var x = cosD1 * sinD2 - sinD1 * cosD2 * cosDa;
  var y = cosD2 * sinDa;
  var z = sinD1 * sinD2 + cosD1 * cosD2 * cosDa;
  return atan2Degs(Math.sqrt(x * x + y * y), z);
}

//Meeus AA p87
function meanSiderealTimeAtGreenwichDegs(jd)
{ var jd0 = Math.round(jd) - 0.5;//Converts to 0h UT
  var t = (jd0 - 2451545) / 36525;
  var t2 = t * t;
  return in360(100.46061837 + 36000.770053608 * t +
    (0.000387933 - t / 38710000.0) * t2);
}

//Set parameters for precessing. Meeus AA p134
function Precessor(fromJD, toJD)
{ var _T = (fromJD - JD2000) / 36525;
  var _T2 = _T * _T;
  var t = (toJD - fromJD) / 36525;
  var t2 = t * t;
  var t3 = t2 * t;
  var secToDeg = 1 / 3600;
  this.zetaDegs = ((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
    (0.30188 - 0.000344 * _T) * t2 + 0.017998 * t3) * secToDeg;
  this.zDegs = ((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
    (1.09468 + 0.000066 * _T) * t2 + 0.018203 * t3) * secToDeg;
  var thetaDegs = ((2004.3109 - 0.85330 * _T - 0.000217 * _T2) * t -
    (0.42665 + 0.000217 * _T) * t2 - 0.041833 * t3) * secToDeg;
  this.cosTheta = cosDegs(thetaDegs);
  this.sinTheta = sinDegs(thetaDegs);
}

//Returns {raHrs, decDegs}. Meeus AA p134
Precessor.prototype.precess = function(raHrs, decDegs)
{ var cosDec = cosDegs(decDegs);
  var sinDec = sinDegs(decDegs);
  var raZetaDegs = raHrs * 15 + this.zetaDegs;
  var cosRaZeta = cosDegs(raZetaDegs);
  var sinRaZeta = sinDegs(raZetaDegs);
  var a = cosDec * sinRaZeta;
  var b = this.cosTheta * cosDec * cosRaZeta - this.sinTheta * sinDec;
  var c = this.sinTheta * cosDec * cosRaZeta + this.cosTheta * sinDec;
  return { raHrs:in360(atan2Degs(a, b) + this.zDegs) / 15, decDegs:asinDegs(c) };
};

function getMousePoint(ev)
{	if (ev.pageX || ev.pageY)
    return new Point (ev.pageX - GD.cnv.offsetLeft, ev.pageY - GD.cnv.offsetTop);
	return new Point (ev.clientX + document.body.scrollLeft +
    document.documentElement.scrollLeft - GD.cnv.offsetLeft,
    ev.clientY + document.body.scrollTop  +
    document.documentElement.scrollTop  - GD.cnv.offsetTop);
}

function handleClick(event)
{ var pt = getMousePoint(event);
  GD.nearest = getNearest(pt);
  showData();
}

function handleMove(event)
{ var pt = getMousePoint(event);
  var nearest = getNearest(pt);
  if (null !== nearest)
  { showPlot();
    GD.g2.fillStyle = '#fff';
    var plotX = pt.x + 4;
    if (pt.x > HALF_IMWD) plotX -= 40;
    GD.g2.fillText(nearest.name, plotX, pt.y - 4);
} }

function getNearest(pt)
{ var minD = 10000;
  var nearest = null;
  for (var i = 0; i < objects.length; i++)
  { var obj = objects[i];
    var d = pt.distance(obj.plotPt);
    if (d < minD)
    { minD = d;
      nearest = obj;
  } }
  if (minD < 50) return nearest;
  showPlot();//Clear label
  return null;
}