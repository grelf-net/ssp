'use strict';
const JD2000 = 2451545.0;

/** Abstract - to be extended for each planet */
function VSOP87Body()
{ this.name = null;
  this.deltaAU = 0;
  this.observerJED = 0;
  this.longitudeHeliocentricDegs = 0;
  this.latitudeHeliocentricDegs = 0;
  this.rAU = 0;
}

VSOP87Body.prototype.calcPosition = function(jed)
{ var tauMillennia = (jed - JD2000) / 365250.0;
  this.longitudeHeliocentricDegs = in360(this.calcLDegs(tauMillennia));
  this.latitudeHeliocentricDegs = this.calcBDegs(tauMillennia);
  this.rAU = this.calcRAU(tauMillennia);
};

// Override:
VSOP87Body.prototype.calcLDegs = function(tau) {};
VSOP87Body.prototype.calcBDegs = function(tau) {};
VSOP87Body.prototype.calcRAU = function(tau) {};

/** Sum series of coefficients as given in Appendix III of Astronomical
  * Algorithms by Jean Meeus.
  * Use is explained in Chapter 32 of the same book. */
VSOP87Body.prototype.sumSeries = function(coefficients, tauMillennia)
{ var sum = 0.0;
  var coeffsLength = coefficients.length;
  var nRows = coeffsLength / 4;
  for (var i = coeffsLength - 4, row = nRows; i >= 0; i -= 4, row--)
  { if (coefficients[i] !== row)
    { alert('Wrong row number in coefficients array');
      // Slight protection against data transcription errors
    }
    sum += coefficients[i + 1] * Math.cos(coefficients[i + 2] +
            tauMillennia * coefficients[i + 3]);
    // A * cos(B + Ct)
  }
  return sum;
};

VSOP87Body.prototype.getHeliocentricCoordinates = function()
{ var cosB = cosDegs (this.latitudeHeliocentricDegs);
  var sinB = sinDegs (this.latitudeHeliocentricDegs);
  var cosL = cosDegs (this.longitudeHeliocentricDegs);
  var sinL = sinDegs (this.longitudeHeliocentricDegs);
  var rAU = this.rAU;
  var x = rAU * cosB * cosL;
  var y = rAU * cosB * sinL;
  var z = rAU * sinB;
  return [x, y, z];
};

VSOP87Body.prototype.getEclipticalGeocentricCoordinates = function(earth)
{ var cosB = cosDegs(this.latitudeHeliocentricDegs);
  var sinB = sinDegs(this.latitudeHeliocentricDegs);
  var cosL = cosDegs(this.longitudeHeliocentricDegs);
  var sinL = sinDegs(this.longitudeHeliocentricDegs);
  var rAU = this.rAU;
  var cosEarthB = cosDegs(earth.latitudeHeliocentricDegs);
  var sinEarthB = sinDegs(earth.latitudeHeliocentricDegs);
  var cosEarthL = cosDegs(earth.longitudeHeliocentricDegs);
  var sinEarthL = sinDegs(earth.longitudeHeliocentricDegs);
  var rEarthAU = earth.rAU;
  var x = rAU * cosB * cosL - rEarthAU * cosEarthB * cosEarthL;
  var y = rAU * cosB * sinL - rEarthAU * cosEarthB * sinEarthL;
  var z = rAU * sinB - rEarthAU * sinEarthB;
  return [x, y, z];
};

/** Gets apparent position at the given epoch. */
VSOP87Body.prototype.getSkyPoint = function(earth, epoch)
{ var pt = this.getSkyPointNow(earth);
  pt.changeEpoch(epoch);
  return pt;
};

/** Gets apparent position at mean equinox of date. */
VSOP87Body.prototype.getSkyPointNow = function(earth)
{ var jXYZ = this.getEclipticalGeocentricCoordinates(earth);
  var dx = jXYZ[0];
  var dy = jXYZ[1];
  var dz = jXYZ[2];
  // Get ecliptical longitude and latitude:
  var lambdaRads = Math.atan2(dy, dx);
  var betaRads = Math.atan2(dz, Math.sqrt (dx * dx + dy * dy));
  var dYears = (this.observerJED - JD2000) / 365.25;
  var epoch = new Epoch(2000.0 + dYears);
  var eclipticObliquityDegs = calcEclipticObliquityDegs(dYears/10000);
  //Rotate from ecliptic to equatorial coordinates to get RA and Dec:
  var cosEpsilon = cosDegs(eclipticObliquityDegs);
  var sinEpsilon = sinDegs(eclipticObliquityDegs);
  var sinLambda = Math.sin(lambdaRads);
  var cosLambda = Math.cos(lambdaRads);
  var sinBeta = Math.sin(betaRads);
  var cosBeta = Math.cos(betaRads);
  var raDegs = in360(atan2Degs(sinLambda * cosEpsilon -
                  sinBeta * sinEpsilon / cosBeta, cosLambda));
  var decDegs = asinDegs(sinBeta * cosEpsilon +
                  cosBeta * sinEpsilon * sinLambda);
  return new SkyPoint(new RA(degs2hours(raDegs)), new Dec(decDegs), epoch);
};
