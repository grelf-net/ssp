'use strict';

function Planet()
{ VSOP87Body.call(this);
  this.earth = null;
}
Planet.prototype = Object.create(VSOP87Body.prototype);
Planet.prototype.constructor = Planet;

Planet.prototype.getData = function()
{ var xyz = this.getEclipticalGeocentricCoordinates(this.earth);
  var skyPt = this.getSkyPoint(this.earth, new Epoch(2000));
  return this.rAU + ',' + // radiusVectorAU
    this.deltaAU + ',' + // distanceFromEarthAU
    xyz[0] + ',' + xyz[1] + ',' + xyz[2] + ',' +
    skyPt.ra.hours + ',' +
    skyPt.dec.degs + ',' +
    skyPt.epoch.toString() + ',';
}; // getData

const LIGHT_DAYS_PER_AU = 0.0057755183;

/** Utility to compute light time in days for a given distance in AU. */
Planet.prototype.lightTimeDays = function(distanceAU)
{ return LIGHT_DAYS_PER_AU * distanceAU;
}; // lightTimeDays

/** Recalculate the position, iterating on the light time. */
Planet.prototype.adjustForLightTime = function(earth)
{ const EPSILON = 1.0e-12;
  var _LDegs = 0.0;
  var _BDegs = 0.0;
  var rAU = 0.0;
  var _DeltaAU = 0.0;
  var iter = 1;
  do
  { _LDegs = this.longitudeHeliocentricDegs;
    _BDegs = this.latitudeHeliocentricDegs;
    rAU = this.rAU;
    _DeltaAU = this.deltaAU;
    var xyz = this.getEclipticalGeocentricCoordinates(earth);
    this.deltaAU =
            Math.sqrt(xyz[0] * xyz[0] + xyz[1] * xyz[1] + xyz[2] * xyz[2]);
    this.calcPosition(this.observerJED -
            this.lightTimeDays(this.deltaAU));
    iter++;
  }
  while (EPSILON * _LDegs > Math.abs(_LDegs - this.longitudeHeliocentricDegs)
      && EPSILON * _BDegs > Math.abs(_BDegs - this.latitudeHeliocentricDegs)
      && EPSILON * rAU  > Math.abs(rAU - this.rAU)
      && EPSILON * _DeltaAU > Math.abs(_DeltaAU - this.deltaAU));
}; // adjustForLightTime
