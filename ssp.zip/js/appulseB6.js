'use strict';
const  APP = {maxSep:1, maxMag:14.5, found:[]};

function checkAppulses()
{ const ASTERS = [];
  GD.nearest = null;
  
  //1: Load asteroid data
  for (var i = 0; i < ASTEROIDS.length; i +=10)
  { var a = createAsteroid(ASTEROIDS[i]);
    if (null !== a)
    { ASTERS.push(a);
  } }

  //2: Get RA/Dec of each at JD:
  var jd = GD.cal.getJD(), n = ASTERS.length;
  var earth2000 = new EarthJ2000(jd);
  var xyz = earth2000.getHeliocentricCoordinates();
  var sunDxJ2000 = -xyz[0];
  var sunDyJ2000 = -xyz[1];
  var sunDzJ2000 = -xyz[2];
  var sunX = sunDxJ2000
            + 0.000000440360 * sunDyJ2000
            - 0.000000190919 * sunDzJ2000;
  var sunY = -0.000000479966 * sunDxJ2000
            + 0.917482137087 * sunDyJ2000
            - 0.397776982902 * sunDzJ2000;
  var sunZ =  0.397776982902 * sunDyJ2000
            + 0.917482137087 * sunDzJ2000;
  for (var i = 0; i < n; i++)
  { var obj = ASTERS[i];
    if (obj.getHeliocentricPositionAU) // In case not yet fully loaded
    { var xyz = obj.getHeliocentricPositionAU(jd); // sets rAU
      if (null !== xyz)
      { var dx = xyz.x + sunX;
        var dy = xyz.y + sunY;
        var dz = xyz.z + sunZ;
        obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
        var dLight = 0.0057755183 * obj.deltaAU; // days
        xyz = obj.getHeliocentricPositionAU (jd - dLight); // sets rAU
        obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
        var dot = dx * xyz.x + dy * xyz.y + dz * xyz.z;
        obj.phaseDegs = acosDegs(dot / (obj.rAU * obj.deltaAU));
        obj.decDegs = atan2Degs(dz, Math.sqrt(dx * dx + dy * dy));
        obj.raHrs = 12 * Math.atan2(dy, dx) / Math.PI;
        if (obj.raHrs < 0) obj.raHrs += 24;
        obj.mV = calcMv(obj).toFixed(1);
        if (GD.topocentric)
        { var adj = topoAdjust(jd, obj.raHrs, obj.decDegs, obj.deltaAU);
          obj.raHrs = adj.raHrs;
          obj.decDegs = adj.decDegs;
  } } } }

  //3: Find sky distances between each:
  var s = '<strong>Asteroids less than ' + APP.maxSep + '&deg; apart and '+
'magnitude &le; ' + APP.maxMag + ' at JD' + jd.toFixed(5) + '</strong> ' + 
'<input type="button" class="control" value="Settings" ' +
'onclick="appulseSettings()"/><br>';
  APP.found = [];
  for (var i = 0; i < n; i++)
  { var ai = ASTERS[i];
    if (ai.mV > APP.maxMag) continue;
    for (var j = i + 1; j < n; j++)
    { var aj = ASTERS[j];
      if (aj.mV > APP.maxMag) continue;
      var dRaDegs = hours2degs(ai.raHrs - aj.raHrs);
      var cosD1 = cosDegs(aj.decDegs);
      var cosD2 = cosDegs(ai.decDegs);
      var cosDa = cosDegs(dRaDegs);
      var sinD1 = sinDegs(aj.decDegs);
      var sinD2 = sinDegs(ai.decDegs);
      var sinDa = sinDegs(dRaDegs);
      var xx = cosD1 * sinD2 - sinD1 * cosD2 * cosDa;
      var yy = cosD2 * sinDa;
      var zz = sinD1 * sinD2 + cosD1 * cosD2 * cosDa;
      var sepnDegs = atan2Degs(Math.sqrt (xx * xx + yy * yy), zz);
      if (sepnDegs <= APP.maxSep)
      { APP.found.push({ra:ai.raHrs,
s:ai.symbol + ' ' + ai.name + ' ' + aToHTMLString(ai) + ' &amp; ' +
aj.symbol + ' ' + aj.name + ' ' + aToHTMLString(aj) + 
' (' + sepnDegs.toFixed(2) + '&deg;)',
name1:ai.name, name2:aj.name});
  } } }
  if (APP.found.length <= 0) s += 'None found';
  else//sort on RA:
  { APP.found.sort(function(a, b) { return (a.ra < b.ra) ? -1 : 1; });
    for (i = 0; i < APP.found.length; i++)
    { s += APP.found[i].s + '<input type="checkbox" id="app' + i +
'" onchange="appChecks()" title="Add to chart"><br>';
  } } 
  document.getElementById("appulse").innerHTML = s;
  showUserText();
}

function aToHTMLString(a)
{ var ra = new RA(a.raHrs), dec = new Dec(a.decDegs);
  return ra.toHTMLString() + ' ' + dec.toHTMLString() + ' mV' + a.mV;
}

function appulseSettings()
{ GD.elData.innerHTML = 
'<p><strong>Asteroid appulses</strong></p>' +
'<p>Max separation [0.5..3]&deg;: <input type="text" id="maxSep" maxlength="3" size="6"' +
'value="' + APP.maxSep + '" onchange="appSetMaxSep()"/><br/>' +
//'<input type="button" class="control" value="Set" onclick="appSetMaxSep()"/></p>' +
'<p>Max magnitude [12..15]: <input type="text" id="maxMag" maxlength="4" size="6"' +
'value="' + APP.maxMag + '" onchange="appSetMaxMag()"/><br/>' +
//'<input type="button" class="control" value="Set" onclick="appSetMaxMag()"/></p>' +
'<p><input type="button" class="control" value="List appulses" onclick="checkAppulses()"/></p>';
}

function appSetMaxSep()
{ var el = document.getElementById("maxSep");
  var maxSep = parseFloat(el.value);
  if (maxSep >= 0.5 && maxSep <= 3) APP.maxSep = maxSep;
}

function appSetMaxMag()
{ var el = document.getElementById("maxMag");
  var maxMag = parseFloat(el.value);
  if (maxMag >= 12 && maxMag <= 15) APP.maxMag = maxMag;
}

function appChecks()
{ var a1 = null, a2 = null;
  for (var i = 0; i < APP.found.length; i++)
  { var el = document.getElementById("app" + i);
    if (el.checked)
    { var ast = APP.found[i];
      for (var j = 0; j < ASTEROIDS.length; j += 10)
      { if (ASTEROIDS[j].startsWith(ast.name1))
        { a1 = createAsteroid(ASTEROIDS[j]);
          if (null !== a1) addedObjects.push(a1);
        }
        if (ASTEROIDS[j].startsWith(ast.name2))
        { a2 = createAsteroid(ASTEROIDS[j]);
          if (null !== a2) addedObjects.push(a2);
  } } } }
  getData();
}

function appUncheckAll()
{ for (var i = 0; i < APP.found.length; i++)
  { var el = document.getElementById("app" + i);
    el.checked = false;
} }