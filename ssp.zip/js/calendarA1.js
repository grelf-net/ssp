'use strict';

const DAY_S = 86400, DAY_MS = DAY_S * 1000, JD_1970_0 = 2440587.5;

/* Parameters: default caption, a function name which may be null.
   The function is called whenever the date/time changes */
function Calendar(caption, action)
{ this.caption = caption;
  this.action = action;
  this.date = new Date();
  this.form = document.forms["calendar"];
  this.setFields();
}

Calendar.prototype.setFields = function()
{ this.form.year.value = "" + this.date.getUTCFullYear();
  this.form.month.options[this.date.getUTCMonth()].selected = true;
  this.form.hour.value = "" + this.date.getUTCHours();
  this.form.minute.value = "" + this.date.getUTCMinutes();
  this.form.second.value = "" + this.date.getUTCSeconds();
  this.setDays();
  this.action();
};

Calendar.prototype.setDays = function()
{ var month = this.date.getUTCMonth(); // Jan = 0
  var day = this.date.getUTCDate();
  var first = new Date(this.date.getUTCFullYear(), month, day, 12, 0, 0, 0);
  first.setUTCDate(1); // The first day of the month
  var dayOfWeek = first.getUTCDay(); // Sunday = 0;
  for (var i = 0; i < dayOfWeek; i++)
  { document.getElementById(i.toString()).innerHTML = "";
  }
  var daysInMonth = 31;
  switch (month + 1)
  {
    case 4:
    case 6:
    case 9:
    case 11: daysInMonth = 30; break;
    case 2:
      daysInMonth = 28;
      var yr = this.date.getUTCFullYear();
      if (yr % 400 === 0 // Added 13.11.25
       || (yr % 4 === 0 && yr % 100 !== 0))
      { daysInMonth = 29;
      }
      break;
  }
  var j;
  for (i = dayOfWeek, j = 1; i < dayOfWeek + daysInMonth; i++, j++)
  { var el = document.getElementById(i.toString());
    if (j === this.date.getUTCDate())
    { el.innerHTML =
'<input type="button" id="day" class="button"' +
' onclick="GD.cal.setDate(' + j + ')" value="' + j + '">';
    }
    else
    { el.innerHTML =
'<input type="button" class="button"' +
' onclick="GD.cal.setDate(' + j + ')" value="' + j + '">';
    }
  }
  for (i = dayOfWeek + daysInMonth; i < 42; i++)
  { document.getElementById(i.toString()).innerHTML = "";
  }
  this.form.jdinput.value = this.getJD().toPrecision(12);
  if (this.action !== null)
  { this.action();
  }
};

Calendar.prototype.setCaption = function(caption)
{ document.getElementById("calhead").innerHTML = caption;
};

Calendar.prototype.setDateCaption = function()
{ document.getElementById("calhead").innerHTML =
    this.date.getUTCFullYear() + " " +
    this.form.month.options[this.date.getUTCMonth()].value + " " +
    this.date.getUTCDate() + " " +
    this.date.getUTCHours() + ":" +
    this.date.getUTCMinutes() + ":" +
    this.date.getUTCSeconds() + " UTC";
};

Calendar.prototype.setDate = function(day)
{ this.date.setUTCDate(day);
  this.setDays();
};

Calendar.prototype.decHour = function()
{ var hour = this.date.getUTCHours();
  if (hour > 0)
  { hour--;
    this.date.setUTCHours(hour);
    this.setFields();
  }
  else
  { hour = 23;
    this.date.setUTCHours(hour);
    this.setFields();
    this.decJD();
  }
};

Calendar.prototype.incHour = function()
{ var hour = this.date.getUTCHours();
  if (hour < 23)
  { hour++;
    this.date.setUTCHours(hour);
    this.setFields();
  }
  else
  { hour = 0;
    this.date.setUTCHours(hour);
    this.setFields();
    this.incJD();
  }
};

Calendar.prototype.setHour = function()
{ this.date.setUTCHours(this.form.hour.value, this.form.minute.value, 0, 0);
  this.setFields();
};

Calendar.prototype.getJD = function()
{ var ms1970 = this.date.getTime(); // ms since 1970.0 UT
  return ms1970 / DAY_MS + JD_1970_0;
};

Calendar.prototype.decJD = function()
{ var jd = this.form.jdinput.value;
  jd--;
  this.form.jdinput.value = jd.toPrecision(12);
  this.setJD();
};

Calendar.prototype.incJD = function()
{ var jd = this.form.jdinput.value;
  jd++;
  this.form.jdinput.value = jd.toPrecision(12);
  this.setJD();
};

Calendar.prototype.setJD = function()
{ var jd = this.form.jdinput.value;
  var ms1970 = (jd - JD_1970_0) * DAY_MS;
  this.date = new Date(ms1970);
  this.setFields();
};

Calendar.prototype.decMinute = function()
{ var minute = this.date.getUTCMinutes();
  if (minute > 0)
  { minute--;
    this.date.setUTCMinutes(minute);
    this.setFields();
  }
  else
  { minute = 59;
    this.date.setUTCMinutes(minute);
    this.decHour();
  }
};

Calendar.prototype.incMinute = function()
{ var minute = this.date.getUTCMinutes();
  if (minute < 59)
  { minute++;
    this.date.setUTCMinutes(minute);
    this.setFields();
  }
  else
  { minute = 0;
    this.date.setUTCMinutes(minute);
    this.incHour();
  }
};

Calendar.prototype.setMinute = function()
{ this.date.setUTCMinutes(this.form.minute.value, 0, 0);
  this.setFields();
};

Calendar.prototype.decMonth = function()
{ var month = this.date.getUTCMonth();
  month--;
  if (month < 0)
  { month = 11;
    this.decYear();
  }
  this.date.setUTCMonth(month);
  this.setFields();
};

Calendar.prototype.incMonth = function()
{ var month = this.date.getUTCMonth();
  month++;
  if (month > 11)
  { month = 0;
    this.incYear();
  }
  this.date.setUTCMonth(month);
  this.setFields();
};

Calendar.prototype.setMonth = function()
{ this.date.setUTCMonth(this.form.month.selectedIndex);
  this.setFields();
};

Calendar.prototype.setNow = function()
{ this.date = new Date();
  this.setFields();
};

Calendar.prototype.decSecond = function()
{ var second = this.date.getUTCSeconds();
  if (second > 0)
  { second--;
    this.date.setUTCSeconds(second);
    this.setFields();
  }
  else
  { second = 59;
    this.date.setUTCSeconds(second);
    this.decMinute();
  }
};

Calendar.prototype.incSecond = function()
{ var second = this.date.getUTCSeconds();
  if (second < 59)
  { second++;
    this.date.setUTCSeconds(second);
    this.setFields();
  }
  else
  { second = 0;
    this.date.setUTCSeconds(second);
    this.incMinute();
  }
};

Calendar.prototype.setSecond = function()
{ this.date.setUTCSeconds(this.form.second.value);
  this.setFields();
};

Calendar.prototype.decYear = function()
{ var year = this.date.getUTCFullYear();
  year--;
  this.date.setUTCFullYear(year);
  this.setFields();
};

Calendar.prototype.incYear = function()
{ var year = this.date.getUTCFullYear();
  year++;
  this.date.setUTCFullYear(year);
  this.setFields();
};

Calendar.prototype.setYear = function()
{ this.date.setUTCFullYear(this.form.year.value);
  this.setFields();
};
