'use strict';

function khtest()
{	// input M: mean anomaly (known data)
  //       e: eccentricity of the hyperbolic orbit (known data) e > 1
	//       eps: tolerance
	// returns object with 3 properties: 
  //   ph1: hyperbolic anomaly
  //   resto1: residual
  //   i: number of iterations
	//
	// The solution is given in double precision for the SDG-code by using 
  // the Modified Newton-Rhapson method
	// Code developed in C by V. Raposo-Pulido and J. Peláez, 2018
	// Converted to Javascript by Graham Relf, July 2025
  
  // Result should be:
  // Eccentricity: +2.250000000000000000E+000
	// Mean anomaly: +4.020000000000000300E+001
	// Hyperbolic anomaly: +3.663967301879906400E+000
	// Residual: +0.000000000000000000E+000
	// Number of iterations:  2
	var eps = 2.22e-16,	e = 2.25,	M = 40.2;
  var result = hkepler_eq(M, e, eps);
  alert("Eccentricity: " + e +
      "\nMean anomaly: " + M +
      "\nHyperbolic anomaly: " + result.ph1 +
      "\n   (should be 3.663967301879906400)" +
      "\nResidual: " + result.resto1 +
      "\nNumber of iterations: " + result.i);
}