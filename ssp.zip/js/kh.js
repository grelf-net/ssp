//The KEPLERH program solves the Kepler equation for hyperbolic Keplerian orbits. The code is 
//collected in the following modules: Keplerh.c, polinomios25.c polinomios25Q.c and hyperk.h.
//The module main.c is a driver to check good operation of the program
//Copyright (C) 2018 by the UNIVERSIDAD POLITECNICA DE MADRID (UPM)  
//Authors: Virginia Raposo-Pulido and Jesus Pelaez
//Converted to Javascript by Graham Relf, July 2025 (files kh.js, khpp.js, khqq.js, khtest.js)
//
//This program is free software: you can redistribute it and/or modify it under the terms 
//of the GNU General Public License as published by //the Free Software Foundation, either 
//version 3 of the License, or (at your option) any later version.
//This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
//without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//See the GNU General Public License for more details: https://www.gnu.org/licenses/.

// keh_25(M0, e0, eps) provides the the starting seed for any Newton-Raphson algorithm
// Arguments:
// M0  mean anomaly (known data)
// e0  eccentricity of the hyperbolic orbit (e0 > 1)
// eps tolerance
// Returns S=sinh(H) (unknown of the Kepler equation)
function keh_25(M0, e0, eps)
{ var XV = new Array(51);
	var z, phi, tt, xi, i = 0, j, k;
	var e  = e0, M = M0;
  if (Math.abs(e - 1.0) <= 0.5 && Math.abs(M) < 0.25)//inside the singular corner 
  { z = gtotalh(M, e);	
    return(Math.sinh(z)); 
  }
  //ends of the 25 intervals associated with the 25 polynomials P:
	XV[0]  = 0;
	XV[1]  = -0.2 + 0.201336002541093987625568243010317373 * e;
	XV[2]  = -0.4 + 0.410752325802815508540210013844698104 * e;
  XV[3]  = -0.6 + 0.636653582148241271123454375465148319 * e;
  XV[4]  = -0.8 + 0.888105982187623006574717573189756981 * e;
  XV[5]  = -1.0 + 1.17520119364380145688238185059560082 * e;
	XV[6]  = -1.2 + 1.50946135541217269644289491125921093 * e;
  XV[7]  = -1.4 + 1.90430150145153405514212382769742631 * e;
  XV[8]  = -1.6 + 2.37556795320022969758455354439030725 * e;
  XV[9]  = -1.8 + 2.94217428809567977271710961629775564 * e;
  XV[10] = -2.0 + 3.62686040784701876766821398280126170 * e;
  XV[11] = -2.2 + 4.45710517053589352156881637051936233 * e;
  XV[12] = -2.4 + 5.46622921367609457443138377479405527 * e;
  XV[13] = -2.6 + 6.69473222839367825866130738120707085 * e;
  XV[14] = -2.8 + 8.19191835423591595325119731137053734 * e;
  XV[15] = -3.0 + 10.0178749274099018989745936194658281 * e;
  XV[16] = -3.2 + 12.2458839965654912141970922329098858 * e;
  XV[17] = -3.4 + 14.9653633887183436343401764511296270 * e;
  XV[18] = -3.6 + 18.2854553606153475958966014183740521 * e;
  XV[19] = -3.8 + 22.3394068607223287208896227032622527 * e;
  XV[20] = -4.0 + 27.2899171971277524489082715907938186 * e;
  XV[21] = -4.2 + 33.3356677320523319694048751468816484 * e;
  XV[22] = -4.4 + 40.7192956625325245016109361699722550 * e;
  XV[23] = -4.6 + 49.7371319030945875769059601966175554 * e;
	XV[24] = -4.8 + 60.7510938858429303641033771355589455 * e;
	XV[25] = -5.0 + 74.2032105777887589770094719960645656 * e;
  //ends of the 24 intervals associated with the 24 polynomials Q:
  XV[26] = 0.100166750019844025823729383521905024 * e - 0.1;
  XV[27] = 0.304520293447142618958435267005095229 * e - 0.3;
  XV[28] = 0.521095305493747361622425626411491559 * e - 0.5;
  XV[29] = 0.758583701839533503459874647592768154 * e - 0.7;
  XV[30] = 1.02651672570817527595833616197842235 * e - 0.9;
  XV[31] = 1.33564747012417677938478052357867844 * e - 1.1;
  XV[32] = 1.69838243729261580866757837422406835 * e - 1.3;
  XV[33] = 2.12927945509481749683438749467763165 * e - 1.5;
  XV[34] = 2.64563193383723255528348091262507841 * e - 1.7;
  XV[35] = 3.26816291152831718171575932929456328 * e - 1.9;
  XV[36] = 4.02185674215733408161554001720300250 * e - 2.1;
  XV[37] = 4.93696180554595850311383723155543542 * e - 2.3;
  XV[38] = 6.05020448103978732145032363835040319 * e - 2.5;
  XV[39] = 7.40626310606654217337122065930621505 * e - 2.7;
  XV[40] = 9.05956107469332685682315502164694588 * e - 2.9;
  XV[41] = 11.0764510395240377993798196445394570 * e - 3.1;
  XV[42] = 13.5378778766283237106863842027448534 * e - 3.3;
  XV[43] = 16.5426272876349976249567315290124982 * e - 3.5;
  XV[44] = 20.2112904167985255688457159280278653 * e - 3.7;
  XV[45] = 24.6911035970421847456447294987383451 * e - 3.9;
  XV[46] = 30.1618574609801041249726180050204907 * e - 4.1;
  XV[47] = 36.8431125702917979900023602980633864 * e - 4.3;
  XV[48] = 45.0030111519917856218096568056437152 * e - 4.5;
  XV[49] = 54.9690385875109015313183231905375222 * e - 4.7;
  XV[50] = 67.1411665509322802497701958639658740 * e - 4.9;
  while (M - XV[i] >= 0.0 && i < 26) i++; // identify the interval where M is located
  j = i - 1;
  if (j === 25) k = 25; // if j=25 M will be > XV[25] and case 25 will be applied (asymptotic expansion)
	else if (j === 0 && M < XV[26]) k = 0; // if M is outside the XVQ domain, the polynomials to be used are the given by P
	else if (j === 24 && M > XV[50]) k = 24;
	else if (M < XV[j + 26])
	{ if ((M - XV[j]) < (XV[j + 26] - M)) k = j;
		else k = j + 25;
	}
	else if (M > XV[j + 26])
	{	if ((M - XV[j + 26]) < (XV[j + 1] - M)) k = j + 26;
		else k = j;
	}
  switch (k) //get S=sinh(H) from the interpolating polynomials PPH:
  {
  case 0: z = PPH0_ke(e,M); break;
  case 1: z = PPH1_ke(e,M); break;
  case 2: z = PPH2_ke(e,M); break;
  case 3: z = PPH3_ke(e,M); break;
  case 4: z = PPH4_ke(e,M); break;
  case 5: z = PPH5_ke(e,M); break;
  case 6: z = PPH6_ke(e,M); break;
  case 7: z = PPH7_ke(e,M); break;
  case 8: z = PPH8_ke(e,M); break;
  case 9: z = PPH9_ke(e,M); break;
  case 10: z = PPH10_ke(e,M); break;
  case 11: z = PPH11_ke(e,M); break;
  case 12: z = PPH12_ke(e,M); break;
  case 13: z = PPH13_ke(e,M); break;
  case 14: z = PPH14_ke(e,M); break;
  case 15: z = PPH15_ke(e,M); break;
  case 16: z = PPH16_ke(e,M); break;
  case 17: z = PPH17_ke(e,M); break;
  case 18: z = PPH18_ke(e,M); break;
  case 19: z = PPH19_ke(e,M); break;
  case 20: z = PPH20_ke(e,M); break;
  case 21: z = PPH21_ke(e,M); break;
  case 22: z = PPH22_ke(e,M); break;
  case 23: z = PPH23_ke(e,M); break;
  case 24: z = PPH24_ke(e,M); break;
  case 25: //expansion when M >= XV[25] (S >= sinh(5))           
  { var le, l2,lm;
    le = Math.log(e);
    l2 = Math.log(2);
    lm = Math.log(M);
    tt = Math.sqrt(e * e + M * M);
    phi = (tt * (Math.log(tt + M) - le)) / ((tt - 1) * M);
    lm = Math.log (e / 2 / M);
    xi = -lm * lm / 2 / M / M / M;
    z = (M / e) * (1 + phi + xi);
  }
  break;
  //get S=sinh(H) from the interpolating polynomials QQH:
  case 26: z = QQH0_ke(e,M); break;
	case 27: z = QQH1_ke(e,M); break;
	case 28: z = QQH2_ke(e,M); break;
  case 29: z = QQH3_ke(e,M); break;
  case 30: z = QQH4_ke(e,M); break;
  case 31: z = QQH5_ke(e,M); break;
  case 32: z = QQH6_ke(e,M); break;
  case 33: z = QQH7_ke(e,M); break;
	case 34: z = QQH8_ke(e,M); break;
  case 35: z = QQH9_ke(e,M); break;
  case 36: z = QQH10_ke(e,M); break;
  case 37: z = QQH11_ke(e,M); break;
	case 38: z = QQH12_ke(e,M); break;
	case 39: z = QQH13_ke(e,M); break;
	case 40: z = QQH14_ke(e,M); break;
	case 41: z = QQH15_ke(e,M); break;
	case 42: z = QQH16_ke(e,M); break;
	case 43: z = QQH17_ke(e,M); break;
	case 44: z = QQH18_ke(e,M); break;
	case 45: z = QQH19_ke(e,M); break;
	case 46: z = QQH20_ke(e,M); break;
	case 47: z = QQH21_ke(e,M); break;
	case 48: z = QQH22_ke(e,M); break;
	case 49: z = QQH23_ke(e,M); break;
	default: z = 0;
	}
	return z;
}

// Functions
//   double intermedioh(double M, double e)
//   double nuh_as (double sigma0, double epsilon)
// control the development of intermedioh in the singular corner

function nuh_as(sigmao, epsilon)
{ var t1, t10, t12, t17, t18, t2, t20, t25, t26, t34, t42, t44, t5, t55, t60, t73;
  t1 = sigmao * sigmao;
  t2 = t1 * sigmao;
  t5 = t1 + 0.2e1;
  t10 = t1 * t1;
  t12 = t10 * t1;
  t17 = t5 * t5;
  t18 = t17 * t5;
  t20 = epsilon * epsilon;
  t25 = t10 * t10;
  t26 = t25 * t1;
  t34 = t17 * t17;
  t42 = t25 * t12;
  t44 = t25 * t10;
  t55 = t20 * t20;
  t60 = t25 * t25;
  t73 = t34 * t34;
  return(sigmao - 0.166666666666666666666667e-1 * t2 * (t1 + 0.20e2) / t5 * epsilon + 0.714285714285714285714286e-3 * t10 * sigmao * (t12 + 0.25e2 * t10 + 0.340e3 * t1 + 0.840e3) / t18 * t20 - 0.793650793650793650793651e-5 * t10 * t2 * (0.5e1 * t26 + 0.166e3 * t25 + 0.2505e4 * t12 + 0.28240e5 * t10 + 0.124100e6 * t1 + 0.180000e6) / t34 / t5 * t20 * epsilon + 0.644197072768501339929911e-8 * t25 * sigmao * (0.387e3 * t42 + 0.16172e5 * t44 + 0.306228e6 * t26 + 0.3619848e7 * t25 + 0.35945312e8 * t12 + 0.205356480e9 * t10 + 0.568176000e9 * t1 + 0.603680000e9) / t34 / t18 * t55 - 0.477183016865556548096231e-11 * t25 * t2 * (0.35203e5 * t60 * t1 + 0.1768558e7 * t60 + 0.40930516e8 * t42 + 0.582574720e9 * t44 + 0.5917801960e10 * t26 + 0.53311645600e11 * t25 + 0.348404653600e12 * t12 + 0.1361270272000e13 * t10 + 0.2820160000000e13 * t1 + 0.2400448512000e13) / t73 / t5 * t55 * epsilon);
}

function intermedioh(M, e)
{ var epsilon, chi, sigma0, sdos, s, L;
	epsilon  = e - 0.1e1;
	chi = M / Math.sqrt(epsilon * epsilon * epsilon);
	L = Math.sqrt(8 + 9 * chi * chi);// is Lambda
	s = Math.pow(L + 3 * chi, 1 / 3); // is T
	sdos = s * s;
	sigma0 = 6 * chi / (2 + sdos + 4 / sdos);
	return Math.sqrt(epsilon) * nuh_as(sigma0, epsilon);
}

// double gtotalh(double M, double e);
// computes the seed provided to the modified Newton-Raphson in the singular corner
// Arguments:
//   M mean anomaly
//   e eccentricity
// Returns S=sinh(H) which is given as seed to the N-R
function gtotalh(M, e)
{ return intermedioh(M, e);
}

function FCT(S, x, e)
{ return (x + Math.log(S + Math.sqrt(S * S + 1))) / e;
}

function gtotalhDOS(M, e)
{ var n = 10, i, S, u;
	for (i = 0; i < n; i++)
	{	if (i === 0) u = M / e;
		else u = FCT(S, M, e);
		S = u;
	}
	return S;
}

function gtotalhTRES(M, e)
{ var n, i, S, u, z, le, l2, lm, tt, phi, xi;
	le = Math.log(e);
	l2 = Math.log(2);
	lm = Math.log(M);
	tt = Math.sqrt(e * e + M * M);
	phi = (tt * (Math.log(tt + M) - le)) / ((tt - 1.0) * M);
	xi = (-1 / (2 * Math.pow(M, 3))) * (Math.pow(le - l2, 2) + lm * (lm + 2 * (l2 - le)));
	z = (M / e) * (1 + phi + xi);
	n = 10;
	console.log("M = " + M + " e = " + e);
	for (i = 0; i < n; i++)
	{	if (i === 0) u = z;
		else u = FCT(S, M, e);
		S = u;
		console.log("S = " + S);
	}
	return S;
}

// double *FKEH(double M, double e, double u, double *caja)     
// calculates the function of the kepler equation f(u)= u-log(u+sqrt(1+pow(u,2)))/e -M/e
// and its first two derivatives. The arguments are:
//  M    mean anomaly (known data)
//  e    eccentricity (e > 1) (known data)
//  u    hyperbolic sine of the hyperbolic anomaly = sinh(H) (here is a known data)
//  caja memory to store the calculated values. It is the responsibility of 
//       the user to make the appropriate reservation of such memory
//       The JS version returns the whole array, created within the function.
//  Devuelve un puntero a caja, que es donde se guardan los valores calculados
// La función usa la variable externa nfun que recoge el numero de veces que se llama a la función

let nfun = 0;

function FKEH(M, e, u)
{ var a, ad, at, ac;
	nfun++;
	ad = 1 + u * u;
	a = Math.sqrt(ad);
	at = ad * a;
	ac = at * ad;
  var c = new Array(4);
	c[3] = (3.0 - 2.0 * ad) / ac / e;       // third derivative
	c[2] = u / at / e;                      // second derivative
	c[1] = 1 - 1 / a / e;                   // first derivative
	c[0] = u - Math.log(u + a) / e - M / e; // function
	return c;
}

// int ECUACION_DE_KEPLERH_sdgh(double M, double e, double *pu, double *resto, double eps)
// solves the kepler equation, in the hyperbolic case with a given precision. Arguments:
//  M     mean anomaly (known data)
//  e     eccentricity of the orbit (e > 1) (known data)
//  pu    pointer to a variable where the hyperbolic sine of the hyperbolic anomaly is collected = sinh(H) (unknown)
//  resto pointer to a variable where the residual of Kepler's equation is collected (e*u-log(u+sqrt(1+pow(u,2)))-M)
//  eps   tolerance
//  Uses the Modified Newton Raphson algorithm (MNR).
//  Returns an integer that matches the number of iterations made with the MNR
// JS version takes no pointers in and returns a composite object
function ECUACION_DE_KEPLERH_sdgh(M0, e0, eps0)
{ var M, e, eps, u, tt, delta, c, i = 0;
	const DBL_EPSILON = 2.22e-16;
	M = M0;
	e = e0;
	eps = eps0;
	u = keh_25(M, e, eps); // seed
  c = FKEH(M, e, u);
	// p   = c[0]; // function (rest of the equation)
	// q   = c[1]; // first derivative
	// r   = c[2]; // second derivative
	// s   = c[3]; // third derivative
	if (Math.abs(c[0]) < eps) // if the residual is < eps the solution is Ok
	{ return {ph1:u, resto1:c[0], i:i};
  }
	for (i = 1; i < 50; i++) // the iteration starts: modified Newton-Raphson 
	{	if (c[1] > 0)
    {	delta = 2 * c[0] / (c[1] + Math.sqrt(Math.abs(c[1] * c[1] - 2 * c[0] * c[2]))); // modified NR
    }
    else
    { delta = 2 * c[0] / (c[1] - Math.sqrt(Math.abs(c[1] * c[1] - 2 * c[0] * c[2])));
    }
    tt = -c[3] * delta * delta * delta / (3 * c[3] * delta * delta - 6 * c[2] * delta + 6 * c[1]);    // third derivative correction
		delta +=  tt;
	  u -=  delta;
		c = FKEH(M, e, u);// the next iteration starts
		if (Math.abs(u) <= 1)
		{	if ((Math.abs(c[0]) < eps) || (Math.abs(delta) < DBL_EPSILON)) break;	// the iteration ends. Exit
		}
		else
		{ if ((Math.abs(c[0]) < eps) || (Math.abs(delta) < Math.abs(u * DBL_EPSILON))) break;                     // the iteration ends. Exit
		}
	}
	return {ph1:u, resto1:c[0], i:i};
}

// int hkepler_eq(double M1, double e1, double *ph1, double *resto1, double eps1)
// consider the sign of the mean anomaly to solve the kepler equation, in the 
// hyperbolic case with a given precision. Arguments:
//  M1     mean anomaly (known data)
//  e1     eccentricity (e > 1) (known data)
//  ph1    pointer to a variable where the hyperbolic anomaly is collected = H (unknown)
//  resto1 pointer to a variable where the residual of Kepler's equation is collected (e1*pu1-log(pu1+sqrt(1+pow(pu1,2)))-M1)
//  eps    tolerance
//  The function returns an integer that matches the number of iterations made with the MNR
// The JS version uses no input pointers and returns a composite object.
function hkepler_eq(M1, e1, eps1)
{ var i1, s, ph1;
  nfun = 0;
	if (M1 >= 0)
	{ i1 = ECUACION_DE_KEPLERH_sdgh(M1, e1, eps1);
    s = i1.ph1;
		ph1 = Math.log(s + Math.sqrt(1 + s * s));
	}
	else
	{ M1 = -M1;
		i1 = ECUACION_DE_KEPLERH_sdgh(M1, e1, eps1);		
    s = i1.ph1;
		ph1 = -Math.log(s + Math.sqrt(1 + s * s));
	}
	return {ph1:ph1, resto1:i1.resto1, i:i1.i};
}