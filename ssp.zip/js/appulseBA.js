'use strict';
const  APP = {maxSep:1, maxMag:14.5, minDec:-90, maxDec:90, minElong:90, found:[]};

function checkAppulses()
{ const ASTERS = [];
  GD.nearest = null;
  var sunSkyPt = new SkyPoint(new RA(sunL.raHrs), new Dec(sunL.decDegs), new Epoch(2000));
  //1: Load asteroid data
  for (var i = 0; i < ASTEROIDS.length; i +=10)
  { var a = createAsteroid(ASTEROIDS[i]);
    if (null !== a)
    { ASTERS.push(a);
  } }
  //2: Get RA/Dec of each at JD:
  var jd = GD.cal.getJD(), n = ASTERS.length;
  var earth2000 = new EarthJ2000(jd);
  var xyzE = earth2000.getHeliocentricCoordinates();
  var sunDxJ2000 = -xyzE[0];
  var sunDyJ2000 = -xyzE[1];
  var sunDzJ2000 = -xyzE[2];
  var sunX = sunDxJ2000
            + 0.000000440360 * sunDyJ2000
            - 0.000000190919 * sunDzJ2000;
  var sunY = -0.000000479966 * sunDxJ2000
            + 0.917482137087 * sunDyJ2000
            - 0.397776982902 * sunDzJ2000;
  var sunZ =  0.397776982902 * sunDyJ2000
            + 0.917482137087 * sunDzJ2000;
  for (var i = 0; i < n; i++)
  { var obj = ASTERS[i];
    if (obj.getHeliocentricPositionAU)//In case not yet fully loaded
    { var xyz = obj.getHeliocentricPositionAU(jd);//sets rAU
      if (null !== xyz)
      { var dx = xyz.x + sunX;
        var dy = xyz.y + sunY;
        var dz = xyz.z + sunZ;
        obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
        var dLight = 0.0057755183 * obj.deltaAU;//days
        xyz = obj.getHeliocentricPositionAU (jd - dLight);//sets rAU
        obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
        var dot = dx * xyz.x + dy * xyz.y + dz * xyz.z;
        obj.phaseDegs = acosDegs(dot / (obj.rAU * obj.deltaAU));
        obj.decDegs = atan2Degs(dz, Math.sqrt(dx * dx + dy * dy));
        obj.raHrs = 12 * Math.atan2(dy, dx) / Math.PI;
        if (obj.raHrs < 0) obj.raHrs += 24;
        obj.mV = calcMv(obj).toFixed(1);
        if (GD.topocentric)
        { var adj = topoAdjust(jd, obj.raHrs, obj.decDegs, obj.deltaAU);
          obj.raHrs = adj.raHrs;
          obj.decDegs = adj.decDegs;
        }
        obj.ra = new RA(obj.raHrs);
        obj.dec = new Dec(obj.decDegs);
  } } }
  //3: Find sky distances between each:
  var s = '<strong>Asteroids &lt; ' + APP.maxSep + '&deg; apart, '+
'magnitude &le; ' + APP.maxMag + ' at JD' + jd.toFixed(5) + '</strong> ' + 
'<input type="button" class="control" value="Settings" ' +
'onclick="appulseSettings()"/><br>';
  APP.found = [];
  for (var i = 0; i < n; i++)
  { var ai = ASTERS[i];
    if (ai.mV > APP.maxMag) continue;
    if (ai.decDegs < APP.minDec || ai.decDegs > APP.maxDec) continue;
    var elong = sunSkyPt.calculateSeparation(ai);
    if (elong < APP.minElong) continue;
    for (var j = i + 1; j < n; j++)
    { var aj = ASTERS[j];
      if (aj.mV > APP.maxMag) continue;
      if (aj.decDegs < APP.minDec || aj.decDegs > APP.maxDec) continue;
      var dRaDegs = hours2degs(ai.raHrs - aj.raHrs);
      var cosD1 = cosDegs(aj.decDegs);
      var cosD2 = cosDegs(ai.decDegs);
      var cosDa = cosDegs(dRaDegs);
      var sinD1 = sinDegs(aj.decDegs);
      var sinD2 = sinDegs(ai.decDegs);
      var sinDa = sinDegs(dRaDegs);
      var xx = cosD1 * sinD2 - sinD1 * cosD2 * cosDa;
      var yy = cosD2 * sinDa;
      var zz = sinD1 * sinD2 + cosD1 * cosD2 * cosDa;
      var sepnDegs = atan2Degs(Math.sqrt (xx * xx + yy * yy), zz);
      if (sepnDegs <= APP.maxSep)
      { APP.found.push({ra:ai.raHrs,
s:ai.symbol + ' ' + ai.name + ' ' + aToHTMLString(ai) + ' &amp; ' +
aj.symbol + ' ' + aj.name + ' ' + aToHTMLString(aj) + 
' (' + sepnDegs.toFixed(2) + '&deg;)',
name1:ai.name, name2:aj.name});
  } } }
  if (APP.found.length <= 0) s += 'None found';
  else//sort on RA:
  { APP.found.sort(function(a, b) { return (a.ra < b.ra) ? -1 : 1; });
    for (i = 0; i < APP.found.length; i++)
    { s += APP.found[i].s + '<input type="checkbox" id="app' + i +
'" onchange="appChecks()" title="Add to chart"><br>';
  } } 
  document.getElementById("appulse").innerHTML = s;
  showUserText();
  location.assign('#appulse');
}

function aToHTMLString(a)
{ var ra = new RA(a.raHrs), dec = new Dec(a.decDegs);
  return ra.toHTMLString() + ' ' + dec.toHTMLString() + ' mV' + a.mV;
}

function appulseSettings()
{ GD.elData.innerHTML = 
'<p><strong>Asteroid appulse settings</strong></p>' +
'<p>Max separation [0.5..3]&deg;: <input type="text" id="maxSep" maxlength="3" size="6"' +
'value="' + APP.maxSep + '" onchange="appValidate()"/><br/>' +
'Max magnitude [12..15]: <input type="text" id="maxMag" maxlength="4" size="6"' +
'value="' + APP.maxMag + '" onchange="appValidate()"/><br/>' +
'Min Declination [-90..0]&deg;: <input type="text" id="minDec" maxlength="4" size="6"' +
'value="' + APP.minDec + '" onchange="appValidate()"/><br/>' +
'Max Declination [0..90]&deg;: <input type="text" id="maxDec" maxlength="4" size="6"' +
'value="' + APP.maxDec + '" onchange="appValidate()"/><br/>' +
'Min solar elong. [30..150]&deg;: <input type="text" id="minElong" maxlength="4" size="6"' +
'value="' + APP.minElong + '" onchange="appValidate()"/><br/>' +
'</p><p><input type="button" class="control" value="List appulses" onclick="checkAppulses()"/> ' +
'<a href="#applist" class="intLink">?</a></p>';
}

function appValidate()
{ APP.maxSep = appSet("maxSep", 0.5, 3, 1);
  APP.maxMag = appSet("maxMag", 12, 15, 14.5);
  APP.minDec = appSet("minDec", -90, 0, -90);
  APP.maxDec = appSet("maxDec", 0, 90, 90);
  APP.minElong = appSet("minElong", 30, 150, 90);
}

function appSet(id, min, max, deft)
{ var el = document.getElementById(id);
  var x = parseFloat(el.value);
  if (!(x >= min && x <= max))
  { x = deft;
    el.value = x;
  }
  return x;
}

function appChecks()
{ var a1 = null, a2 = null;
  for (var i = 0; i < APP.found.length; i++)
  { var el = document.getElementById("app" + i);
    if (el.checked)
    { var ast = APP.found[i];
      for (var j = 0; j < ASTEROIDS.length; j += 10)
      { if (ASTEROIDS[j].startsWith(ast.name1))
        { a1 = createAsteroid(ASTEROIDS[j]);
          if (null !== a1) addedObjects.push(a1);
        }
        if (ASTEROIDS[j].startsWith(ast.name2))
        { a2 = createAsteroid(ASTEROIDS[j]);
          if (null !== a2) addedObjects.push(a2);
  } } } }
  getData();
}

function appUncheckAll()
{ for (var i = 0; i < APP.found.length; i++)
  { var el = document.getElementById("app" + i);
    if (el) el.checked = false;
} }

function listFastest()
{ const ASTERS = [];
  GD.nearest = null;
  var sunSkyPt = new SkyPoint(new RA(sunL.raHrs), new Dec(sunL.decDegs), new Epoch(2000));
  //1: Load asteroid data
  for (var i = 0; i < ASTEROIDS.length; i +=10)
  { var a = createAsteroid(ASTEROIDS[i]);
    if (null !== a)
    { ASTERS.push(a);
  } }
  ASTERS.push(ceres);
  ASTERS.push(juno);
  ASTERS.push(pallas);
  ASTERS.push(vesta);
  //2: Get RA/Dec of each at JD:
  var jd = GD.cal.getJD(), n = ASTERS.length;
  for (var i = 0; i < n; i++)
  { var obj = ASTERS[i];
    if (obj.getHeliocentricPositionAU)//In case not yet fully loaded
    { 
      var pt1 = appGetSkyPt(obj, jd);
      var pt2 = appGetSkyPt(obj, jd + 1);
      obj.dailyDegs = pt1.calculateSeparation(pt2);
      obj.elongDegs = pt1.calculateSeparation(sunSkyPt);
  } }
  ASTERS.sort(function(a, b) { return (a.dailyDegs > b.dailyDegs) ? -1 : 1; });
  var s = '<strong>Asteroids with largest daily motion, &ge; 90&deg; from Sun at JD ' +
          jd + '</strong><br/>';
  var n = 0;
  for (i = 0; i < ASTERS.length && n < 16; i++)
  { var ai = ASTERS[i];
    if (ai.elongDegs >= 90)
    { s += ai.symbol + ' ' + ai.name + ' ' + ai.dailyDegs.toFixed(3) + '&deg;/day<br>';
      n++;
      addIfNotAlready(ai);
  } }
  if (n === 0) s += "None found: all &lt; 90&deg; from Sun";
  document.getElementById("appulse").innerHTML = s;
  getData();
  location.assign('#appulse');
}

function listBrightest()
{ const ASTERS = [];
  GD.nearest = null;
  var sunSkyPt = new SkyPoint(new RA(sunL.raHrs), new Dec(sunL.decDegs), new Epoch(2000));
  //1: Load asteroid data
  for (var i = 0; i < ASTEROIDS.length; i +=10)
  { var a = createAsteroid(ASTEROIDS[i]);
    if (null !== a)
    { ASTERS.push(a);
  } }
  ASTERS.push(ceres);
  ASTERS.push(juno);
  ASTERS.push(pallas);
  ASTERS.push(vesta);
  //2: Get RA/Dec of each at JD:
  var jd = GD.cal.getJD(), n = ASTERS.length;
  for (var i = 0; i < n; i++)
  { var obj = ASTERS[i];
    if (obj.getHeliocentricPositionAU)//In case not yet fully loaded
    { 
      var pt = appGetSkyPt(obj, jd);
      obj.elongDegs = pt.calculateSeparation(sunSkyPt);
      obj.mv = calcMv(obj);
  } }
  ASTERS.sort(function(a, b) { return (a.mv < b.mv) ? -1 : 1; });
  var s = '<strong>Brightest asteroids estimated magnitudes, &ge; 60&deg; from Sun at JD ' +
          jd + '</strong><br/>';
  for (i = 0, n = 0; i < ASTERS.length && n < 16; i++)
  { var ai = ASTERS[i];
    if (ai.elongDegs >= 60)
    { s += ai.symbol + ' ' + ai.name + ' ' + ai.mv.toFixed(1) + '<br/>';
      n++;
      addIfNotAlready(ai);
  } }
  if (n === 0) s += "None found: all &lt; 90&deg; from Sun";
  document.getElementById("appulse").innerHTML = s;
  getData();
  location.assign('#appulse');
}

function addIfNotAlready(a)
{ for (var i = 0; i < objects.length; i++)
  { if (a.name === objects[i].name) return;
  }
  for (i = 0; i < addedObjects.length; i++)
  { if (a.name === addedObjects[i].name) return;
  }
  addedObjects.push(a);
}

function appGetSkyPt(obj, jd)
{ var earth2000 = new EarthJ2000(jd);
  var xyzE = earth2000.getHeliocentricCoordinates();
  var sunDxJ2000 = -xyzE[0];
  var sunDyJ2000 = -xyzE[1];
  var sunDzJ2000 = -xyzE[2];
  var sunX = sunDxJ2000
            + 0.000000440360 * sunDyJ2000
            - 0.000000190919 * sunDzJ2000;
  var sunY = -0.000000479966 * sunDxJ2000
            + 0.917482137087 * sunDyJ2000
            - 0.397776982902 * sunDzJ2000;
  var sunZ =  0.397776982902 * sunDyJ2000
            + 0.917482137087 * sunDzJ2000;
  var xyz = obj.getHeliocentricPositionAU(jd);//sets rAU
  var dx = xyz.x + sunX;
  var dy = xyz.y + sunY;
  var dz = xyz.z + sunZ;
  obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
  var dLight = 0.0057755183 * obj.deltaAU;//days
  xyz = obj.getHeliocentricPositionAU (jd - dLight);//sets rAU
  obj.deltaAU = Math.sqrt(dx * dx + dy * dy + dz * dz);
  var dot = dx * xyz.x + dy * xyz.y + dz * xyz.z;
  obj.phaseDegs = acosDegs(dot / (obj.rAU * obj.deltaAU));
  obj.decDegs = atan2Degs(dz, Math.sqrt(dx * dx + dy * dy));
  obj.raHrs = 12 * Math.atan2(dy, dx) / Math.PI;
  if (obj.raHrs < 0) obj.raHrs += 24;
  obj.mV = calcMv(obj).toFixed(1);
  if (GD.topocentric)
  { var adj = topoAdjust(jd, obj.raHrs, obj.decDegs, obj.deltaAU);
    obj.raHrs = adj.raHrs;
    obj.decDegs = adj.decDegs;
  }
  obj.ra = new RA(obj.raHrs);
  obj.dec = new Dec(obj.decDegs);
  return new SkyPoint(obj.ra, obj.dec, J2000);
}