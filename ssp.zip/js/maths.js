// maths.js by Graham Relf
'use strict';

const TWO_PI = Math.PI * 2, HALF_PI = Math.PI / 2;
const DEGS_TO_RADS = Math.PI / 180, RADS_TO_DEGS = 180 / Math.PI;
const HRS_TO_RADS = Math.PI / 12;
function acosDegs(x) { return RADS_TO_DEGS * Math.acos(x); }
function asinDegs(x) { return RADS_TO_DEGS * Math.asin(x); }
function atan2Degs(y, x) { return RADS_TO_DEGS * Math.atan2(y, x); }
function cosDegs(xDegs) { return Math.cos(xDegs * DEGS_TO_RADS); }
function sinDegs(xDegs) { return Math.sin(xDegs * DEGS_TO_RADS); }
function tanDegs(xDegs) { return Math.tan(xDegs * DEGS_TO_RADS); }
function in360(xDegs) { return(xDegs + 360) % 360; }
function log10(x) { return Math.log(x) / Math.LN10; }
function signum(x) { return x >= 0 ? 1 : -1; }
function rad2deg(x) { return x * RADS_TO_DEGS; }
function deg2rad(x) { return x * DEGS_TO_RADS; }

function cbrt(x)
{ if (x === 0) return 0;
  return signum(x) * Math.exp(Math.log(Math.abs (x)) / 3);
}


