/* orbits.js by Graham Relf 2013 Jul 19
 * Orbits as in Meeus AA Chapters 33 - 35.
 * Assumes elements are given for J2000.0.
 * Requires calendar.js and maths.js */
'use strict';

/**  Gaussian gravitational constant (radians). */
const K = 0.01720209895;
const TWO_PI_ON_K_SQ = 4 * (Math.PI / K) * (Math.PI / K);
// Then Kepler: Period = Math.sqrt(TWO_PI_ON_K_SQ * aCubed)

/**  G x mass of sun - assume other masses are negligible. */
const MU = K * K;

/** Ecliptic obliquity for J2000.0 */
const SIN_EPSILON_J2000 = 0.397777156;
const COS_EPSILON_J2000 = 0.917482062;

/** Parameters after first 4 are in the order given by MPC COMET data.
  * tauY and tauM are integers but tauD includes decimals. */
function Orbit (name, symbol, kind, colour,
  tauY, tauM, tauD, qAU, e, periArgDegs, omegaDegs, iDegs, epochJD, h, g)
{ this.name = name;
  this.symbol = symbol;
  this.kind = kind;
  this.colour = colour;
  this.tauJD = toJD (tauY, tauM, tauD);
  this.qAU = qAU;
  this.aAU = aFqe (qAU, e);
	this.nRadPerDay = nRadPerDayFaAU (this.aAU);
	this.e = e;
	this.sqrt1_ee = Math.sqrt (1 - e * e);
  this.wRad = DEGS_TO_RADS * periArgDegs;
  this.omegaDegs = omegaDegs;
  this.sinOmega = sinDegs (omegaDegs);
  this.cosOmega = cosDegs (omegaDegs);
  this.iDegs = iDegs;
  this.sinI = sinDegs (iDegs);
  this.cosI = cosDegs (iDegs);
  this.epochJD = epochJD;
  this.h = h;
  this.g = g;
  // Meeus AA p228:
  var cosOmegaCosI = this.cosOmega * this.cosI;
  var _FF = this.cosOmega;
  var _GG = this.sinOmega * COS_EPSILON_J2000;
  var _HH = this.sinOmega * SIN_EPSILON_J2000;
  var _P = -this.sinOmega * this.cosI;
  var _Q = cosOmegaCosI * COS_EPSILON_J2000 - this.sinI * SIN_EPSILON_J2000;
  var _R = cosOmegaCosI * SIN_EPSILON_J2000 + this.sinI * COS_EPSILON_J2000;
  var _Fsq = _FF * _FF;
  var _Gsq = _GG * _GG;
  var _Hsq = _HH * _HH;
  var _Psq = _P * _P;
  var _Qsq = _Q * _Q;
  var _Rsq = _R * _R;
this._FF = _FF;
this._GG = _GG;
this._HH = _HH;
this._P = _P;
this._Q = _Q;
this._R = _R;
  this._A = Math.atan2 (_FF, _P);
  this._B = Math.atan2 (_GG, _Q);
  this._C = Math.atan2 (_HH, _R);
  this.aa = Math.sqrt (_Fsq + _Psq);
  this.bb = Math.sqrt (_Gsq + _Qsq);
  this.cc = Math.sqrt (_Hsq + _Rsq);
} // Orbit

/** Get heliocentric cartesian coordinates at given Julian date, as an object with
  * properties x, y, z (all in AU).
  * May return null in cases of non-convergence for near-parabolic orbits and user
  * gets a message in such cases. */
Orbit.prototype.getHeliocentricPositionAU = function (jd)
{ var daysSincePerihelion = jd - this.tauJD;
  var meanAnomalyRads = this.nRadPerDay * daysSincePerihelion;
  var g, s, wv;
  if (this.e < 0.98) // Ellipse
  { this.eccentricAnomalyRads = solveKepler(meanAnomalyRads, this.e);
    var cosE = Math.cos(this.eccentricAnomalyRads);
    this.rAU = this.aAU * (1 - this.e * cosE);
    this.trueAnomalyRads = 2 * Math.atan2(
      Math.sqrt (1 + this.e) * Math.tan (this.eccentricAnomalyRads * 0.5),
      Math.sqrt (1 - this.e));
  }
  else
  if (this.e === 1.0) // Parabola: Meeus AA Chapter 34, p241
  { var _W = 0.03649116245 *
      daysSincePerihelion / (this.qAU * Math.sqrt (this.qAU));
    // Meeus p243 (third method of solving Barker's equation for s):
    g = _W * 0.5;
    var _Y = cbrt (g + Math.sqrt (g * g + 1));
    s = _Y - 1 / _Y;
    this.trueAnomalyRads = 2 * Math.atan (s);
    this.rAU = this.qAU * (1 + s * s);
  }
  else
  if (this.e < 1.1) // Near parabolic (1.1 is arbitrary)
  { // Meeus AA Chapter 35 p245:
    if (daysSincePerihelion === 0)
    { this.rAU = this.qAU;
      this.trueAnomalyRads = 0;
    }
    else
    { var d1 = 1000;
      var d = 1.e-9;
      var qe = (1 + this.e) / this.qAU;
      var q1 = 0.5 * K * Math.sqrt (qe) / this.qAU;
      g = (1 - this.e) / (1 + this.e);
      var q2 = q1 * daysSincePerihelion;
      s = 2 / (3 * Math.abs (q2));
      s = 2 / Math.tan (2 * Math.atan (
              cbrt (Math.tan (0.5 * Math.atan (s)))));
      if (daysSincePerihelion < 0.0) s = -s;
      var l = 0;
      var s0, z;
      do
      { z = 1;
        s0 = s;
        var y = s * s;
        var g1 = -y * s;
        var q3 = q2 + 2 * g * s * y / 3;
        var absF;
        do
        { z++;
          g1 = -g1 * g * y;
          var z1 = (z - (z + 1) * g) / (2 * z + 1);
          var f = z1 * g1;
          q3 += f;
          absF = Math.abs (f);
          if (z > 50 || absF > d1)
          { error ('Sorry, no convergence in near parabolic orbit');
            return null;
          }
        }
        while (absF > d);
        l++;
        if (l > 50)
        { error ('Sorry, no convergence in near parabolic orbit');
          return null;
        }
        var s1;
        do
        { s1 = s;
          var s2 = s * s;
          s = (2 * s2 * s / 3 + q3) / (s2 + 1);
        }
        while (Math.abs (s - s1) > d);
      }
      while (Math.abs (s - s0) > d);
      this.trueAnomalyRads = 2 * Math.atan (s);
      if (this.trueAnomalyRads < 0) this.trueAnomalyRads += TWO_PI;
      this.rAU = this.qAU * (1 + this.e) /
        (1 + this.e * Math.cos (this.trueAnomalyRads));
    }
  }
  else//hyperbolic: e > 1.2
  { var res = hkepler_eq(meanAnomalyRads, this.e, 2.22e-16);//in kh.js
//console.log(res);
    this.eccentricAnomalyRads = res.ph1;
    var coshF = Math.cosh(this.eccentricAnomalyRads);
//console.log("coshF=" + coshF);
    this.rAU = this.aAU * (this.e * coshF - 1);
    this.trueAnomalyRads = 2 * Math.atan2(
      Math.sqrt(this.e + 1) * Math.tanh(this.eccentricAnomalyRads * 0.5),
      Math.sqrt(this.e - 1));
//console.log(this);
  }
  wv = this.wRad + this.trueAnomalyRads;
  return {x: this.rAU * this.aa * Math.sin (this._A + wv),
          y: this.rAU * this.bb * Math.sin (this._B + wv),
          z: this.rAU * this.cc * Math.sin (this._C + wv)};
}; // getHeliocentricPositionAU

function solveKepler(_MRads, e)
{ // Sinnott's method, from Meeus AA p206:
  var f = signum(_MRads);
  var m = Math.abs(_MRads) / TWO_PI;
  m = (m - Math.floor(m)) * TWO_PI * f;
  if (m < 0)
  { m += TWO_PI;
  }
  if (m > Math.PI)
  { f = -1;
    m = TWO_PI - m;
  }
  else
  { f = 1;
  }
  var e0 = Math.PI / 2;
  var d = e0 / 2;
  for (var j = 1; j <= 63; j++)
  { var m1 = e0 - e * Math.sin(e0);
    e0 += d * signum(m - m1);
    d /= 2;
  }
  return e0 * f; // Eccentric anomaly in radians
} // solveKepler

function toJD(y, m, d)
{ var wholeDays = Math.floor(d);
  var secs = (d - wholeDays) * 86400;
  var hour = Math.floor(secs / 3600);
  secs -= hour * 3600;
  var min = Math.floor(secs / 60);
  secs -= min * 60;
  var date = new Date();
  date.setUTCFullYear(y, m - 1, wholeDays);
  date.setUTCHours(hour, min, secs, 0)
  var msSince1970 = date.getTime ();
  return msSince1970 / DAY_MS + JD_1970_0;
} // toJD

/** Returns Orbit object constructed from a different set of parameters */
function createOrbit(name, symbol, kind, colour,
  epochJD, e, aAU, iDegs, omegaDegs, periLongDegs, meanLongDegs, h, g)
{ var qAU = qFae(aAU, e);
  var nDegsPerDay = RADS_TO_DEGS * nRadPerDayFaAU (aAU);
  var periArgDegs = in360 (periLongDegs - omegaDegs);
  var _M = in360 (meanLongDegs - periLongDegs);
  var tauJD;
  if (_M <= 180) tauJD = epochJD - _M / nDegsPerDay;
  else tauJD = epochJD + (360 - _M) / nDegsPerDay;
  var msSince1970 = (tauJD - JD_1970_0) * DAY_MS;
  var tau = new Date (msSince1970);
  var tauD = tau.getUTCDate() + tau.getUTCHours() / 24 + tau.getUTCMinutes() / 1440 +
    tau.getUTCSeconds() / DAY_S + tau.getUTCMilliseconds() / DAY_MS;
  return new Orbit (name, symbol, kind, colour,
    tau.getUTCFullYear(), tau.getUTCMonth() + 1, tauD,
    qAU, e, periArgDegs, omegaDegs, iDegs, epochJD, h, g);
} // createOrbit

function qFae (a, e) { return a * (1 - e); }
function aFqe (q, e) { return Math.abs (q / (1 - e)); }
function nRadPerDayFaAU (aAU) { return K / Math.sqrt (aAU * aAU * aAU); }
function periArgFperiLongOmega (periLongDegs, omegaDegs)
{ return in360 (periLongDegs - omegaDegs); }
