package net.grelf.planet;

/** Each instance represents Neptune at a given instant.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class Neptune extends Planet
{
	/** Constructs apparent position at earth-bound observer's Julian Ephemeris Day, allowing for light time. */
	public Neptune (double observerJED, Earth earth) throws WrongRowNumberException
	{
		super ("Neptune");
		this.observerJED = observerJED;
		this.distanceFromEarthAU = 30.0; // First guess
		calcPosition (observerJED); // - Planet.lightTimeDays (this.distanceFromEarthAU));
/*
		report ("Neptune L=" + this.longitudeHeliocentricDegs + " B=" + this.latitudeHeliocentricDegs +
						" R=" + this.radiusVectorAU + "delta=" + this.distanceFromEarthAU +
						"light time=" + Planet.lightTimeDays (this.distanceFromEarthAU));
*/
		adjustForLightTime (earth);
/*
		report ("Neptune L=" + this.longitudeHeliocentricDegs + " B=" + this.latitudeHeliocentricDegs +
						" R=" + this.radiusVectorAU + "delta=" + this.distanceFromEarthAU +
						"light time=" + Planet.lightTimeDays (this.distanceFromEarthAU));
*/
	} // Neptune

	@Override
	protected  double calcLDegs (double tau) throws WrongRowNumberException
	{
		double l0 = sumSeries (NEPTUNE_L0, tau);
		double l1 = sumSeries (NEPTUNE_L1, tau);
		double l2 = sumSeries (NEPTUNE_L2, tau);
		double l3 = sumSeries (NEPTUNE_L3, tau);
		double l4 = sumSeries (NEPTUNE_L4, tau);
		return StrictMath.toDegrees ((((((((l4 * tau) + l3) * tau) + l2) * tau) + l1) * tau + l0) * 1.0e-8);
	} // calcLDegs

	@Override
	protected  double calcBDegs (double tau) throws WrongRowNumberException
	{
		double b0 = sumSeries (NEPTUNE_B0, tau);
		double b1 = sumSeries (NEPTUNE_B1, tau);
		double b2 = sumSeries (NEPTUNE_B2, tau);
		double b3 = sumSeries (NEPTUNE_B3, tau);
		double b4 = sumSeries (NEPTUNE_B4, tau);
		return StrictMath.toDegrees ((((((((b4 * tau) + b3) * tau) + b2) * tau) + b1) * tau + b0) * 1.0e-8);
	} // calcBDegs

	@Override
	protected  double calcRAU (double tau) throws WrongRowNumberException
	{
		double r0 = sumSeries (NEPTUNE_R0, tau);
		double r1 = sumSeries (NEPTUNE_R1, tau);
		double r2 = sumSeries (NEPTUNE_R2, tau);
		double r3 = sumSeries (NEPTUNE_R3, tau);
		return (((((r3 * tau) + r2) * tau) + r1) * tau + r0) * 1.0e-8;
	} // calcRAU

	private static final double [] NEPTUNE_L0 = new double []
	{
		1,531188633,0,0,
		2,1798476,2.9010127,38.1330356,
		3,1019728,0.4858092,1.4844727,
		4,124532,4.830081,36.648563,
		5,42064,5.41055,2.96895,
		6,37715,6.09222,35.16409,
		7,33785,1.24489,76.26607,
		8,16483,0.00008,491.55793,
		9,9199,4.9375,39.6175,
		10,8994,0.2746,175.1661,
		11,4216,1.9871,73.2971,
		12,3365,1.0359,33.6796,
		13,2285,4.2061,4.4534,
		14,1434,2.7834,74.7816,
		15,900,2.076,109.946,
		16,745,3.190,71.813,
		17,506,5.748,114.399,
		18,400,0.350,1021.249,
		19,345,3.462,41.102,
		20,340,3.304,77.751,
		21,323,2.248,32.195,
		22,306,0.497,0.521,
		23,287,4.505,0.048,
		24,282,2.246,146.594,
		25,267,4.889,0.963,
		26,252,5.782,388.465,
		27,245,1.247,9.561,
		28,233,2.505,137.033,
		29,227,1.797,453.425,
		30,170,3.324,108.461,
		31,151,2.192,33.940,
		32,150,2.997,5.938,
		33,148,0.859,111.430,
		34,119,3.677,2.448,
		35,109,2.416,183.243,
		36,103,0.041,0.261,
		37,103,4.404,70.328,
		38,102,5.705,0.112
	};

	private static final double [] NEPTUNE_L1 = new double []
	{
		1,3837687717.0,0,0,
		2,16604,4.86319,1.48447,
		3,15807,2.27923,38.13304,
		4,3335,3.6820,76.2661,
		5,1306,3.6732,2.9689,
		6,605,1.505,35.164,
		7,179,3.453,39.618,
		8,107,2.451,4.453,
		9,106,2.755,33.680,
		10,73,5.49,36.65,
		11,57,1.86,114.40,
		12,57,5.22,0.52,
		13,35,4.52,74.78,
		14,32,5.90,77.75,
		15,30,3.67,388.47,
		16,29,5.17,9.56,
		17,29,5.17,2.45,
		18,26,5.25,168.05
	};

	private static final double [] NEPTUNE_L2 = new double []
	{
		1,53893,0,0,
		2,296,1.855,1.484,
		3,281,1.191,38.133,
		4,270,5.721,76.266,
		5,23,1.21,2.97,
		6,9,4.43,35.16,
		7,7,0.54,2.45
	};

	private static final double [] NEPTUNE_L3 = new double []
	{
		1,31,0,0,
		2,15,1.35,76.27,
		3,12,6.04,1.48,
		4,12,6.11,38.13
	};

	private static final double [] NEPTUNE_L4 = new double []
	{
		1,114,3.142,0
	};

	private static final double [] NEPTUNE_B0 = new double []
	{
		1,3088623,1.4410437,38.1330356,
		2,27780,5.91272,76.26607,
		3,27624,0,0,
		4,15448,3.50877,39.61751,
		5,15355,2.52124,36.64856,
		6,2000,1.5100,74.7816,
		7,1968,4.3778,1.4845,
		8,1015,3.2156,35.1641,
		9,606,2.802,73.297,
		10,595,2.129,41.102,
		11,589,3.187,2.969,
		12,402,4.169,114.399,
		13,280,1.682,77.751,
		14,262,3.767,213.299,
		15,254,3.271,453.425,
		16,206,4.257,529.691,
		17,140,3.530,137.033
	};

	private static final double [] NEPTUNE_B1 = new double []
	{
		1,227279,3.807931,38.133036,
		2,1803,1.9758,76.2661,
		3,1433,3.1416,0,
		4,1386,4.8256,36.6486,
		5,1073,6.0805,39.6175,
		6,148,3.858,74.782,
		7,136,0.478,1.484,
		8,70,6.19,35.16,
		9,52,5.05,73.30,
		10,43,0.31,114.40,
		11,37,4.89,41.10,
		12,37,5.76,2.97,
		13,26,5.22,213.30
	};

	private static final double [] NEPTUNE_B2 = new double []
	{
		1,9691,5.5712,38.1330,
		2,79,3.63,76.27,
		3,72,0.45,36.65,
		4,59,3.14,0,
		5,30,1.61,39.62,
		6,6,5.61,74.78
	};

	private static final double [] NEPTUNE_B3 = new double []
	{
		1,273,1.017,38.133,
		2,2,0,0,
		3,2,2.37,36.65,
		4,2,5.33,76.27
	};

	private static final double [] NEPTUNE_B4 = new double []
	{
		1,6,2.67,38.13
	};

	private static final double [] NEPTUNE_R0 = new double []
	{
		1,3007013206.0,0,0,
		2,27062259,1.32999459,38.13303564,
		3,1691764,3.2518614,36.6485629,
		4,807831,5.185928,1.484473,
		5,537761,4.521139,35.164090,
		6,495726,1.571057,491.557929,
		7,274572,1.845523,175.166060,
		8,135134,3.372206,39.617508,
		9,121802,5.797544,76.266071,
		10,100895,0.377027,73.297126,
		11,69792,3.79617,2.96895,
		12,46688,5.74938,33.67962,
		13,24594,0.50802,109.94569,
		14,16939,1.59422,71.81265,
		15,14230,1.07786,74.78160,
		16,12012,1.92062,1021.24889,
		17,8395,0.6782,146.5943,
		18,7572,1.0715,388.4652,
		19,5721,2.5906,4.4534,
		20,4840,1.9069,41.1020,
		21,4483,2.9057,529.6910,
		22,4421,1.7499,108.4612,
		23,4354,0.6799,32.1951,
		24,4270,3.4134,453.4249,
		25,3381,0.8481,183.2428,
		26,2881,1.9860,137.0330,
		27,2879,3.6742,350.3321,
		28,2636,3.0976,213.2991,
		29,2530,5.7984,490.0735,
		30,2523,0.4863,493.0424,
		31,2306,2.8096,70.3282,
		32,2087,0.6186,33.9402
	};

	private static final double [] NEPTUNE_R1 = new double []
	{
		1,236339,0.704980,38.133036,
		2,13220,3.32015,1.48447,
		3,8622,6.2163,35.1641,
		4,2702,1.8814,39.6175,
		5,2155,2.0943,2.9689,
		6,2153,5.1687,76.2661,
		7,1603,0,0,
		8,1464,1.1842,33.6796,
		9,1136,3.9189,36.6486,
		10,898,5.241,388.465,
		11,790,0.533,168.053,
		12,760,0.021,182.280,
		13,607,1.077,1021.249,
		14,572,3.401,484.444,
		15,561,2.887,498.671
	};

	private static final double [] NEPTUNE_R2 = new double []
	{
		1,4247,5.8991,38.1330,
		2,218,0.346,1.484,
		3,163,2.239,168.053,
		4,156,4.594,182.280,
		5,127,2.848,35.164
	};

	private static final double [] NEPTUNE_R3 = new double []
	{
		1,166,4.552,38.133
	};

} // Neptune
