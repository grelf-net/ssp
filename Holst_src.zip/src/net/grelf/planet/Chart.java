package net.grelf.planet;

/** Pane for displaying planets against star chart.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class Chart extends javax.swing.JComponent implements java.awt.event.MouseMotionListener
{
	private java.util.List <net.grelf.astro.Star> stars = new java.util.ArrayList <net.grelf.astro.Star> ();

	private net.grelf.astro.Epoch chartEpoch;

	private static final int STAR_RADIUS = 3;
	private static final int JUPITER_RADIUS = 8;
	private static final int JUPITER_DIAMETER = JUPITER_RADIUS * 2;
	private static final java.awt.Color JUPITER_COLOUR = new java.awt.Color (255, 255, 192);
	private static final int URANUS_RADIUS = 4;
	private static final int URANUS_DIAMETER = URANUS_RADIUS * 2;
	private static final java.awt.Color URANUS_COLOUR = new java.awt.Color (192, 255, 255);

	private int chartWidthPx, chartHeightPx;
	private double xScale, yScale;
	private java.awt.image.BufferedImage starImage;

	public Chart (net.grelf.astro.JulianDate jd, net.grelf.astro.SkyPoint plotCentre, double fieldRadiusDegs,
					      int chartWidthPx, int chartHeightPx)
	{
		super ();
		this.chartWidthPx = chartWidthPx;
		this.chartHeightPx = chartHeightPx;
		java.awt.Dimension size = new java.awt.Dimension (chartWidthPx, chartHeightPx);
		setSize (size);
		setPreferredSize (size);

		initialiseChartCoordinates (plotCentre, fieldRadiusDegs);
		this.chartEpoch = plotCentre.getEpoch ();
		addStars ();

		double sinFieldWidth = 2.0 * StrictMath.sin (StrictMath.toRadians (fieldRadiusDegs));
		this.xScale = chartWidthPx / sinFieldWidth;
		this.yScale = chartHeightPx / sinFieldWidth;
		starImage = new java.awt.image.BufferedImage (
					chartWidthPx, chartHeightPx, java.awt.image.BufferedImage.TYPE_INT_RGB);
		drawStars (starImage);
		plotPlanets (jd);
	} // Chart

	private net.grelf.astro.Star jupiter;
	private net.grelf.astro.Star uranus;
	private static final java.text.SimpleDateFormat DATE_FORMAT = new java.text.SimpleDateFormat ("yy MMM dd");

	public void plotPlanets (net.grelf.astro.JulianDate jd)
	{
		starNearestMouse = null; // Clear overlay when buttons are used

		try
		{
			double jdd = jd.toDouble ();
			java.util.Calendar date = jd.toGregorianCalendar ();
			String dateString = DATE_FORMAT.format (date.getTime ());
			Earth e = new Earth (jdd);
			Jupiter j = new Jupiter (jdd, e);
			net.grelf.astro.SkyPoint jPt = j.getSkyPoint (e, chartEpoch);
			jupiter = new net.grelf.astro.Star ();
			jupiter.setOtherId ("Jupiter " + dateString);
			jupiter.addMagnitude (new net.grelf.astro.Magnitude (3.0F));
			jupiter.setPosition (jPt);
			calculateChartCoordinates (jupiter);
			Uranus u = new Uranus (jdd, e);
			net.grelf.astro.SkyPoint uPt = u.getSkyPoint (e, chartEpoch);
			uranus = new net.grelf.astro.Star ();
			uranus.setOtherId ("Uranus " + dateString);
			uranus.addMagnitude (new net.grelf.astro.Magnitude (5.7F));
			uranus.setPosition (uPt);
			calculateChartCoordinates (uranus);
			repaint ();
		}
		catch (WrongRowNumberException ex) { /* Prevented by testing!! */ }
	} // plotPlanets

	private void addStar (String commonId, String hipId, String tycId, String otherId,
												int rah, int ram, double ras, int decd, int decm, double decs, float epochy, String magBand, float magValue)
	{
		net.grelf.astro.Star star = new net.grelf.astro.Star ();
		star.setCommonId (commonId);

		if (hipId.length () > 0)
		{
			star.setHipparcosId ("Hip" + hipId);
		}

		if (tycId.length () > 0)
		{
			star.setTychoId ("Tyc" + tycId);
		}

		star.setOtherId (otherId);
		net.grelf.astro.SkyPoint pt = new net.grelf.astro.SkyPoint (
						new net.grelf.astro.RA (rah, ram, ras),
						new net.grelf.astro.Dec (decd, decm, decs),
						new net.grelf.astro.Epoch ('J', epochy));
		pt.changeEpoch (this.chartEpoch);
		star.setPosition (pt);
		star.addMagnitude (new net.grelf.astro.Magnitude (magValue, magBand));
		calculateChartCoordinates (star);
		stars.add (star);
	} // addStar

	private void addStars ()
	{
		addStar ("", "    14", "4663   160 1", "", 00, 00, 11.59, -00, -21, -37.5, 1991.25F, "V", 7.25F);
		addStar ("", "    18", "4666   461 1", "", 00, 00, 12.75, -04, -03, -13.5, 1991.25F, "V", 11.03F);
		addStar ("", "    44", "4666   405 1", "", 00, 00, 31.85, -03, -18, -22.9, 1991.25F, "V", 7.91F);
		addStar ("", "    56", "   1  1015 1", "", 00, 00, 39.08, +00, 13, 22.6, 1991.25F, "V", 8.12F);
		addStar ("", "    93", "4663   456 1", "", 00, 01, 10.13, -00, -04, -33.3, 1991.25F, "V", 8.12F);
		addStar ("", "   134", "4663   658 1", "", 00, 01, 42.03, -01, -8, -23.9, 1991.25F, "V", 9.96F);
		addStar ("", "   135", "4663    94 1", "", 00, 01, 42.42, -00, -13, -02.1, 1991.25F, "V", 8.64F);
		addStar ("29 Psc", "   145", "4666   935 1", "", 00, 01, 49.44, -03, -01, -38.9, 1991.25F, "V", 5.13F);
		addStar ("", "   159", "4666    98 1", "", 00, 02, 02.59, -02, -45, -58.2, 1991.25F, "V", 6.93F);
		addStar ("", "   168", "4666   130 1", "", 00, 02, 08.05, -02, -49, -11.4, 1991.25F, "V", 9.56F);
		addStar ("", "   236", "4663   679 1", "", 00, 02, 57.08, -00, -53, -37.8, 1991.25F, "V", 8.09F);
		addStar ("", "   267", "4666   202 2", "", 00, 03, 20.50, -04, -8, -44.6, 1991.25F, "V", 8.09F);
		addStar ("", "117043", "5255   994 1", "", 23, 43, 36.21, -03, -18, -46.9, 1991.25F, "V", 8.81F);
		addStar ("", "117112", "5255  1146 1", "", 23, 44, 32.50, -03, -10, -31.3, 1991.25F, "V", 7.26F);
		addStar ("", "117151", "5252   250 1", "", 23, 45, 00.05, -00, -39, -37.2, 1991.25F, "V", 7.07F);
		addStar ("", "117176", "5252   652 1", "", 23, 45, 24.27, -01, -56, -43.5, 1991.25F, "V", 9.42F);
		addStar ("", "117215", " 586  1002 2", "", 23, 46, 00.10, +00, 15, 43.5, 1991.25F, "V", 7.95F);
		addStar ("", "117261", "5252   459 1", "", 23, 46, 34.74, -01, -31, -22.2, 1991.25F, "V", 9.75F);
		addStar ("", "117323", "5252   252 1", "", 23, 47, 22.55, -01, -30, -31.7, 1991.25F, "V", 9.26F);
		addStar ("", "117325", "5255   504 1", "", 23, 47, 23.52, -03, -54, -10.9, 1991.25F, "V", 9.06F);
		addStar ("", "117333", "5252  1023 1", "", 23, 47, 29.49, -02, -8, -58.2, 1991.25F, "V", 9.59F);
		addStar ("", "117352", "5255  1147 1", "", 23, 47, 39.19, -04, -27, -42.1, 1991.25F, "V", 7.56F);
		addStar ("", "117354", "5252   886 1", "", 23, 47, 41.99, -00, -45, -43.6, 1991.25F, "V", 7.11F);
		addStar ("20 Psc", "117375", "5255  1145 1", "", 23, 47, 56.49, -02, -45, -41.8, 1991.25F, "V", 5.49F);
		addStar ("", "117395", "5252   478 1", "", 23, 48, 12.70, -00, -46, -29.5, 1991.25F, "V", 8.54F);
		addStar ("", "117438", "5255   298 1", "", 23, 48, 45.14, -04, -26, -06.8, 1991.25F, "V", 8.08F);
		addStar ("", "117457", " 586   735 1", "", 23, 48, 57.89, +00, 26, 16.9, 1991.25F, "V", 8.93F);
		addStar ("", "117612", "5253   771 1", "", 23, 51, 09.46, -01, -56, -10.1, 1991.25F, "V", 9.71F);
		addStar ("", "117614", "5256    91 1", "", 23, 51, 09.84, -02, -31, -13.3, 1991.25F, "V", 7.86F);
		addStar ("", "117641", "5256   151 1", "", 23, 51, 28.88, -03, -24, -13.9, 1991.25F, "V", 7.91F);
		addStar ("", "117644", "5256   352 1", "", 23, 51, 32.56, -03, -30, -30.5, 1991.25F, "V", 8.62F);
		addStar ("", "117739", "5253   382 1", "", 23, 52, 42.82, -00, -48, -29.7, 1991.25F, "V", 10.22F);
		addStar ("24 Psc", "117761", "5256   186 1", "", 23, 52, 55.52, -3, -9, -19.4, 1991.25F, "V", 5.93F);
		addStar ("", "117820", "5253  1102 1", "", 23, 53, 41.35, -01, -39, -38.7, 1991.25F, "V", 8.62F);
		addStar ("", "117875", "5256   841 1", "", 23, 54, 34.78, -02, -58, -46.6, 1991.25F, "V", 8.4F);
		addStar ("", "117881", "5253  1164 1", "", 23, 54, 38.66, -01, -56, -46.3, 1991.25F, "V", 7.58F);
		addStar ("", "117887", " 587  1283 1", "", 23, 54, 46.65, +00, 06, 33.6, 1991.25F, "V", 5.78F);
		addStar ("", "117902", "5253  1079 1", "", 23, 54, 52.93, -00, -17, -08.2, 1991.25F, "V", 8.36F);
		addStar ("", "117937", "5253   244 1", "", 23, 55, 22.52, -01, -04, -45.5, 1991.25F, "V", 9.64F);
		addStar ("", "118028", "5253   669 1", "", 23, 56, 27.76, -00, -55, -56.3, 1991.25F, "V", 9.1F);
		addStar ("", "118073", "5256    27 1", "", 23, 57, 04.31, -02, -36, -51.6, 1991.25F, "V", 9.07F);
		addStar ("", "118156", "5253   846 1", "", 23, 58, 02.84, -01, -58, -48.1, 1991.25F, "V", 8.95F);
		addStar ("", "118159", "5253   655 1", "", 23, 58, 04.56, -00, -07, -41.3, 1991.25F, "V", 9.02F);
		addStar ("", "118166", "5256   610 1", "", 23, 58, 09.20, -03, -58, -44.9, 1991.25F, "V", 8.65F);
		addStar ("", "118186", "5256   744 1", "", 23, 58, 23.60, -03, -21, -16.5, 1991.25F, "V", 8.4F);
		addStar ("", "118199", "5253  1123 2", "", 23, 58, 31.30, -01, -41, -18.6, 1991.25F, "V", 8.94F);
		addStar ("27 Psc", "118209", "5256  1131 1", "", 23, 58, 40.41, -03, -33, -20.9, 1991.25F, "V", 4.88F);
		addStar ("", "118286", "5256  1129 1", "", 23, 59, 31.30, -02, -50, -37.7, 1991.25F, "V", 7.12F);
		addStar ("", "118293", "5253  1139 1", "", 23, 59, 34.95, -01, -50, -59.1, 1991.25F, "V", 7.49F);
		addStar ("", "118307", "5253   343 1", "", 23, 59, 46.49, -00, -16, -48.2, 1991.25F, "V", 6.83F);
		addStar ("", "118312", "5253  1144 1", "", 23, 59, 49.06, -02, -06, -45.2, 1991.25F, "V", 8.35F);
		addStar ("", "", "   1   286 1", "", 00, 02, 06.45, +00, 24, 55.2, 1991.25F, "V", 9.15F);
		addStar ("", "", "   1   325 1", "", 00, 01, 47.60, +00, 11, 47.4, 1991.25F, "V", 11.59F);
		addStar ("", "", "   1   451 1", "", 00, 01, 27.63, +00, 18, 05.7, 1991.25F, "V", 9.19F);
		addStar ("", "", "   1   800 1", "", 00, 00, 34.53, +00, 10, 29.5, 1991.25F, "V", 10.93F);
		addStar ("", "", "   1   870 1", "", 00, 00, 13.79, +00, 13, 12.2, 1991.25F, "V", 11.24F);
		addStar ("", "", "   1   976 1", "", 00, 01, 36.39, +00, 14, 09.4, 1991.25F, "V", 10.43F);
		addStar ("", "", "   1   981 1", "", 00, 01, 57.97, +00, 07, 43.3, 1991.25F, "V", 9.34F);
		addStar ("", "", "   1  1058 1", "", 00, 00, 39.10, +00, 18, 54.3, 1991.25F, "V", 10.76F);
		addStar ("", "", "   1  1115 1", "", 00, 01, 24.23, +00, 15, 05.6, 1991.25F, "V", 10.65F);
		addStar ("", "", "   1  1167 1", "", 00, 00, 27.72, +00, 12, 17.8, 1991.25F, "V", 9.25F);
		addStar ("", "", " 586   266 1", "", 23, 47, 41.73, +00, 11, 47.8, 1991.25F, "V", 9.78F);
		addStar ("", "", " 586   896 1", "", 23, 48, 26.48, +00, 11, 43.9, 1991.25F, "V", 11.0F);
		addStar ("", "", " 586   952 1", "", 23, 48, 50.38, +00, 07, 06.0, 1991.25F, "V", 10.52F);
		addStar ("", "", " 587    10 1", "", 23, 56, 57.55, +00, 9, 33.4, 1991.25F, "V", 10.1F);
		addStar ("", "", " 587    11 1", "", 23, 50, 08.69, +00, 11, 40.8, 1991.25F, "V", 10.86F);
		addStar ("", "", " 587    20 1", "", 23, 53, 32.63, +00, 11, 46.3, 1991.25F, "V", 10.78F);
		addStar ("", "", " 587    50 1", "", 23, 54, 05.04, +00, 13, 36.5, 1991.25F, "V", 9.97F);
		addStar ("", "", " 587    89 1", "", 23, 53, 42.24, +00, 10, 27.8, 1991.25F, "V", 10.28F);
		addStar ("", "", " 587   154 1", "", 23, 54, 33.67, +00, 8, 01.7, 1991.25F, "V", 10.94F);
		addStar ("", "", " 587   268 1", "", 23, 52, 36.77, +00, 03, 44.0, 1991.25F, "V", 11.17F);
		addStar ("", "", " 587   345 1", "", 23, 54, 58.94, +00, 00, 49.5, 1991.25F, "V", 10.3F);
		addStar ("", "", " 587   403 1", "", 23, 53, 06.77, +00, 20, 42.2, 1991.25F, "V", 11.09F);
		addStar ("", "", " 587   430 1", "", 23, 52, 09.38, +00, 21, 39.9, 1991.25F, "V", 11.3F);
		addStar ("", "", " 587   432 1", "", 23, 59, 10.94, +00, 13, 27.2, 1991.25F, "V", 10.98F);
		addStar ("", "", " 587   548 1", "", 23, 58, 19.89, +00, 19, 29.3, 1991.25F, "V", 10.22F);
		addStar ("", "", " 587   616 1", "", 23, 54, 10.44, +00, 24, 44.0, 1991.25F, "V", 9.39F);
		addStar ("", "", " 587   779 1", "", 23, 58, 40.13, +00, 23, 30.4, 1991.25F, "V", 10.91F);
		addStar ("", "", "4663    16 1", "", 00, 02, 17.07, -00, -21, -35.9, 1991.25F, "V", 10.79F);
		addStar ("", "", "4663    95 1", "", 00, 02, 03.59, -01, -33, -08.6, 1991.25F, "V", 10.26F);
		addStar ("", "", "4663   125 1", "", 00, 00, 09.01, -00, -03, -52.5, 1991.25F, "V", 10.67F);
		addStar ("", "", "4663   223 1", "", 00, 03, 32.58, -00, -55, -37.2, 1991.25F, "V", 11.42F);
		addStar ("", "", "4663   257 1", "", 00, 03, 17.40, -01, -00, -06.0, 1991.25F, "V", 10.58F);
		addStar ("", "", "4663   416 1", "", 00, 02, 13.59, -00, -29, -06.9, 1991.25F, "V", 9.65F);
		addStar ("", "", "4663   665 1", "", 00, 01, 35.22, -00, -8, -16.5, 1991.25F, "V", 10.07F);
		addStar ("", "", "4663   766 1", "", 00, 03, 18.84, -00, -9, -49.8, 1991.25F, "V", 9.49F);
		addStar ("", "", "4663   797 1", "", 00, 01, 54.81, -01, -01, -36.4, 1991.25F, "V", 11.34F);
		addStar ("", "", "4663   823 1", "", 00, 00, 32.66, -01, -55, -45.1, 1991.25F, "V", 11.02F);
		addStar ("", "", "4663   862 1", "", 00, 02, 54.55, -01, -54, -02.9, 1991.25F, "V", 10.79F);
		addStar ("", "", "4663   893 1", "", 00, 00, 46.06, -02, -03, -47.3, 1991.25F, "V", 10.81F);
		addStar ("", "", "4663   934 1", "", 00, 01, 22.97, -01, -37, -17.1, 1991.25F, "V", 10.42F);
		addStar ("", "", "4663   969 1", "", 00, 02, 17.18, -02, -8, -20.5, 1991.25F, "V", 9.71F);
		addStar ("", "", "4663  1059 1", "", 00, 03, 08.55, -01, -49, -27.4, 1991.25F, "V", 10.86F);
		addStar ("", "", "4663  1120 1", "", 00, 00, 29.50, -02, -23, -21.7, 1991.25F, "V", 9.37F);
		addStar ("", "", "4663  1207 1", "", 00, 01, 15.27, -02, -20, -25.5, 1991.25F, "V", 9.08F);
		addStar ("", "", "4663  1260 1", "", 00, 00, 52.49, -02, -01, -00.1, 1991.25F, "V", 10.62F);
		addStar ("", "", "4666    30 1", "", 00, 00, 23.87, -02, -49, -32.6, 1991.25F, "V", 10.45F);
		addStar ("", "", "4666    70 1", "", 00, 01, 20.08, -02, -33, -53.4, 1991.25F, "V", 9.96F);
		addStar ("", "", "4666   174 1", "", 00, 02, 56.25, -03, -23, -00.6, 1991.25F, "V", 10.82F);
		addStar ("", "", "4666   179 1", "", 00, 02, 02.12, -03, -16, -27.9, 1991.25F, "V", 9.64F);
		addStar ("", "", "4666   290 1", "", 00, 03, 03.04, -03, -29, -19.3, 1991.25F, "V", 10.81F);
		addStar ("", "", "4666   398 1", "", 00, 03, 18.68, -03, -02, -22.7, 1991.25F, "V", 10.78F);
		addStar ("", "", "4666   400 1", "", 00, 01, 16.24, -03, -10, -23.5, 1991.25F, "V", 10.58F);
		addStar ("", "", "4666   484 1", "", 00, 00, 34.34, -03, -55, -13.2, 1991.25F, "V", 11.16F);
		addStar ("", "", "4666   494 1", "", 00, 00, 16.69, -02, -56, -51.1, 1991.25F, "V", 9.91F);
		addStar ("", "", "4666   498 1", "", 00, 00, 05.95, -03, -22, -43.5, 1991.25F, "V", 10.47F);
		addStar ("", "", "4666   590 1", "", 00, 02, 42.16, -03, -23, -27.2, 1991.25F, "V", 9.75F);
		addStar ("", "", "4666   799 1", "", 00, 02, 46.98, -02, -54, -59.1, 1991.25F, "V", 8.65F);
		addStar ("", "", "5252    92 1", "", 23, 47, 43.51, -00, -35, -12.3, 1991.25F, "V", 10.9F);
		addStar ("", "", "5252   104 1", "", 23, 46, 14.06, -00, -35, -17.6, 1991.25F, "V", 10.36F);
		addStar ("", "", "5252   177 1", "", 23, 47, 28.43, -00, -41, -44.7, 1991.25F, "V", 10.77F);
		addStar ("", "", "5252   178 1", "", 23, 43, 41.11, -00, -55, -03.2, 1991.25F, "V", 10.42F);
		addStar ("", "", "5252   231 1", "", 23, 46, 34.34, -01, -01, -27.1, 1991.25F, "V", 10.99F);
		addStar ("", "", "5252   247 1", "", 23, 49, 09.82, -01, -53, -23.3, 1991.25F, "V", 10.71F);
		addStar ("", "", "5252   282 1", "", 23, 47, 23.60, -00, -16, -11.2, 1991.25F, "V", 10.67F);
		addStar ("", "", "5252   289 1", "", 23, 48, 15.35, -01, -48, -03.1, 1991.25F, "V", 10.39F);
		addStar ("", "", "5252   350 1", "", 23, 49, 23.16, -00, -06, -14.4, 1991.25F, "V", 10.21F);
		addStar ("", "", "5252   366 1", "", 23, 47, 19.36, -00, -43, -53.1, 1991.25F, "V", 10.66F);
		addStar ("", "", "5252   401 1", "", 23, 45, 16.89, -00, -58, -35.3, 1991.25F, "V", 9.44F);
		addStar ("", "", "5252   521 1", "", 23, 46, 08.43, -00, -39, -36.1, 1991.25F, "V", 10.96F);
		addStar ("", "", "5252   522 1", "", 23, 43, 54.76, -00, -35, -09.6, 1991.25F, "V", 9.8F);
		addStar ("", "", "5252   603 1", "", 23, 46, 14.54, -00, -07, -13.9, 1991.25F, "V", 10.41F);
		addStar ("", "", "5252   701 1", "", 23, 44, 27.34, -02, -27, -21.4, 1991.25F, "V", 9.14F);
		addStar ("", "", "5252   712 1", "", 23, 44, 23.73, -01, -06, -39.8, 1991.25F, "V", 10.04F);
		addStar ("", "", "5252   730 1", "", 23, 47, 52.01, -02, -18, -18.2, 1991.25F, "V", 9.86F);
		addStar ("", "", "5252   739 1", "", 23, 47, 56.80, -00, -01, -59.3, 1991.25F, "V", 10.8F);
		addStar ("", "", "5252   749 1", "", 23, 49, 00.95, -02, -28, -06.1, 1991.25F, "V", 10.8F);
		addStar ("", "", "5252   763 1", "", 23, 46, 38.26, -01, -59, -21.8, 1991.25F, "V", 10.86F);
		addStar ("", "", "5252   792 1", "", 23, 47, 31.79, -02, -19, -19.0, 1991.25F, "V", 10.44F);
		addStar ("", "", "5252   814 1", "", 23, 48, 00.92, -01, -16, -39.7, 1991.25F, "V", 10.8F);
		addStar ("", "", "5252   815 1", "", 23, 47, 38.98, -01, -10, -41.4, 1991.25F, "V", 10.5F);
		addStar ("", "", "5252   840 1", "", 23, 44, 10.21, -00, -30, -04.2, 1991.25F, "V", 10.87F);
		addStar ("", "", "5252   851 1", "", 23, 46, 49.63, -01, -15, -28.1, 1991.25F, "V", 10.91F);
		addStar ("", "", "5252   866 1", "", 23, 48, 43.47, -01, -28, -35.3, 1991.25F, "V", 10.4F);
		addStar ("", "", "5252   918 1", "", 23, 48, 21.70, -02, -9, -21.3, 1991.25F, "V", 10.9F);
		addStar ("", "", "5252   934 1", "", 23, 43, 33.49, -01, -28, -38.9, 1991.25F, "V", 10.46F);
		addStar ("", "", "5252   962 1", "", 23, 49, 24.10, -01, -19, -14.6, 1991.25F, "V", 11.04F);
		addStar ("", "", "5252  1006 1", "", 23, 48, 11.66, -00, -30, -34.5, 1991.25F, "V", 10.97F);
		addStar ("", "", "5252  1015 1", "", 23, 47, 01.02, -01, -35, -10.9, 1991.25F, "V", 10.22F);
		addStar ("", "", "5253    12 1", "", 23, 59, 10.74, -00, -29, -59.2, 1991.25F, "V", 8.68F);
		addStar ("", "", "5253    21 1", "", 23, 58, 26.04, -01, -04, -56.9, 1991.25F, "V", 10.43F);
		addStar ("", "", "5253    35 1", "", 23, 59, 21.38, -01, -37, -09.8, 1991.25F, "V", 10.45F);
		addStar ("", "", "5253    37 1", "", 23, 57, 11.09, -00, -38, -57.7, 1991.25F, "V", 9.95F);
		addStar ("", "", "5253    98 1", "", 23, 59, 44.69, -00, -16, -46.1, 1991.25F, "V", 11.05F);
		addStar ("", "", "5253    99 1", "", 23, 59, 10.30, -00, -35, -00.4, 1991.25F, "V", 9.23F);
		addStar ("", "", "5253   123 1", "", 23, 55, 51.52, -00, -33, -35.7, 1991.25F, "V", 9.88F);
		addStar ("", "", "5253   144 1", "", 23, 56, 50.03, -00, -30, -34.1, 1991.25F, "V", 9.57F);
		addStar ("", "", "5253   195 1", "", 23, 58, 46.56, -00, -53, -48.5, 1991.25F, "V", 10.22F);
		addStar ("", "", "5253   200 1", "", 23, 50, 52.46, -00, -9, -33.6, 1991.25F, "V", 10.69F);
		addStar ("", "", "5253   207 1", "", 23, 53, 52.50, -01, -42, -08.1, 1991.25F, "V", 11.27F);
		addStar ("", "", "5253   213 1", "", 23, 50, 28.59, -00, -30, -58.3, 1991.25F, "V", 10.31F);
		addStar ("", "", "5253   226 1", "", 23, 54, 22.57, -00, -46, -08.6, 1991.25F, "V", 10.41F);
		addStar ("", "", "5253   242 1", "", 23, 52, 59.57, -00, -18, -06.7, 1991.25F, "V", 10.57F);
		addStar ("", "", "5253   243 1", "", 23, 50, 03.95, -00, -18, -10.6, 1991.25F, "V", 10.26F);
		addStar ("", "", "5253   248 1", "", 23, 50, 05.47, -00, -18, -20.8, 1991.25F, "V", 11.21F);
		addStar ("", "", "5253   249 1", "", 23, 56, 27.24, -00, -35, -13.7, 1991.25F, "V", 10.38F);
		addStar ("", "", "5253   260 1", "", 23, 51, 36.20, -00, -18, -39.5, 1991.25F, "V", 11.43F);
		addStar ("", "", "5253   281 1", "", 23, 57, 52.05, -01, -01, -52.7, 1991.25F, "V", 10.6F);
		addStar ("", "", "5253   312 1", "", 23, 54, 36.10, -00, -37, -21.0, 1991.25F, "V", 10.37F);
		addStar ("", "", "5253   332 1", "", 23, 59, 59.76, -00, -03, -55.1, 1991.25F, "V", 10.37F);
		addStar ("", "", "5253   339 1", "", 23, 54, 35.22, -00, -53, -41.8, 1991.25F, "V", 10.75F);
		addStar ("", "", "5253   394 1", "", 23, 54, 44.59, -00, -47, -59.3, 1991.25F, "V", 10.79F);
		addStar ("", "", "5253   395 1", "", 23, 57, 43.20, -00, -15, -09.4, 1991.25F, "V", 10.47F);
		addStar ("", "", "5253   397 1", "", 23, 55, 57.31, -00, -17, -56.5, 1991.25F, "V", 10.39F);
		addStar ("", "", "5253   409 1", "", 23, 52, 57.41, -01, -43, -43.3, 1991.25F, "V", 10.24F);
		addStar ("", "", "5253   415 1", "", 23, 58, 03.47, -01, -38, -41.5, 1991.25F, "V", 11.26F);
		addStar ("", "", "5253   420 1", "", 23, 57, 21.61, -02, -21, -01.3, 1991.25F, "V", 10.71F);
		addStar ("", "", "5253   425 1", "", 23, 55, 17.62, -01, -34, -22.3, 1991.25F, "V", 9.64F);
		addStar ("", "", "5253   472 1", "", 23, 57, 57.30, -01, -9, -47.7, 1991.25F, "V", 10.41F);
		addStar ("", "", "5253   590 1", "", 23, 59, 52.55, -01, -44, -10.5, 1991.25F, "V", 10.8F);
		addStar ("", "", "5253   640 1", "", 23, 52, 44.57, -01, -00, -54.8, 1991.25F, "V", 9.96F);
		addStar ("", "", "5253   649 1", "", 23, 53, 10.41, -01, -34, -13.2, 1991.25F, "V", 9.68F);
		addStar ("", "", "5253   690 1", "", 23, 58, 37.08, -00, -10, -03.1, 1991.25F, "V", 11.51F);
		addStar ("", "", "5253   691 1", "", 23, 55, 36.01, -02, -19, -50.3, 1991.25F, "V", 9.44F);
		addStar ("", "", "5253   698 1", "", 23, 55, 35.14, -00, -10, -44.1, 1991.25F, "V", 10.18F);
		addStar ("", "", "5253   702 1", "", 23, 56, 22.66, -00, -26, -18.4, 1991.25F, "V", 10.96F);
		addStar ("", "", "5253   705 1", "", 23, 59, 50.95, -01, -11, -48.1, 1991.25F, "V", 9.24F);
		addStar ("", "", "5253   741 1", "", 23, 52, 36.14, -02, -22, -06.3, 1991.25F, "V", 9.11F);
		addStar ("", "", "5253   749 1", "", 23, 53, 40.97, -01, -38, -50.6, 1991.25F, "V", 10.42F);
		addStar ("", "", "5253   781 1", "", 23, 53, 46.34, -02, -20, -18.3, 1991.25F, "V", 11.16F);
		addStar ("", "", "5253   806 1", "", 23, 58, 01.17, -02, -22, -19.3, 1991.25F, "V", 8.52F);
		addStar ("", "", "5253   877 1", "", 23, 52, 28.09, -01, -9, -58.3, 1991.25F, "V", 10.43F);
		addStar ("", "", "5253   889 1", "", 23, 53, 56.48, -02, -13, -11.8, 1991.25F, "V", 9.6F);
		addStar ("", "", "5253   890 1", "", 23, 53, 49.63, -01, -17, -01.3, 1991.25F, "V", 9.93F);
		addStar ("", "", "5253   892 1", "", 23, 55, 24.72, -02, -06, -39.3, 1991.25F, "V", 9.78F);
		addStar ("", "", "5253   923 1", "", 23, 57, 02.43, -02, -8, -40.6, 1991.25F, "V", 10.29F);
		addStar ("", "", "5253   959 1", "", 23, 55, 00.16, -02, -24, -06.8, 1991.25F, "V", 10.12F);
		addStar ("", "", "5253   969 1", "", 23, 52, 24.35, -00, -55, -59.7, 1991.25F, "V", 10.73F);
		addStar ("", "", "5253   986 1", "", 23, 53, 20.59, -02, -9, -18.1, 1991.25F, "V", 10.66F);
		addStar ("", "", "5253   987 1", "", 23, 53, 13.22, -02, -22, -26.7, 1991.25F, "V", 10.32F);
		addStar ("", "", "5253  1002 1", "", 23, 50, 33.24, -02, -03, -58.2, 1991.25F, "V", 10.52F);
		addStar ("", "", "5253  1094 1", "", 23, 54, 34.98, -00, -35, -06.8, 1991.25F, "V", 8.77F);
		addStar ("", "", "5253  1114 1", "", 23, 56, 54.88, -02, -7, -33.8, 1991.25F, "V", 9.6F);
		addStar ("", "", "5255     3 1", "", 23, 46, 22.09, -02, -41, -14.0, 1991.25F, "V", 10.81F);
		addStar ("", "", "5255    22 1", "", 23, 45, 22.70, -02, -37, -13.6, 1991.25F, "V", 9.21F);
		addStar ("", "", "5255    23 1", "", 23, 49, 50.76, -02, -44, -42.9, 1991.25F, "V", 10.29F);
		addStar ("", "", "5255    60 1", "", 23, 49, 44.81, -02, -33, -59.7, 1991.25F, "V", 9.57F);
		addStar ("", "", "5255    69 1", "", 23, 47, 45.07, -02, -45, -02.5, 1991.25F, "V", 9.76F);
		addStar ("", "", "5255   104 1", "", 23, 49, 22.92, -02, -34, -26.6, 1991.25F, "V", 10.53F);
		addStar ("", "", "5255   121 1", "", 23, 45, 40.98, -02, -40, -27.1, 1991.25F, "V", 10.88F);
		addStar ("", "", "5255   204 1", "", 23, 46, 22.73, -03, -27, -02.7, 1991.25F, "V", 10.26F);
		addStar ("", "", "5255   224 1", "", 23, 47, 20.15, -04, -28, -15.2, 1991.25F, "V", 10.88F);
		addStar ("", "", "5255   251 1", "", 23, 46, 46.01, -03, -24, -49.4, 1991.25F, "V", 10.21F);
		addStar ("", "", "5255   255 1", "", 23, 48, 09.45, -04, -11, -16.1, 1991.25F, "V", 10.85F);
		addStar ("", "", "5255   263 1", "", 23, 49, 57.58, -03, -35, -19.4, 1991.25F, "V", 9.37F);
		addStar ("", "", "5255   303 1", "", 23, 46, 05.11, -03, -18, -18.4, 1991.25F, "V", 9.69F);
		addStar ("", "", "5255   329 1", "", 23, 44, 07.21, -04, -10, -59.2, 1991.25F, "V", 10.7F);
		addStar ("", "", "5255   350 1", "", 23, 46, 07.98, -03, -24, -42.6, 1991.25F, "V", 9.27F);
		addStar ("", "", "5255   354 1", "", 23, 46, 58.94, -03, -15, -11.2, 1991.25F, "V", 10.11F);
		addStar ("", "", "5255   476 1", "", 23, 46, 37.03, -03, -8, -23.1, 1991.25F, "V", 10.95F);
		addStar ("", "", "5255   539 1", "", 23, 43, 55.14, -02, -55, -46.3, 1991.25F, "V", 10.74F);
		addStar ("", "", "5255   554 1", "", 23, 48, 42.41, -02, -59, -14.4, 1991.25F, "V", 10.57F);
		addStar ("", "", "5255   588 1", "", 23, 48, 10.31, -03, -29, -04.3, 1991.25F, "V", 10.11F);
		addStar ("", "", "5255   596 1", "", 23, 48, 58.99, -03, -55, -58.8, 1991.25F, "V", 10.33F);
		addStar ("", "", "5255   711 1", "", 23, 43, 39.94, -03, -33, -59.6, 1991.25F, "V", 10.28F);
		addStar ("", "", "5255   756 1", "", 23, 43, 53.86, -03, -35, -54.1, 1991.25F, "V", 10.33F);
		addStar ("", "", "5255   782 1", "", 23, 44, 38.03, -04, -23, -00.6, 1991.25F, "V", 10.53F);
		addStar ("", "", "5255   854 1", "", 23, 46, 28.02, -03, -00, -22.2, 1991.25F, "V", 9.63F);
		addStar ("", "", "5255   874 1", "", 23, 45, 12.43, -03, -41, -52.7, 1991.25F, "V", 10.82F);
		addStar ("", "", "5255   876 1", "", 23, 45, 48.35, -03, -16, -18.3, 1991.25F, "V", 10.69F);
		addStar ("", "", "5255   985 1", "", 23, 44, 31.68, -03, -42, -32.2, 1991.25F, "V", 10.83F);
		addStar ("", "", "5255  1034 1", "", 23, 48, 46.24, -03, -38, -20.4, 1991.25F, "V", 9.22F);
		addStar ("", "", "5255  1044 1", "", 23, 47, 41.18, -04, -19, -31.6, 1991.25F, "V", 10.15F);
		addStar ("", "", "5255  1096 1", "", 23, 45, 54.86, -04, -01, -32.9, 1991.25F, "V", 10.39F);
		addStar ("", "", "5255  1148 1", "", 23, 47, 39.89, -03, -32, -18.7, 1991.25F, "V", 8.73F);
		addStar ("", "", "5256     4 1", "", 23, 52, 54.10, -02, -35, -20.5, 1991.25F, "V", 9.88F);
		addStar ("", "", "5256     5 1", "", 23, 51, 40.02, -02, -32, -27.3, 1991.25F, "V", 8.64F);
		addStar ("", "", "5256    15 1", "", 23, 58, 50.11, -02, -47, -55.9, 1991.25F, "V", 10.43F);
		addStar ("", "", "5256    26 1", "", 23, 50, 42.36, -02, -38, -32.8, 1991.25F, "V", 10.16F);
		addStar ("", "", "5256    34 1", "", 23, 56, 06.26, -02, -40, -27.5, 1991.25F, "V", 8.81F);
		addStar ("", "", "5256    58 1", "", 23, 59, 31.24, -02, -36, -22.9, 1991.25F, "V", 10.7F);
		addStar ("", "", "5256    63 1", "", 23, 53, 07.70, -02, -34, -37.7, 1991.25F, "V", 10.08F);
		addStar ("", "", "5256    81 1", "", 23, 50, 45.46, -02, -38, -34.9, 1991.25F, "V", 12.79F);
		addStar ("", "", "5256   136 1", "", 23, 52, 15.91, -03, -44, -11.8, 1991.25F, "V", 10.25F);
		addStar ("", "", "5256   137 1", "", 23, 53, 40.03, -03, -39, -35.9, 1991.25F, "V", 11.22F);
		addStar ("", "", "5256   159 1", "", 23, 58, 53.52, -03, -45, -54.8, 1991.25F, "V", 10.51F);
		addStar ("", "", "5256   166 1", "", 23, 52, 44.11, -03, -10, -20.5, 1991.25F, "V", 10.14F);
		addStar ("", "", "5256   177 1", "", 23, 50, 25.75, -02, -59, -04.7, 1991.25F, "V", 10.56F);
		addStar ("", "", "5256   180 1", "", 23, 57, 53.64, -03, -36, -26.9, 1991.25F, "V", 9.87F);
		addStar ("", "", "5256   211 1", "", 23, 51, 02.02, -03, -33, -20.1, 1991.25F, "V", 9.36F);
		addStar ("", "", "5256   221 1", "", 23, 51, 41.06, -04, -21, -48.1, 1991.25F, "V", 10.24F);
		addStar ("", "", "5256   238 1", "", 23, 54, 03.56, -04, -16, -43.0, 1991.25F, "V", 8.97F);
		addStar ("", "", "5256   247 1", "", 23, 55, 54.98, -03, -07, -06.6, 1991.25F, "V", 9.8F);
		addStar ("", "", "5256   248 1", "", 23, 54, 20.72, -03, -37, -35.1, 1991.25F, "V", 11.13F);
		addStar ("", "", "5256   279 1", "", 23, 54, 46.82, -03, -04, -18.1, 1991.25F, "V", 10.11F);
		addStar ("", "", "5256   288 1", "", 23, 54, 36.04, -03, -33, -12.3, 1991.25F, "V", 9.25F);
		addStar ("", "", "5256   291 1", "", 23, 54, 50.67, -04, -30, -31.1, 1991.25F, "V", 10.43F);
		addStar ("", "", "5256   296 1", "", 23, 56, 14.66, -03, -29, -41.6, 1991.25F, "V", 8.99F);
		addStar ("", "", "5256   301 1", "", 23, 56, 05.78, -02, -54, -43.0, 1991.25F, "V", 10.84F);
		addStar ("", "", "5256   309 1", "", 23, 58, 43.00, -04, -11, -23.9, 1991.25F, "V", 10.59F);
		addStar ("", "", "5256   351 1", "", 23, 56, 47.01, -03, -13, -18.9, 1991.25F, "V", 9.98F);
		addStar ("", "", "5256   367 1", "", 23, 54, 42.64, -03, -27, -12.6, 1991.25F, "V", 9.32F);
		addStar ("", "", "5256   390 1", "", 23, 56, 11.53, -04, -24, -06.0, 1991.25F, "V", 11.08F);
		addStar ("", "", "5256   427 1", "", 23, 55, 17.32, -04, -11, -56.9, 1991.25F, "V", 10.92F);
		addStar ("", "", "5256   455 1", "", 23, 56, 39.75, -04, -17, -40.5, 1991.25F, "V", 10.66F);
		addStar ("", "", "5256   477 1", "", 23, 52, 41.71, -04, -17, -36.8, 1991.25F, "V", 9.61F);
		addStar ("", "", "5256   479 1", "", 23, 50, 09.24, -04, -24, -23.3, 1991.25F, "V", 10.16F);
		addStar ("", "", "5256   534 1", "", 23, 59, 00.02, -04, -13, -08.4, 1991.25F, "V", 10.88F);
		addStar ("", "", "5256   536 1", "", 23, 59, 16.49, -03, -13, -27.3, 1991.25F, "V", 9.99F);
		addStar ("", "", "5256   544 1", "", 23, 57, 04.31, -02, -58, -32.2, 1991.25F, "V", 8.7F);
		addStar ("", "", "5256   616 1", "", 23, 54, 58.30, -04, -8, -03.0, 1991.25F, "V", 10.61F);
		addStar ("", "", "5256   620 1", "", 23, 58, 05.69, -04, -24, -14.3, 1991.25F, "V", 10.45F);
		addStar ("", "", "5256   639 1", "", 23, 57, 12.57, -03, -8, -32.3, 1991.25F, "V", 10.21F);
		addStar ("", "", "5256   659 1", "", 23, 58, 38.40, -04, -05, -47.7, 1991.25F, "V", 10.75F);
		addStar ("", "", "5256   701 1", "", 23, 56, 57.99, -04, -15, -09.8, 1991.25F, "V", 10.94F);
		addStar ("", "", "5256   703 1", "", 23, 52, 13.81, -04, -22, -45.1, 1991.25F, "V", 10.87F);
		addStar ("", "", "5256   737 1", "", 23, 56, 20.14, -03, -13, -22.7, 1991.25F, "V", 10.57F);
		addStar ("", "", "5256   757 1", "", 23, 52, 27.50, -04, -13, -17.6, 1991.25F, "V", 10.61F);
		addStar ("", "", "5256   760 1", "", 23, 55, 29.59, -03, -41, -36.6, 1991.25F, "V", 11.18F);
		addStar ("", "", "5256   764 1", "", 23, 50, 25.23, -03, -20, -15.1, 1991.25F, "V", 10.27F);
		addStar ("", "", "5256   800 1", "", 23, 53, 58.17, -03, -15, -18.4, 1991.25F, "V", 10.5F);
		addStar ("", "", "5256   802 1", "", 23, 59, 09.55, -03, -50, -26.6, 1991.25F, "V", 9.86F);
		addStar ("", "", "5256   804 1", "", 23, 51, 32.37, -03, -28, -59.9, 1991.25F, "V", 8.25F);
		addStar ("", "", "5256   821 1", "", 23, 58, 35.50, -04, -07, -02.1, 1991.25F, "V", 9.92F);
		addStar ("", "", "5256   832 1", "", 23, 55, 56.64, -04, -14, -42.1, 1991.25F, "V", 10.36F);
		addStar ("", "", "5256   851 1", "", 23, 50, 16.84, -03, -26, -30.6, 1991.25F, "V", 10.39F);
		addStar ("", "", "5256   897 1", "", 23, 52, 54.02, -03, -28, -55.4, 1991.25F, "V", 10.74F);
		addStar ("", "", "5256   918 1", "", 23, 51, 14.55, -04, -25, -29.8, 1991.25F, "V", 9.88F);
		addStar ("", "", "5256   953 1", "", 23, 52, 54.93, -03, -28, -36.3, 1991.25F, "V", 10.52F);
		addStar ("", "", "5256   954 1", "", 23, 57, 43.91, -03, -45, -56.4, 1991.25F, "V", 10.21F);
		addStar ("", "", "5256   979 1", "", 23, 56, 11.39, -03, -58, -34.7, 1991.25F, "V", 9.99F);
		addStar ("", "", "5256   991 1", "", 23, 53, 50.97, -03, -22, -59.0, 1991.25F, "V", 11.39F);
		addStar ("", "", "5256   996 1", "", 23, 52, 22.38, -03, -23, -49.3, 1991.25F, "V", 9.26F);
		addStar ("", "", "5256   998 1", "", 23, 58, 51.78, -04, -17, -16.9, 1991.25F, "V", 10.1F);
		addStar ("", "", "5256  1065 1", "", 23, 58, 22.20, -04, -04, -47.2, 1991.25F, "V", 10.09F);
		addStar ("", "", "5256  1071 1", "", 23, 57, 13.57, -03, -48, -04.2, 1991.25F, "V", 10.78F);
		addStar ("", "", "5256  1100 1", "", 23, 58, 20.45, -04, -26, -14.0, 1991.25F, "V", 10.68F);
	} // addStars

	@Override
	public void paintComponent (java.awt.Graphics g)
	{
		java.awt.Graphics2D g2 = (java.awt.Graphics2D) g;
		g2.setRenderingHint (java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
		g2.drawImage (starImage, 0, 0, this);
		int x0 = starImage.getWidth () / 2;
		int y0 = starImage.getHeight () / 2;

		if (null != jupiter)
		{
			double dx = jupiter.xdd * xScale;
			double dy = jupiter.zdd * yScale;
			int xPlot = (int) StrictMath.round (x0 + dx);
			int yPlot = (int) StrictMath.round (y0 - dy);
			jupiter.setPlotPoint (new java.awt.Point (xPlot, yPlot));
			g2.setPaint (JUPITER_COLOUR);
			g2.fillOval (xPlot - JUPITER_RADIUS, yPlot - JUPITER_RADIUS, JUPITER_DIAMETER, JUPITER_DIAMETER);
		}

		if (null != uranus)
		{
			double dx = uranus.xdd * xScale;
			double dy = uranus.zdd * yScale;
			int xPlot = (int) StrictMath.round (x0 + dx);
			int yPlot = (int) StrictMath.round (y0 - dy);
			uranus.setPlotPoint (new java.awt.Point (xPlot, yPlot));
			g2.setPaint (URANUS_COLOUR);
			g2.fillOval (xPlot - URANUS_RADIUS, yPlot - URANUS_RADIUS, URANUS_DIAMETER, URANUS_DIAMETER);
		}

		if (null != jupiter && null != uranus)
		{
			g2.setPaint (java.awt.Color.BLUE);
			java.awt.Point jPt = jupiter.getPlotPoint ();
			java.awt.Point uPt = uranus.getPlotPoint ();
			g2.drawLine (jPt.x, jPt.y, uPt.x, uPt.y);
			g2.setPaint (java.awt.Color.RED);
			int xMid = (jPt.x + uPt.x) / 2;
			int yMid = (jPt.y + uPt.y) / 2;
			net.grelf.astro.SkyVector sepn = jupiter.getPosition ().calculateSeparation (uranus.getPosition ());
			double sepnDegs = sepn.getSeparation ();
			g2.drawString (DF2.format (sepnDegs) + "\u00b0", xMid, yMid);
		}

		if (null != starNearestMouse)
		{
			g2.setPaint (java.awt.Color.RED);
			java.awt.Point pt = starNearestMouse.getPlotPoint ();
			drawCross (g2, pt.x, pt.y);
			net.grelf.astro.SkyPoint skyPt = starNearestMouse.getPosition ();
			int xs = pt.x + 12;

			if (pt.x > x0)
			{
				xs = pt.x - 90;
			}

			int ys = pt.y + 12;

			if (pt.y > y0)
			{
				ys = pt.y - 60;
			}

			g2.drawString (starNearestMouse.getId (), xs, ys);
			g2.drawString (skyPt.getRA ().toString (), xs, ys + 12);
			net.grelf.astro.Dec dec = skyPt.getDec ();
			g2.drawString (dec.getDegree () + "\u00b0" + 
							DI2.format (Math.abs (dec.getMin ())) +"\'" +
							DI2.format (Math.abs (dec.getSec ())) + "\"", xs, ys + 24);
			g2.drawString (skyPt.getEpoch ().toString (), xs, ys + 36);
			g2.drawString ("mv " + DF2.format (starNearestMouse.getMagnitude ().getValue ()), xs, ys + 48);
		}
	} // paintComponent

	private static final int CROSS_ARM = 3;

	private void drawCross (java.awt.Graphics2D g2, int x, int y)
	{
		g2.drawLine (x - CROSS_ARM, y, x + CROSS_ARM, y);
		g2.drawLine (x, y - CROSS_ARM, x, y + CROSS_ARM);
	} // drawCross

	private static final java.text.DecimalFormat DF2 = new java.text.DecimalFormat ("0.00");
	private static final java.text.DecimalFormat DI2 = new java.text.DecimalFormat ("00");

	/** Get the maximum level which can occur for each channel in the image. */
	private int getMaxLevel (java.awt.image.BufferedImage bim)
	{
		switch (bim.getSampleModel ().getSampleSize (0))
		{
			case 16: return 65535;
			case 15: return 32767;
			case 14: return 16383;
			case 13: return  8191;
			case 12: return  4095;
			case 11: return  2047;
			case 10: return  1023;
			case  9: return   511;
			case  8: return   255;
			case  7: return   127;
			case  6: return    63;
			case  5: return    31;
			case  4: return    15;
			case  3: return     7;
			case  2: return     3;
			case  1: return     1;
			case  0: return     0;
			default: return 65535;
		}
	} // getMaxLevel

	/** Indices of returned array: [x][y][band] */
	private float [][] calculateShape (int maxLevel, int halfWidth)
	{
		int kwd = 2 * halfWidth + 1;
		float [][] data = new float [kwd][kwd];
		float halfHeightRadius = halfWidth / 2.0F;
		net.grelf.Gaussian gaussian = new net.grelf.Gaussian_ (0, halfHeightRadius);

		for (int ky = 0, y = -halfWidth; ky < kwd; ky++, y++)
		{
			for (int kx = 0, x = -halfWidth; kx < kwd; kx++, x++)
			{
				data [kx][ky] = maxLevel * gaussian.calc (x) * gaussian.calc (y);
			}
		}

		return data;
	} // calculateShape

	private void drawStars (java.awt.image.BufferedImage bim)
	{
		int wd = bim.getWidth ();
		int wd2 = wd / 2;
		int ht = bim.getHeight ();
		int ht2 = ht / 2;
		int nBands = bim.getSampleModel ().getNumBands ();
		int maxLevel = getMaxLevel (bim);
		int [] px = new int [nBands];
		java.awt.image.WritableRaster wr = bim.getRaster ();
		int x0 = wd2;
		int y0 = ht2;

		float [][] shape = calculateShape (maxLevel, STAR_RADIUS); // Indices: [x][y]

		for (net.grelf.astro.Star star : this.stars)
		{
			double dx = star.xdd * xScale;
			double dy = star.zdd * yScale;
			int xPlot = (int) StrictMath.round (x0 + dx);
			int yPlot = (int) StrictMath.round (y0 - dy);
			star.setPlotPoint (new java.awt.Point (xPlot, yPlot));
			float magFactor = getMagnitudeFactor (star.getMagnitude ());

			int pxValue = 0;

			for (int y = yPlot - STAR_RADIUS, yData = 0; y <= yPlot + STAR_RADIUS; y++, yData++)
			{
				if (y >= 0 && y < ht)
				{
					for (int x = xPlot - STAR_RADIUS, xData = 0; x <= xPlot + STAR_RADIUS; x++, xData++)
					{
						if (x >= 0 && x < wd)
						{
							wr.getPixel (x, y, px);
							pxValue = (int) (shape [xData][yData] * magFactor);

							for (int band = 0; band < nBands; band++)
							{
								px [band] += pxValue;
							}

							wr.setPixel (x, y, px);
						}
					}
				}
			}
		}

		autoStretch (bim);
		java.awt.Graphics2D g2 = bim.createGraphics ();
		g2.setPaint (java.awt.Color.WHITE);
		double minDecDegs = -4.5;
		double maxDecDegs = 0.5;
		int dy = (int) (chartHeightPx / (maxDecDegs - minDecDegs));

		for (int decDegs = -4, y = chartHeightPx - dy / 2; decDegs < 1; decDegs++, y -= dy)
		{
			g2.drawLine (0, y, 10, y);
			g2.drawString (decDegs + "\u00b0", 12, y);
		}

		double minRaMins = -16;
		double maxRaMins = 4;
		int dx = 4 * (int) (chartWidthPx / (maxRaMins - minRaMins));

		for (int raMins = -12, x = chartWidthPx - dx; raMins <= 0; raMins += 4, x -= dx)
		{
			g2.drawLine (x, 0, x, 10);

			if (raMins == 0)
			{
				g2.drawString ("0h0m", x + 4, 16);
			}
			else
			{
				g2.drawString ("23h" + (60 + raMins) + "m", x + 4, 16);
			}
		}
	} // drawStars

	private float getMagnitudeFactor (net.grelf.astro.Magnitude m)
	{
		float v = m.getValue ();

		if (v <  1) return 1.0F;
		if (v <  2) return 0.90F; //0.63F;
		if (v <  3) return 0.80F; //0.40F;
		if (v <  4) return 0.69F; //0.25F;
		if (v <  5) return 0.58F; //0.16F;

		if (v <  6) return 0.46F;  //0.1F;
		if (v <  7) return 0.34F;  //0.063F;
		if (v <  8) return 0.22F; //0.040F;
		if (v <  9) return 0.10F; //0.025F;
		if (v < 10) return 0.090F; //0.016F;

		if (v < 11) return 0.080F; //0.01F;
		if (v < 12) return 0.069F; //0.0063F;
		if (v < 13) return 0.058F; //0.0040F;
		if (v < 14) return 0.046F; //0.0025F;
		if (v < 15) return 0.034F; //0.0016F;

		if (v < 16) return 0.022F; //0.001F;
		if (v < 17) return 0.010F; //0.00063F;

		return 0.009F; //0.00040F;
	} // getMagnitudeFactor

	protected double cos90ap;
	protected double sin90ap;
	protected double cosdp;
	protected double sindp;
	protected double sinFieldRadius;

	/** Calculate certain fields just once so they do not have to be calculated for every star.
	 * This needs to be called once a data set for a star chart has been obtained successfully but before
	 * retrieving the stars from it. */
	protected void initialiseChartCoordinates (net.grelf.astro.SkyPoint plotCentre, double fieldRadiusDegs)
	{
		double raDegs = plotCentre.getRA ().toDegrees ();
		double decDegs = plotCentre.getDec ().toDegrees ();
		double ap90rad = StrictMath.toRadians (90.0 - raDegs);
		cos90ap = StrictMath.cos (ap90rad);
		sin90ap = StrictMath.sin (ap90rad);
		double dprad = StrictMath.toRadians (decDegs);
		cosdp = StrictMath.cos (-dprad);
		sindp = StrictMath.sin (-dprad);
		sinFieldRadius = StrictMath.sin (StrictMath.toRadians (fieldRadiusDegs));
	} // initialiseChartCoordinates

	/** This needs to be done after retrieving each star from the data set for the chart. */
	protected void calculateChartCoordinates (net.grelf.astro.Star star)
	{
		net.grelf.astro.SkyPoint pt = star.getPosition ();
		double raRadians = StrictMath.toRadians (pt.getRA ().toDegrees ());
		double decRadians = StrictMath.toRadians (pt.getDec ().toDegrees ());
		double cosDec = StrictMath.cos (decRadians);
		double x = StrictMath.cos (raRadians) * cosDec;
		double y = StrictMath.sin (raRadians) * cosDec;
		double z = StrictMath.sin (decRadians);
		star.xdd = cos90ap * x - sin90ap * y;
		star.zdd = sindp * sin90ap * x + sindp * cos90ap * y + cosdp * z;
	} // calculateChartCoordinates

	/** Stretch the contrast in the image so the full range of levels is used. */
	public void autoStretch (java.awt.image.BufferedImage bim)
	{
		java.awt.Point topLeft = new java.awt.Point (0, 0);
		java.awt.Point bottomRight = new java.awt.Point (bim.getWidth () - 1, bim.getHeight () - 1);
		java.awt.image.WritableRaster wr = bim.getRaster ();
		int nb = bim.getSampleModel ().getNumBands ();
		int maxLevel = getMaxLevel (bim);
		int [] px = new int [nb];
		int [] min = new int [nb];
		int [] max = new int [nb];

		for (int b = 0; b < nb; b++)
		{
			min [b] = maxLevel;
			max [b] = 0;
		}

		for (int y = topLeft.y; y <= bottomRight.y; y++)
		{
			for (int x = topLeft.x; x <= bottomRight.x; x++)
			{
				wr.getPixel (x, y, px);

				for (int b = 0; b < nb; b++)
				{
					if (px [b] > max [b]) max [b] = px [b];
					else if (px [b] < min [b]) min [b] = px [b];
				}
			}
		}

		int overallMin = maxLevel;
		int overallMax = 0;

		for (int b = 0; b < nb ; b++)
		{
			if (overallMin > min [b]) overallMin = min [b];
			if (overallMax < max [b]) overallMax = max [b];
		}

		float scale = ((float) maxLevel) / (overallMax - overallMin);

		for (int y = topLeft.y; y <= bottomRight.y; y++)
		{
			for (int x = topLeft.x; x <= bottomRight.x; x++)
			{
				wr.getPixel (x, y, px);

				for (int band = 0; band < nb; band++)
				{
					px [band] = (int) ((px [band] - overallMin) * scale);
				}

				wr.setPixel (x, y, px);
			}
		}
	} // autoStretch

	@Override
	public void mouseDragged (java.awt.event.MouseEvent ev) {}

	@Override
	public void mouseMoved (java.awt.event.MouseEvent ev)
	{
		java.awt.Point pt = ev.getPoint ();
		this.starNearestMouse = findNearestStar (pt.x, pt.y);
		repaint ();
	} // mouseMoved

	private net.grelf.astro.Star starNearestMouse;

	/** Return the star nearest to the given chart coordinates. */
	public net.grelf.astro.Star findNearestStar (int x, int y)
	{
		double minD = chartWidthPx;
		net.grelf.astro.Star nearest = null;

		for (net.grelf.astro.Star star : this.stars)
		{
			java.awt.Point pt = star.getPlotPoint ();
			int dx = pt.x - x;
			int dy = pt.y - y;
			double d = StrictMath.sqrt (dx * dx + dy * dy);

			if (d < minD)
			{
				minD = d;
				nearest = star;
			}
		}

		return nearest;
	} // findNearestStar

} // Chart
