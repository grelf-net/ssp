package net.grelf.planet;

/** Each instance represents Venus at a given instant.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class Venus extends Planet
{
	/** Constructs apparent position at earth-bound observer's Julian Ephemeris Day, allowing for light time. */
	public Venus (double observerJED, Earth earth) throws WrongRowNumberException
	{
		super ("Venus");
		this.observerJED = observerJED;
		this.distanceFromEarthAU = 2.0; // First guess
		calcPosition (observerJED); // - Planet.lightTimeDays (this.distanceFromEarthAU));
/*
		report ("Venus L=" + this.longitudeHeliocentricDegs + " B=" + this.latitudeHeliocentricDegs +
						" R=" + this.radiusVectorAU + "delta=" + this.distanceFromEarthAU +
						"light time=" + Planet.lightTimeDays (this.distanceFromEarthAU));
*/
		adjustForLightTime (earth);
/*
		report ("Venus L=" + this.longitudeHeliocentricDegs + " B=" + this.latitudeHeliocentricDegs +
						" R=" + this.radiusVectorAU + "delta=" + this.distanceFromEarthAU +
						"light time=" + Planet.lightTimeDays (this.distanceFromEarthAU));
*/
	} // Venus

	@Override
	protected  double calcLDegs (double tau) throws WrongRowNumberException
	{
		double l0 = sumSeries (VENUS_L0, tau);
		double l1 = sumSeries (VENUS_L1, tau);
		double l2 = sumSeries (VENUS_L2, tau);
		double l3 = sumSeries (VENUS_L3, tau);
		double l4 = sumSeries (VENUS_L4, tau);
		double l5 = sumSeries (VENUS_L5, tau);
		return StrictMath.toDegrees (((((((((l5 * tau + l4) * tau) + l3) * tau) + l2) * tau) + l1) * tau + l0) * 1.0e-8);
	} // calcLDegs

	@Override
	protected  double calcBDegs (double tau) throws WrongRowNumberException
	{
		double b0 = sumSeries (VENUS_B0, tau);
		double b1 = sumSeries (VENUS_B1, tau);
		double b2 = sumSeries (VENUS_B2, tau);
		double b3 = sumSeries (VENUS_B3, tau);
		double b4 = sumSeries (VENUS_B4, tau);
		return StrictMath.toDegrees ((((((((b4 * tau) + b3) * tau) + b2) * tau) + b1) * tau + b0) * 1.0e-8);
	} // calcBDegs

	@Override
	protected  double calcRAU (double tau) throws WrongRowNumberException
	{
		double r0 = sumSeries (VENUS_R0, tau);
		double r1 = sumSeries (VENUS_R1, tau);
		double r2 = sumSeries (VENUS_R2, tau);
		double r3 = sumSeries (VENUS_R3, tau);
		double r4 = sumSeries (VENUS_R4, tau);
		return (((((((r4 * tau) + r3) * tau) + r2) * tau) + r1) * tau + r0) * 1.0e-8;
	} // calcRAU

	private static final double [] VENUS_L0 = new double []
	{
		1, 317614667, 0, 0,
		2, 1353968, 5.5931332, 10213.2855462,
		3, 89892, 5.30650, 20426.57109,
		4, 5477, 4.4163, 7860.4194,
		5, 3456, 2.6996, 11790.6291,
		6, 2372, 2.9938, 3930.2097,
		7, 1664, 4.2502, 1577.3435,
		8, 1438, 4.1575, 9683.5946,
		9, 1317, 5.1867, 26.2983,
		10, 1201, 6.1536, 30639.8566,
		11, 769, 0.816, 9437.763,
		12, 761, 1.950, 529.691,
		13, 708, 1.065, 775.523,
		14, 585, 3.998, 191.448,
		15, 500, 4.123, 15720.839,
		16, 429, 3.586, 19367.189,
		17, 327, 5.677, 5507.553,
		18, 326, 4.591, 10404.734,
		19, 232, 3.163, 9153.904,
		20, 180, 4.653, 1109.379,
		21, 155, 5.570, 19651.048,
		22, 128, 4.226, 20.775,
		23, 128, 0.962, 5661.332,
		24, 106, 1.537, 801.821
	};

	private static final double [] VENUS_L1 = new double []
	{
		1, 1021352943053.0, 0, 0,
		2, 95708, 2.46424, 10213.28555,
		3, 14445, 0.51625, 20426.57109,
		4, 213, 1.795, 30639.857,
		5, 174, 2.655, 26.298,
		6, 152, 6.106, 1577.344,
		7, 82, 5.70,191.45,
		8, 70, 2.68, 9437.76,
		9, 52, 3.60, 775.52,
		10, 38, 1.03, 529.69,
		11, 30, 1.25, 5507.55,
		12, 25, 6.11, 10404.73
	};

	private static final double [] VENUS_L2 = new double []
	{
		1, 54127, 0, 0,
		2, 3891, 0.3451, 10213.2855,
		3, 1338, 2.0201, 20426.5711,
		4, 24, 2.05, 26.30,
		5, 19, 3.54, 30639.86,
		6, 10, 3.97, 775.52,
		7, 7, 1.52, 1577.34,
		8, 6, 1.00, 191.45
	};

	private static final double [] VENUS_L3 = new double []
	{
		1, 136, 4.804, 10213.286,
		2, 78, 3.67, 20426.57,
		3, 26, 0, 0
	};

	private static final double [] VENUS_L4 = new double []
	{
		1, 114, 3.1416, 0,
		2, 3, 5.21, 20426.57,
		3, 2, 2.51, 10213.29
	};

	private static final double [] VENUS_L5 = new double []
	{
		1, 1, 3.14, 0
	};

	private static final double [] VENUS_B0 = new double []
	{
		1, 5923638, 0.2670278, 10213.2855462,
		2, 40108, 1.14737, 20426.57109,
		3, 32815, 3.14159, 0,
		4, 1011, 1.0895, 30639.8566,
		5, 149, 6.254, 18073.705,
		6, 138, 0.860, 1577.344,
		7, 130, 3.672, 9437.763,
		8, 120, 3.705, 2352.866,
		9, 108, 4.539, 22003.915
	};

	private static final double [] VENUS_B1 = new double []
	{
		1, 513348, 1.803643, 10213.285546,
		2, 4380, 3.3862, 20426.5711,
		3, 199, 0, 0,
		4, 197, 2.530, 30639.857
	};

	private static final double [] VENUS_B2 = new double []
	{
		1, 22378, 3.38509, 10213.28555,
		2, 282, 0, 0,
		3, 173, 5.256, 20426.571,
		4, 27, 3.87, 30639.86
	};

	private static final double [] VENUS_B3 = new double []
	{
		1, 647, 4.992, 10213.286,
		2, 20, 3.14, 0,
		3, 6, 0.77, 20426.57,
		4, 3, 5.44, 30639.86
	};

	private static final double [] VENUS_B4 = new double []
	{
		1, 14, 0.32, 10213.29
	};

	private static final double [] VENUS_R0 = new double []
	{
		1, 72334821, 0, 0,
		2, 489824, 4.021518, 10213.285546,
		3, 1658, 4.9021, 20426.5711,
		4, 1632, 2.8455, 7860.4194,
		5, 1378, 1.1285, 11790.6291,
		6, 498, 2.587, 9683.595,
		7, 374, 1.423, 3930.210,
		8, 264, 5.529, 9437.763,
		9, 237, 2.551, 15720.839,
		10, 222, 2.013, 19367.189,
		11, 126, 2.728, 1577.344,
		12, 119, 3.020, 10404.734
	};

	private static final double [] VENUS_R1 = new double []
	{
		1, 34551, 0.89199, 10213.28555,
		2, 234, 1.772, 20426.571,
		3, 234, 3.142, 0
	};

	private static final double [] VENUS_R2 = new double []
	{
		1, 1407, 5.0637, 10213.2855,
		2, 16, 5.47, 20426.57,
		3, 13, 0, 0
	};

	private static final double [] VENUS_R3 = new double []
	{
		1, 50, 3.22, 10213.29
	};

	private static final double [] VENUS_R4 = new double []
	{
		1, 1, 0.92, 10213.29
	};

} // Venus
