package net.grelf.planet;

/** */
public class ButtonPanel extends javax.swing.JComponent implements java.awt.event.ActionListener
{
	private static final int PANEL_WIDTH = 798; // Pixels
	private static final int PANEL_HEIGHT = 50; // Pixels

	private AppletJU applet;
	private javax.swing.JButton jdButton = new javax.swing.JButton ("Julian day ");
	private javax.swing.JButton nowButton = new javax.swing.JButton ("Now");
	private javax.swing.JButton plusButton = new javax.swing.JButton ("+1 day");
	private javax.swing.JButton minusButton = new javax.swing.JButton ("-1 day");

	public ButtonPanel (AppletJU theApplet)
	{
		this.applet = theApplet;
		setSize (PANEL_WIDTH, PANEL_HEIGHT);
		setPreferredSize (new java.awt.Dimension (PANEL_WIDTH, PANEL_HEIGHT));
		this.setLayout (new java.awt.FlowLayout ());

		setJDButtonText ();
		this.add (this.jdButton);
		this.jdButton.addActionListener (this);
		
		this.add (this.minusButton);
		this.minusButton.addActionListener (this);

		this.add (this.plusButton);
		this.plusButton.addActionListener (this);

		this.add (this.nowButton);
		this.nowButton.addActionListener (this);
	} // ButtonPanel

	private static final java.text.SimpleDateFormat SDF = new java.text.SimpleDateFormat ("dd MMM yyyy");

	private void setJDButtonText ()
	{
		net.grelf.astro.JulianDate jd = this.applet.getJD ();
		java.util.Date date = jd.toGregorianCalendar ().getTime ();
		this.jdButton.setText ("Julian day " + jd.toString () +	" (" + SDF.format (date) + ")");
	} // setJDButtonText

	@Override
	public void actionPerformed (java.awt.event.ActionEvent event)
	{
		Object source = event.getSource ();

		if (source == this.jdButton)
		{
			String s = javax.swing.JOptionPane.showInputDialog (this, "Julian day?",
							                                this.applet.getJD ().toString ());

			if (null != s && 0 < s.length ())
			{
				try
				{
					double jd = Double.parseDouble (s);
					this.applet.setJulianDate (new net.grelf.astro.JulianDate (jd));
					setJDButtonText ();
					this.applet.recalculate ();
				}
				catch (NumberFormatException ex)
				{
					javax.swing.JOptionPane.showMessageDialog (this, "Invalid JD ignored");
				}
			}
		}
		else
		if (source == this.nowButton)
		{
			this.applet.setJulianDate (new net.grelf.astro.JulianDate ());
			setJDButtonText ();
			this.applet.recalculate ();
		}
		else
		if (source == this.minusButton)
		{
			double jd = this.applet.getJD ().toDouble ();
			this.applet.setJulianDate (new net.grelf.astro.JulianDate (jd - 1.0));
			setJDButtonText ();
			this.applet.recalculate ();
		}
		else
		if (source == this.plusButton)
		{
			double jd = this.applet.getJD ().toDouble ();
			this.applet.setJulianDate (new net.grelf.astro.JulianDate (jd + 1.0));
			setJDButtonText ();
			this.applet.recalculate ();
		}
	} // actionPerformed

} // ButtonPanel
