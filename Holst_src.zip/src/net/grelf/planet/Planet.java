package net.grelf.planet;

/** Abstract base class which any planet must extend.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public abstract class Planet
{
	public Planet (String theName) { this.name = theName; }

	protected String name;
	public String getName () { return this.name; }

	protected double distanceFromEarthAU;
	public double getDistanceFromEarthAU () { return this.distanceFromEarthAU; }

	protected double observerJED;
	/** Observer's (on Earth) Julian Ephemeris Day. */
	public double getObserverJED () { return this.observerJED; }

	protected double longitudeHeliocentricDegs;
	public double getLongitudeHeliocentricDegs () { return this.longitudeHeliocentricDegs; }

	protected double latitudeHeliocentricDegs;
	public double getLatitudeHeliocentricDegs () { return this.latitudeHeliocentricDegs;}

	protected double radiusVectorAU;
	public double getRadiusVectorAU () { return this.radiusVectorAU; }

	private static final double LIGHT_DAYS_PER_AU = 0.0057755183;

	/** Utility to compute light time in days for a given distance in AU. */
	public static double lightTimeDays (double distanceAU)
	{
		return LIGHT_DAYS_PER_AU * distanceAU;
	} // lightTimeDays

	protected void calcPosition (double jed) throws WrongRowNumberException
	{
		double tauMillennia = (jed - net.grelf.astro.JulianDate.J2000) / 365250.0;
		this.longitudeHeliocentricDegs = net.grelf.Maths.in360 (calcLDegs (tauMillennia));
		this.latitudeHeliocentricDegs = calcBDegs (tauMillennia);
		this.radiusVectorAU = calcRAU (tauMillennia);
	} // calcPosition

	/** Recalculate the position, iterating on the light time. */
	protected void adjustForLightTime (Earth earth) throws WrongRowNumberException
	{
		final double EPSILON = 1.0e-12;
		double _LDegs, _BDegs, rAU, _DeltaAU;
		int iter = 1;

		do
		{
			_LDegs = this.longitudeHeliocentricDegs;
			_BDegs = this.latitudeHeliocentricDegs;
			rAU = this.radiusVectorAU;
			_DeltaAU = this.distanceFromEarthAU;
			net.grelf.XYZ xyz = getEclipticalGeocentricCoordinates (earth);
			this.distanceFromEarthAU = xyz.getRadius ();
			calcPosition (this.observerJED - Planet.lightTimeDays (this.distanceFromEarthAU));
//			report ("Iteration " + iter + ": x = " + xyz.x + ", y = " + xyz.y + ", z = " + xyz.z);
			iter++;
		}
		while (EPSILON * _LDegs > StrictMath.abs (_LDegs - this.longitudeHeliocentricDegs)
				&& EPSILON * _BDegs > StrictMath.abs (_BDegs - this.latitudeHeliocentricDegs)
				&& EPSILON * rAU  > StrictMath.abs (rAU - this.radiusVectorAU)
				&& EPSILON * _DeltaAU > StrictMath.abs (_DeltaAU - this.distanceFromEarthAU));
	} // adjustForLightTime

	abstract protected double calcLDegs (double tau) throws WrongRowNumberException;
	abstract protected double calcBDegs (double tau) throws WrongRowNumberException;
	abstract protected double calcRAU (double tau) throws WrongRowNumberException;

	/** Sum series of coefficients as given in Appendix III of Astronomical Algorithms by Jean Meeus.
	 * Use is explained in Chapter 32 of the same book. */
	protected double sumSeries (double [] coefficients, double tauMillennia) throws WrongRowNumberException
	{
		double sum = 0.0;
		int nRows = coefficients.length / 4;

//		for (int i = 0, row = 1; i < coefficients.length; i += 4, row++)
		for (int i = coefficients.length - 4, row = nRows; i >= 0; i -= 4, row--)
		{
			if (coefficients [i] != row) throw new WrongRowNumberException (row);
			// Some slight protection against data transcription errors

			sum += coefficients [i + 1] * StrictMath.cos (coefficients [i + 2] + tauMillennia * coefficients [i + 3]);
			       // A * cos (B + Ct)
		}

		return sum;
	} // sumSeries

	public net.grelf.XYZ getHeliocentricCoordinates ()
	{
		double cosB = net.grelf.Maths.cosDegs (this.latitudeHeliocentricDegs);
		double sinB = net.grelf.Maths.sinDegs (this.latitudeHeliocentricDegs);
		double cosL = net.grelf.Maths.cosDegs (this.longitudeHeliocentricDegs);
		double sinL = net.grelf.Maths.sinDegs (this.longitudeHeliocentricDegs);
		double rAU = this.radiusVectorAU;
		net.grelf.XYZ xyz = new net.grelf.XYZ ();
		xyz.x = rAU * cosB * cosL;
		xyz.y = rAU * cosB * sinL;
		xyz.z = rAU * sinB;
		return xyz;
	} // getHeliocentricCoordinates

	/** Get ecliptical geocentric position. */
	public net.grelf.XYZ getEclipticalGeocentricCoordinates (net.grelf.planet.Earth earth)
	{
		double cosB = net.grelf.Maths.cosDegs (this.latitudeHeliocentricDegs);
		double sinB = net.grelf.Maths.sinDegs (this.latitudeHeliocentricDegs);
		double cosL = net.grelf.Maths.cosDegs (this.longitudeHeliocentricDegs);
		double sinL = net.grelf.Maths.sinDegs (this.longitudeHeliocentricDegs);
		double rAU = this.radiusVectorAU;
		double cosEarthB = net.grelf.Maths.cosDegs (earth.getLatitudeHeliocentricDegs ());
		double sinEarthB = net.grelf.Maths.sinDegs (earth.getLatitudeHeliocentricDegs ());
		double cosEarthL = net.grelf.Maths.cosDegs (earth.getLongitudeHeliocentricDegs ());
		double sinEarthL = net.grelf.Maths.sinDegs (earth.getLongitudeHeliocentricDegs ());
		double rEarthAU = earth.getRadiusVectorAU ();
		net.grelf.XYZ xyz = new net.grelf.XYZ ();
		xyz.x = rAU * cosB * cosL - rEarthAU * cosEarthB * cosEarthL;
		xyz.y = rAU * cosB * sinL - rEarthAU * cosEarthB * sinEarthL;
		xyz.z = rAU * sinB - rEarthAU * sinEarthB;
/*
		report ("Earth: x = " + (rEarthAU * cosEarthB * cosEarthL) +
				            ", y = " + (rEarthAU * cosEarthB * sinEarthL) +
										", z = " + (rEarthAU * sinEarthB));
		report (this.name + xyz.toString ());
*/
		return xyz;
	} // getEclipticalGeocentricCoordinates

	/** Gets apparent position at the given epoch. */
	public net.grelf.astro.SkyPoint getSkyPoint (Earth earth, net.grelf.astro.Epoch epoch)
	{
		net.grelf.XYZ jXYZ = getEclipticalGeocentricCoordinates (earth);
		net.grelf.astro.SkyPoint pt = getSkyPoint (earth, jXYZ);
		pt.changeEpoch (epoch);
		return pt;
	} // getSkyPoint

	/** Gets apparent position at mean equinox of date. */
	private net.grelf.astro.SkyPoint getSkyPoint (Earth earth, net.grelf.XYZ geocentricEclipticalCoordinates)
	{
		double dx = geocentricEclipticalCoordinates.x;
		double dy = geocentricEclipticalCoordinates.y;
		double dz = geocentricEclipticalCoordinates.z;

		// Get ecliptical longitude and latitude:
		double lambdaRads = StrictMath.atan2 (dy, dx);
		double betaRads = StrictMath.atan2 (dz, StrictMath.sqrt (dx * dx + dy * dy));

		double dYears = (this.observerJED - net.grelf.astro.JulianDate.J2000) / 365.25;
		net.grelf.astro.Epoch epoch = new net.grelf.astro.Epoch ('J', (float)(2000.0 + dYears));
		double eclipticObliquityDegs = earth.getEclipticObliquityDegs (epoch);

		//Rotate from ecliptic to equatorial coordinates to get RA and Dec:
		double cosEpsilon = net.grelf.Maths.cosDegs (eclipticObliquityDegs);
		double sinEpsilon = net.grelf.Maths.sinDegs (eclipticObliquityDegs);
		double sinLambda = StrictMath.sin (lambdaRads);
		double cosLambda = StrictMath.cos (lambdaRads);
		double sinBeta = StrictMath.sin (betaRads);
		double cosBeta = StrictMath.cos (betaRads);
		double raDegs = net.grelf.Maths.in360 (
						net.grelf.Maths.atan2Degs (sinLambda * cosEpsilon - sinBeta * sinEpsilon / cosBeta, cosLambda));
		double decDegs = net.grelf.Maths.asinDegs (sinBeta * cosEpsilon + cosBeta * sinEpsilon * sinLambda);

		net.grelf.astro.SkyPoint pt =  new net.grelf.astro.SkyPoint (
						new net.grelf.astro.RA (raDegs),
						new net.grelf.astro.Dec (decDegs),
						epoch);
//		report (this.name + " " + pt.toString ());
		return pt;
	} // getSkyPoint

} // Planet
