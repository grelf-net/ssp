package net.grelf.planet;

/** Applet for displaying planets against star chart.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class AppletJU extends javax.swing.JApplet implements Runnable
{
	@Override
	public String getAppletInfo ()
	{
		return ("Jupiter and Uranus shown on a star chart for their conjunctions in 2010-11, Copyright \u00a9 grelf.net, UK, 2010");
	} // getAppletInfo

	private net.grelf.astro.JulianDate jd = new net.grelf.astro.JulianDate ();
	public net.grelf.astro.JulianDate getJD () { return this.jd; }

	/** For user interaction via ButtonPanel */
	protected void setJulianDate (net.grelf.astro.JulianDate jd) { this.jd = jd; }

	private Chart imagePanel;
	private ButtonPanel buttonPanel;

	protected void recalculate ()
	{
		this.imagePanel.plotPlanets (this.jd);
	} // recalculate

	@Override
	public void init ()
	{
		try
		{
//			javax.swing.UIManager.setLookAndFeel (javax.swing.UIManager.getSystemLookAndFeelClassName ());
			javax.swing.SwingUtilities.invokeAndWait (this);

    }
		catch (Exception ex)
		{
			System.err.println (ex.toString ());
			ex.printStackTrace ();
    }
	} // init

	/** Implementing Runnable */
	@Override
	public void run ()
	{
		net.grelf.astro.JulianDate nowJD = new net.grelf.astro.JulianDate ();
		setJulianDate (nowJD);

		javax.swing.JPanel pane = (javax.swing.JPanel) getContentPane ();
		pane.setLayout (new java.awt.BorderLayout ());
		net.grelf.astro.SkyPoint centre = new net.grelf.astro.SkyPoint (
						new net.grelf.astro.RA (23, 54, 0),
						new net.grelf.astro.Dec (-2, 0, 0),
						new net.grelf.astro.Epoch ('J', 2000.0F));
		double radiusDegs = 2.5;
		int chartWidthPx = 500;
		int chartHeightPx = 500;
		imagePanel = new Chart (jd, centre, radiusDegs, chartWidthPx, chartHeightPx);
		pane.add (imagePanel, java.awt.BorderLayout.NORTH);
		buttonPanel = new ButtonPanel (this);
		pane.add (buttonPanel, java.awt.BorderLayout.SOUTH);
		java.awt.Dimension size = new java.awt.Dimension (imagePanel.getWidth (),
						imagePanel.getHeight () + buttonPanel.getHeight ());
		pane.setSize (size);
		pane.setPreferredSize (size);
		addMouseMotionListener (imagePanel);
	} // run

} // Applet
