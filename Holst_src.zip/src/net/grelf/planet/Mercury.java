package net.grelf.planet;

/** Each instance represents Mercury at a given instant.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class Mercury extends Planet
{
	/** Constructs apparent position at earth-bound observer's Julian Ephemeris Day, allowing for light time. */
	public Mercury (double observerJED, Earth earth) throws WrongRowNumberException
	{
		super ("mercury");
		this.observerJED = observerJED;
		this.distanceFromEarthAU = 2.0; // First guess
		calcPosition (observerJED); // - Planet.lightTimeDays (this.distanceFromEarthAU));
/*
		report ("Mercury L=" + this.longitudeHeliocentricDegs + " B=" + this.latitudeHeliocentricDegs +
						" R=" + this.radiusVectorAU + "delta=" + this.distanceFromEarthAU +
						"light time=" + Planet.lightTimeDays (this.distanceFromEarthAU));
*/
		adjustForLightTime (earth);
/*
		report ("Mercury L=" + this.longitudeHeliocentricDegs + " B=" + this.latitudeHeliocentricDegs +
						" R=" + this.radiusVectorAU + "delta=" + this.distanceFromEarthAU +
						"light time=" + Planet.lightTimeDays (this.distanceFromEarthAU));
*/
	} // Mercury

	@Override
	protected  double calcLDegs (double tau) throws WrongRowNumberException
	{
		double l0 = sumSeries (MERCURY_L0, tau);
		double l1 = sumSeries (MERCURY_L1, tau);
		double l2 = sumSeries (MERCURY_L2, tau);
		double l3 = sumSeries (MERCURY_L3, tau);
		double l4 = sumSeries (MERCURY_L4, tau);
		double l5 = sumSeries (MERCURY_L5, tau);
		return StrictMath.toDegrees (((((((((l5 * tau + l4) * tau) + l3) * tau) + l2) * tau) + l1) * tau + l0) * 1.0e-8);
	} // calcLDegs

	@Override
	protected  double calcBDegs (double tau) throws WrongRowNumberException
	{
		double b0 = sumSeries (MERCURY_B0, tau);
		double b1 = sumSeries (MERCURY_B1, tau);
		double b2 = sumSeries (MERCURY_B2, tau);
		double b3 = sumSeries (MERCURY_B3, tau);
		double b4 = sumSeries (MERCURY_B4, tau);
		return StrictMath.toDegrees ((((((((b4 * tau) + b3) * tau) + b2) * tau) + b1) * tau + b0) * 1.0e-8);
	} // calcBDegs

	@Override
	protected  double calcRAU (double tau) throws WrongRowNumberException
	{
		double r0 = sumSeries (MERCURY_R0, tau);
		double r1 = sumSeries (MERCURY_R1, tau);
		double r2 = sumSeries (MERCURY_R2, tau);
		double r3 = sumSeries (MERCURY_R3, tau);
		return (((((r3 * tau) + r2) * tau) + r1) * tau + r0) * 1.0e-8;
	} // calcRAU

	private static final double [] MERCURY_L0 = new double []
	{
		1,440250710,0,0,
		2,40989415,1.48302034,26087.90314157,
		3,5046294,4.4778549,52175.8062831,
		4,855347,1.165203,78263.709425,
		5,165590,4.119692,104351.612566,
		6,34562,0.77931,130439.51571,
		7,7583,3.7135,156527.4188,
		8,3560,1.5120,1109.3786,
		9,1803,4.1033,5661.3320,
		10,1726,0.3583,182615.3220,
		11,1590,2.9951,25028.5212,
		12,1365,4.5992,27197.2817,
		13,1017,0.8803,31749.2352,
		14,714,1.541,24978.525,
		15,644,5.303,21535.950,
		16,451,6.050,51116.424,
		17,404,3.282,208703.225,
		18,352,5.242,20426.571,
		19,345,2.792,15874.618,
		20,343,5.765,955.600,
		21,339,5.863,25558.212,
		22,325,1.337,53285.185,
		23,273,2.495,529.691,
		24,264,3.917,57837.138,
		25,260,0.987,4551.953,
		26,239,0.113,1059.382,
		27,235,0.267,11322.664,
		28,217,0.660,13521.751,
		29,209,2.092,47623.853,
		30,183,2.629,27043.503,
		31,182,2.434,25661.305,
		32,176,4.536,51066.428,
		33,173,2.452,24498.830,
		34,142,3.360,37410.567,
		35,138,0.291,10213.286,
		36,125,3.721,39669.655,
		37,118,2.781,77204.327,
		38,106,4.206,19804.827
	};

	private static final double [] MERCURY_L1 = new double []
	{
		1,2608814706223.0,0,0,
		2,1126008,6.2170397,26087.9031416,
		3,303471,3.055655,52175.806283,
		4,80538,6.10455,78263.70942,
		5,21245,2.83532,104351.61257,
		6,5592,5.8268,130439.5157,
		7,1472,2.5185,156527.4188,
		8,388,5.480,182615.322,
		9,352,3.052,1109.379,
		10,103,2.149,208703.225,
		11,94,6.12,27197.28,
		12,91,0.00,24978.52,
		13,52,5.62,5661.33,
		14,44,4.57,25028.52,
		15,28,3.04,51066.43,
		16,27,5.09,234791.13
	};

	private static final double [] MERCURY_L2 = new double []
	{
		1,53050,0,0,
		2,16904,4.69072,26087.90314,
		3,7397,1.3474,52175.8063,
		4,3018,4.4564,78263.7094,
		5,1107,1.2623,104351.6126,
		6,378,4.320,130439.516,
		7,123,1.069,156527.419,
		8,39,4.08,182615.32,
		9,15,4.63,1109.38,
		10,12,0.79,208703.23
	};

	private static final double [] MERCURY_L3 = new double []
	{
		1,188,0.035,52175.806,
		2,142,3.125,26087.903,
		3,97,3.00,78263.71,
		4,44,6.02,104351.61,
		5,35,0,0,
		6,18,2.78,130439.52,
		7,7,5.82,156527.42,
		8,3,2.57,182615.32
	};

	private static final double [] MERCURY_L4 = new double []
	{
		1,114,3.1416,0,
		2,3,2.03,26087.90,
		3,2,1.42,78263.71,
		4,2,4.50,52175.81,
		5,1,4.50,104351.61,
		6,1,1.27,130439.52
	};

	private static final double [] MERCURY_L5 = new double []
	{
		1,1,3.14,0
	};

	private static final double [] MERCURY_B0 = new double []
	{
		1,11737529,1.98357499,26087.90314157,
		2,2388077,5.0373896,52175.8062831,
		3,1222840,3.1415927,0,
		4,543252,1.796444,78263.709425,
		5,129779,4.832325,104351.612566,
		6,31867,1.58088,130439.51571,
		7,7963,4.6097,156527.4188,
		8,2014,1.3532,182615.3220,
		9,514,4.378,208703.225,
		10,209,2.020,24978.525,
		11,208,4.918,27197.282,
		12,132,1.119,234791.128,
		13,121,1.813,53285.185,
		14,100,5.657,20426.571
	};

	private static final double [] MERCURY_B1 = new double []
	{
		1,429151,3.501698,26087.903142,
		2,146234,3.141593,0,
		3,22675,0.01515,52175.80628,
		4,10895,0.48540,78263.70942,
		5,6353,3.4294,104351.6126,
		6,2496,0.1605,130439.5157,
		7,860,3.185,156527.419,
		8,278,6.210,182615.322,
		9,86,2.95,208703.23,
		10,28,0.29,27197.28,
		11,26,5.98,234791.13
	};

	private static final double [] MERCURY_B2 = new double []
	{
		1,11831,4.79066,26087.90314,
		2,1914,0,0,
		3,1045,1.2122,52175.8063,
		4,266,4.434,78263.709,
		5,170,1.623,104351.613,
		6,96,4.80,130439.52,
		7,45,1.61,156527.42,
		8,18,4.67,182615.32,
		9,7,1.43,208703.23
	};

	private static final double [] MERCURY_B3 = new double []
	{
		1,235,0.354,26087.903,
		2,161,0,0,
		3,19,4.36,52175.81,
		4,6,2.51,78263.71,
		5,5,6.14,104351.61,
		6,3,3.12,130439.52,
		7,2,6.27,156527.42
	};

	private static final double [] MERCURY_B4 = new double []
	{
		1,4,1.75,26087.90,
		2,1,3.14,0
	};

	private static final double [] MERCURY_R0 = new double []
	{
		1,39528272,0,0,
		2,7834132,6.1923372,26087.9031416,
		3,795526,2.959897,52175.806283,
		4,121282,6.010642,78263.709425,
		5,21922,2.77820,104351.61257,
		6,4354,5.8289,130439.5157,
		7,918,2.597,156527.419,
		8,290,1.424,25028.521,
		9,260,3.028,27197.282,
		10,202,5.647,182615.322,
		11,201,5.592,31749.235,
		12,142,6.253,24978.525,
		13,100,3.734,21535.950
	};

	private static final double [] MERCURY_R1 = new double []
	{
		1,217348,4.656172,26087.903142,
		2,44142,1.42386,52175.80628,
		3,10094,4.47466,78263.70942,
		4,2433,1.2423,104351.6126,
		5,1624,0,0,
		6,604,4.293,130439.516,
		7,153,1.061,156527.419,
		8,39,4.11,182615.32
	};

	private static final double [] MERCURY_R2 = new double []
	{
		1,3118,3.0823,26087.9031,
		2,1245,6.1518,52175.8063,
		3,425,2.926,78263.709,
		4,136,5.980,104351.613,
		5,42,2.75,130439.52,
		6,22,3.14,0,
		7,13,5.80,156527.42
	};

	private static final double [] MERCURY_R3 = new double []
	{
		1,33,1.68,26087.90,
		2,24,4.63,52175.81,
		3,12,1.39,78263.71,
		4,5,4.44,104351.61,
		5,2,1.21,130439.52
	};

} // Mercury
