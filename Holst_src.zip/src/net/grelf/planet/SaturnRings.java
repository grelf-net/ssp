package net.grelf.planet;

/** Record to hold major and minor axes of the outer ring, to enable it to be drawn as an ellipse.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class SaturnRings
{
	public double a, b;
} // Rings
