package net.grelf.planet;

/**
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class WrongRowNumberException extends Exception
{
	public WrongRowNumberException () { super (); }

	public WrongRowNumberException (int row) { super ("Row no: " + row); }

} // WrongRowNumberException
