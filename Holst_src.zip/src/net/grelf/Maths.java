package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Static methods to do common mathematical calculations. */
public class Maths
{
	private Maths () { /* Not instantiable */ }

	/** Find the mean of a set of angles, taking into account periodicity. Uses angleStatistics (). */
	public static double angleMean (double... anglesInDegrees)
	{
		Maths.Statistics stats = angleStatistics (anglesInDegrees);
		return stats.mean;
	} // angleMean

	/** Find the difference (a1 - a2) between 2 angles in degrees, taking into account periodicity.
		* The result is in the range -180..+180. */
	public static double angleDifference (double a1degrees, double a2degrees)
	{
		double diff = a1degrees - a2degrees;

		if (diff > 180.0) return diff - 360;

		if (diff < -180.0) return diff + 360;

		return diff;
	} // angleDifference

	/** Calculate the min, max, mean and stdDev of a set of angles, taking into account periodicity.
		* Uses angleDifference () from a working mean of the first angle. Does NOT use the erroneous
		* method you can find on the web that averages sin and cos and then takes atan2. */
	public static Maths.Statistics angleStatistics (double... anglesInDegrees)
	{
		final double NOT_SET = Double.POSITIVE_INFINITY;
		Maths.Statistics stats = new Maths.Statistics ();
		double minDiff = 0.0;
		double maxDiff = 0.0;
		double angle0degrees = NOT_SET;
		double sumDiff = 0.0;
		double sumDiffSq = 0.0;
		int n = 0;

		for (double angle : anglesInDegrees)
		{
			if (NOT_SET == angle0degrees) angle0degrees = angle;

			n++;
			double diff = angleDifference (angle, angle0degrees);
			sumDiff += diff;
			sumDiffSq += diff * diff;

			if (diff < minDiff) minDiff = diff;
			else if (diff > maxDiff) maxDiff = diff;
		}

		stats.n = n;
		stats.min = in360 (angle0degrees + minDiff);
		stats.max = in360 (angle0degrees + maxDiff);
		stats.mean = in360 (angle0degrees + sumDiff / n);
		stats.stdDev = StrictMath.sqrt (sumDiffSq / n - stats.mean * stats.mean);
		return stats;
	} // angleStatistics

	/** Calculate the min, max, mean and stdDev of a set of angles, taking into account periodicity.
		* Uses angleDifference () from a working mean of the first angle. Does NOT use the erroneous
		* method you can find on the web that averages sin and cos and then takes atan2. */
	public static Maths.Statistics angleStatistics (java.util.List <Double> anglesInDegrees)
	{
		double [] a = new double [anglesInDegrees.size ()];

		for (int i = 0; i < a.length; i++)
		{
			a [i] = anglesInDegrees.get (i);
		}

		return angleStatistics (a);
	} // angleStatistics

	/** Convert angle x (degrees) to lie in range 0..360.<br>
		* 10.4.7 deprecated - use synonymous in360 () instead. */
	@Deprecated
	public static double angleNormalise (double xDegs)
	{
		return in360 (xDegs);
	} // angleNormalise

	/** Convert angle x (degrees) to lie in range 0..360 */
	public static double in360 (double xDegs)
	{
		double x360 = xDegs % 360.0;

		if (x360 >= 0.0) return x360;

		return x360 + 360.0;
	} // in360

	/** Get arccos in degrees. */
	public static double acosDegs (double cos)
	{
		return toDegrees (StrictMath.acos (cos));
	} // acosDegs

	/** Get arcsin in degrees. */
	public static double asinDegs (double sin)
	{
		return toDegrees (StrictMath.asin (sin));
	} // asinDegs

	/** Hyperbolic inverse sine. */
	public static double asinh (double x)
	{
		return StrictMath.log (x + StrictMath.sqrt (x * x + 1.0));
	} // asinh

	/** Get atan2 in degrees. */
	public static double atan2Degs (double sin, double cos)
	{
		return toDegrees (StrictMath.atan2 (sin, cos));
	} // atan2Degs

	/** Get sine of an angle given in degrees. */
	public static double sinDegs (double xDegs)
	{
		return StrictMath.sin (toRadians (xDegs));
	} // sinDegs

	/** Get cosine of an angle given in degrees. */
	public static double cosDegs (double xDegs)
	{
		return StrictMath.cos (toRadians (xDegs));
	} // cosDegs

	/** Get tangent of an angle in degrees. */
	public static double tanDegs (double xDegs)
	{
		return StrictMath.tan (toRadians (xDegs));
	} // tanDegs

	/** Just a record to hold public values.
		* Differs from net.grelf.grip.Statistics because min and max are not int and there is no mode. */
	public static class Statistics
	{
		public int n;
		public double min, mean, max, stdDev;
	} // Statistics

	private static final double DEGREES_PER_RADIAN = 180.0 / StrictMath.PI;
	private static final double RADIANS_PER_DEGREE = StrictMath.PI / 180.0;

	private static double toDegrees (double xRads) { return xRads * DEGREES_PER_RADIAN; }
	private static double toRadians (double xDegs) { return xDegs * RADIANS_PER_DEGREE; }

} // Maths
