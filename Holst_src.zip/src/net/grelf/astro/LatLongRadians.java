package net.grelf.astro;

import net.grelf.Maths;

/** Simple record to hold latitude and longitude in radians, with conversion between epochs
 * according to Chapter 21 (p136) of Jean Meeus Astronomical Alogorithms.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class LatLongRadians
{
	public double latitude;
	public double longitude;

	/** Convert from J2000.0 to B1950.0 */
	public void convertJ2000toB1950 ()
	{
		double jd = JulianDate.B1950;
		double jd0 = JulianDate.J2000;
		convertEpoch (jd0, jd);
	} // convertJ2000toB1950

	public void convertEpoch (double fromJD, double toJD)
	{
		double vTCenturies = (fromJD - JulianDate.J2000) / 36525.0;
		double vT2 = vTCenturies * vTCenturies;
		double vtCenturies = (toJD - fromJD) / 36525.0;
		double etaDegs = (((0.000060 * vtCenturies - 0.03302 + 0.000598 * vTCenturies) * vtCenturies +
						47.0029 - 0.06603 * vTCenturies + 0.000598 * vT2) * vtCenturies) / 3600.0;
		double piDegs = (((0.03536 * vtCenturies) - 869.8089 + 0.50491 * vTCenturies) * vtCenturies +
						3289.4789 * vTCenturies + 0.60622 * vT2) / 3600.0 + 174.876384;
		double pDegs = ((-0.000006 * vtCenturies + 1.11113 - 0.000042 * vTCenturies) * vtCenturies +
						5029.0966 + 2.22226 * vTCenturies - 0.000042 * vT2) * vtCenturies / 3600.0;
		double coseta = Maths.cosDegs (etaDegs);
		double sineta = Maths.sinDegs (etaDegs);
		double piminuslong0Degs = piDegs - Math.toDegrees (this.longitude);
		double cospiminuslong0 = Maths.cosDegs (piminuslong0Degs);
		double sinpiminuslong0 = Maths.sinDegs (piminuslong0Degs);
		double coslat0 = Math.cos (this.latitude);
		double sinlat0 = Math.sin (this.latitude);
		double a = coseta * coslat0 * sinpiminuslong0 - sineta * sinlat0;
		double b = coslat0 * cospiminuslong0;
		double c = coseta * sinlat0 + sineta * coslat0 * sinpiminuslong0;
/*
System.out.println ("etaDegs = " + etaDegs);
System.out.println ("piDegs = " + piDegs);
System.out.println ("pDegs = " + pDegs);
System.out.println ("A = " + a);
System.out.println ("B = " + b);
System.out.println ("C = " + c);
*/
		this.latitude = Math.asin (c);
		this.longitude = Math.toRadians (pDegs + piDegs) - Math.atan2 (a, b);
	} // convertEpoch

} // LatLong
