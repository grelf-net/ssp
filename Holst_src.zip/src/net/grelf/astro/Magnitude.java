package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Type representing astronomical magnitude. NB: If a star's magnitude is unknown that fact is represented by
	* having a null magnitude. There is no Magnitude object having unknown value. Designed in such a way that band
	* ids can be ignored if desired. A band id can be any string of text but the conventional single-character
	* identifiers (I, B, V, R, etc) may be used.<br><br>
	* 9.12.20: Modified to add the bandId field and 2nd constructor using it; also added toXML (). */
public class Magnitude implements Cloneable, java.io.Serializable
{
	private float value;
	public float getValue () { return this.value; }

	private String bandId = "";
	/** Get band identifier, typically a single letter: U, B, V, R or I. */
	public String getBandId () { return this.bandId; }

	/** Unknown band - bandId set to empty string. */
	public Magnitude (float value)
	{
		this.value = value;
	} // Magnitude

	/** Band identifier is typically a single letter: U, B, V, R or I. */
	public Magnitude (float value, String bandId)
	{
		this (value);
		this.bandId = bandId;
	} // Magnitude

	private static final java.text.DecimalFormat DF = new java.text.DecimalFormat ("0.00");

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		Magnitude otherMagnitude = (Magnitude) other;

		if (otherMagnitude.value != this.value) return false;
		if (!otherMagnitude.bandId.equals (this.bandId)) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) (this.value * 7654321) + bandId.hashCode ();
	} // hashCode

	@Override
	public Magnitude clone ()
	{
		return new Magnitude (this.value, this.bandId);
	} // clone

	@Override
	public String toString ()
	{
		if (this.bandId.length () > 0)
		{
			return "(" + this.bandId + ")" + DF.format (this.value);
		}

		return DF.format (this.value);
	} // toString

	/** Creates a <Mag> element, either containing a simple value (if the band id is empty) or
		* 2 sub-elements: <Band> and <Value>. */
	public StringBuffer toXML ()
	{
		StringBuffer sb = new StringBuffer ();

		if (this.bandId.length () == 0)
		{
			sb.append ("<Mag>");
			sb.append (this.value);
			sb.append ("</Mag>");
		}
		else
		{
			// NB: Essential for loading .chart or .blobs that <Band> is before <Value>
			sb.append ("<Mag>");
			sb.append ("<Band>");
			sb.append (this.bandId);
			sb.append ("</Band>");
			sb.append ("<Value>");
			sb.append (this.value);
			sb.append ("</Value>");
			sb.append ("</Mag>");
		}

		return sb;
	} // toXML

} // Magnitude