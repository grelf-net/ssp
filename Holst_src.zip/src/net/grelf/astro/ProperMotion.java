package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Representing the proper motion of a star, in RA and Dec, with units (always) of arcsec per year. */
public class ProperMotion implements java.io.Serializable, Cloneable
{
	private double pmRA_arcsecPerYr = 0.0;
	public double getPmRA_arcsecPerYr () { return this.pmRA_arcsecPerYr; }
	private double pmDec_arcsecPerYr = 0.0;
	public double getPmDec_arcsecPerYr () { return this.pmDec_arcsecPerYr; }

	/** True if either RA or Dec fields are non-zero. */
	public boolean isKnown () { return this.pmRA_arcsecPerYr != 0.0 || this.pmDec_arcsecPerYr != 0.0; }

	public ProperMotion (double pmRA_arcsecPerYr, double pmDec_arcsecPerYr)
	{
		this.pmRA_arcsecPerYr = pmRA_arcsecPerYr;
		this.pmDec_arcsecPerYr = pmDec_arcsecPerYr;
	} // ProperMotion

	private static final double EPSILON = 1.0E-7;

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		ProperMotion otherPM = (ProperMotion) other;

		if (EPSILON < Math.abs (otherPM.pmRA_arcsecPerYr - this.pmRA_arcsecPerYr)) return false;
		if (EPSILON < Math.abs (otherPM.pmDec_arcsecPerYr - this.pmDec_arcsecPerYr)) return false;

		return true;
	} // equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) (31.0 * this.pmRA_arcsecPerYr + 43.0 * this.pmDec_arcsecPerYr);
	} // hashCode

	@Override
	public ProperMotion clone ()
	{
		return new ProperMotion (this.pmRA_arcsecPerYr, this.pmDec_arcsecPerYr);
	} // clone
	
	@Override
	public String toString ()
	{
		return "RA: " + DF4.format (this.pmRA_arcsecPerYr) + 
					" Dec: " + DF4.format (this.pmDec_arcsecPerYr) + " (arcsec/yr)";
	} // toString

	/** &lt;PM&gt; and sub-elements in a single line. */
	public StringBuffer toXML ()
	{
		StringBuffer sb = new StringBuffer ();
		sb.append ("<PM><RA>");
		sb.append (DF4.format (this.pmRA_arcsecPerYr));
		sb.append ("</RA><Dec>");
		sb.append (DF4.format (this.pmDec_arcsecPerYr));
		sb.append ("</Dec><Units>arcsec/yr</Units></PM>");
		return sb;
	} // toXML

	private static final java.text.DecimalFormat DF4 = new java.text.DecimalFormat ("0.0000");

} // ProperMotion
