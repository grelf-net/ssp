/** This package contains Java classes for astronomical applications. */
package net.grelf.astro;
