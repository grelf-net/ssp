package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Representation of Right Ascension (celestial longitude) in a compact form, just 4 bytes of data. Accurate to 0.01
	* seconds. */
public class RA implements Cloneable, java.io.Serializable
{
	private byte hour;		// Range 0..23
	private byte min;			// Range 0..59
	private byte secint;	// Range 0..59
	private byte secfrac; // Fractional part x 100. Range 0..99

	/** Range 0..23 */
	public byte getHour () { return this.hour; }

	/** Range 0..59 */
	public byte getMin () { return this.min; }

	/** Range 0.0..59.99 */
	public float getSec () { return ((float) this.secint) + 0.01F * (float) this.secfrac; }

	private static final java.text.DecimalFormat DF = new java.text.DecimalFormat ("00");
	
	/** Can pass in fractional hours or minutes but will be held in normalised form with integer hours and minutes
		* plus fractional seconds. */
	public RA (double hour, double min, double sec)
	{
		double totalSecs = (hour * 60.0 + min) * 60.0 + sec;
		double wholeSecs = Math.floor (totalSecs);
		this.secfrac = (byte) Math.round (100.0 * (totalSecs - wholeSecs));
		int intSecs = (int) wholeSecs;
		this.secint = (byte) (intSecs % 60);
		int intMins = intSecs / 60;
		this.min = (byte) (intMins % 60);
		this.hour = (byte) ((intMins / 60) % 24);
	} // RA

	public RA (int hour, int min, double sec)
	{
		this.hour = (byte) hour;
		this.min = (byte) min;
		this.secint = (byte) Math.floor (sec);
		this.secfrac = (byte) Math.floor (100.0 * (sec - this.secint));
	} // RA

	private static final double DEG_TO_HOUR = 24.0 / 360.0;
	private static final double HOUR_TO_DEG = 360.0 / 24.0;

	public RA (double degrees)
	{
		this (degrees * DEG_TO_HOUR, 0.0, 0.0);
	} // RA

	public double toHours ()
	{
		return this.hour + this.min / 60.0 + (this.secint + this.secfrac / 100.0) / 3600.0;
	} // toHours

	public double toDegrees ()
	{
		return HOUR_TO_DEG * this.toHours ();
	} // toDegrees

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		RA otherRA = (RA) other;

		if (otherRA.hour != this.hour) return false;
		if (otherRA.min != this.min) return false;
		if (otherRA.secint != this.secint) return false;
		if (otherRA.secfrac != this.secfrac) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) this.hour * 23  + (int) this.min * 17 + (int) this.secint * 13 + (int) this.secfrac * 11;
	} // hashCode

	@Override
	public RA clone ()
	{
		RA copy = new RA ();
		copy.hour = this.hour;
		copy.min = this.min;
		copy.secint = this.secint;
		copy.secfrac = this.secfrac;
		return copy;
	} // clone

	private RA () {} // Only to support perfect clone ()

	@Override
	public String toString ()
	{
		return (DF.format (this.hour) + "h" + DF.format (this.min) + "m" +
		        DF.format (this.secint) + "." + DF.format (this.secfrac) + "s");
	} // toString

} // RA