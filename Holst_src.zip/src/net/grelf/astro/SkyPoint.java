package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Representing a celestial position by equatorial coordinates (RA and Dec) for a given Epoch. */
public class SkyPoint implements Cloneable, java.io.Serializable
{
	public RA getRA () { return this.ra; }
	private RA ra;

	public Dec getDec () { return this.dec; }
	private Dec dec;

	public Epoch getEpoch () { return this.epoch; }
	private Epoch epoch;

	/** Equatorial coordinates, held to avoid computing them more than once. */
	protected double x, y, z;

	private static final double DEG_TO_HOUR = 24.0 / 360.0;
	private static final double EPSILON = 1.0E-7;

	public SkyPoint (RA ra, Dec dec, Epoch epoch)
	{
		this.ra = ra;
		this.dec = dec;
		this.epoch = epoch;
		computeXYZ ();
	} // SkyPoint

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		SkyPoint otherPt = (SkyPoint) other;

		if (!otherPt.ra.equals (this.ra)) return false;
		if (!otherPt.dec.equals (this.dec)) return false;
		if (!otherPt.epoch.equals (this.epoch)) return false;
		if (Math.abs (otherPt.x - this.x) > EPSILON) return false;
		if (Math.abs (otherPt.y - this.y) > EPSILON) return false;
		if (Math.abs (otherPt.z - this.z) > EPSILON) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return this.ra.hashCode () * 17  + this.dec.hashCode () * 41 + this.epoch.hashCode () * 83;
	} // hashCode

	@Override
	public SkyPoint clone ()
	{
		return new SkyPoint (this.ra.clone (), this.dec.clone (), this.epoch.clone ());
	} // clone

	private void computeXYZ ()
	{
		double raDegs =  this.ra.toDegrees ();
		double decDegs = this.dec.toDegrees ();
		double cosDec = net.grelf.Maths.cosDegs (decDegs);
		this.x = net.grelf.Maths.cosDegs (raDegs) * cosDec;
		this.y = net.grelf.Maths.sinDegs (raDegs) * cosDec;
		this.z = net.grelf.Maths.sinDegs (decDegs);
	} // computeXYZ

	/** This adjusts the fields of the current object to the given new epoch, low accuracy version.
		* Uses the approximate formulae:<br>
		* Annual precession in RA = 3.0730 + 1.3362.sin(RA).tan(Dec) seconds of time<br>
		* Annual precession in Dec = 20.043.cos(RA) seconds of arc. */
	public void changeEpochLowAccuracy (Epoch newEpoch)
	{
		float dY = newEpoch.getYear () - this.epoch.getYear ();

		if (0.0001F > Math.abs (dY)) return;

		double raDegs = this.ra.toDegrees ();
		double decDegs = this.dec.toDegrees ();
		double dRaSecs = dY * (3.0730 + 1.3362 * net.grelf.Maths.sinDegs (raDegs) * net.grelf.Maths.tanDegs (decDegs));
		RA newRA = new RA (raDegs * DEG_TO_HOUR, 0.0,  dRaSecs);
		double dDecSecs = dY * 20.043 * net.grelf.Maths.cosDegs (raDegs);
		Dec newDec = new Dec (decDegs + dDecSecs / 3600.0);
		this.ra = newRA;
		this.dec = newDec;
		this.epoch = newEpoch;
		computeXYZ ();
	} // changeEpochLowAccuracy

	private static final double ARCSECS_TO_DEGS = 1.0 / 3600.0;

	/** This adjusts the fields of the current object to the given new epoch, high accuracy version.
		* Uses the method given in Astronomical Algorithms by Jean Meeus (2nd edition, corrected Aug 09),
		* Chapter 21 (Precession), the section headed "Rigorous method". */
	public void changeEpoch (Epoch newEpoch)
	{
		double jd0 = this.epoch.getJulianDate ().toDouble ();
		double jd = newEpoch.getJulianDate ().toDouble ();
		double _T = (jd0 - 2451545.0) / 36525.0;
		double t = (jd - jd0) / 36525.0;
		double _T2 = _T * _T;
		double t2 = t * t;
		double t3 = t2 * t;
		double zetaDegs = ((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
						           (0.30188 - 0.000344 * _T) * t2 + 0.017998 * t3) * ARCSECS_TO_DEGS;
		double zDegs = ((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
						        (1.09468 + 0.000066 * _T) * t2 + 0.018203 * t3) * ARCSECS_TO_DEGS;
		double thetaDegs = ((2004.3109 - 0.85330 * _T - 0.000217 * _T2) * t -
						            (0.42665 + 0.000217 * _T) * t2 - 0.041833 * t3) * ARCSECS_TO_DEGS;
		double ra0Degs = this.ra.toDegrees ();
		double dec0Degs = this.dec.toDegrees ();
		double cosDec0 = net.grelf.Maths.cosDegs (dec0Degs);
		double sinDec0 = net.grelf.Maths.sinDegs (dec0Degs);
		double ra0zetaDegs = net.grelf.Maths.in360 (ra0Degs + zetaDegs);
		double cosDaz = cosDec0 * net.grelf.Maths.cosDegs (ra0zetaDegs);
		double cosTheta = net.grelf.Maths.cosDegs (thetaDegs);
		double sinTheta = net.grelf.Maths.sinDegs (thetaDegs);
		double _A = cosDec0 * net.grelf.Maths.sinDegs (ra0zetaDegs);
		double _B = cosTheta * cosDaz - sinTheta * sinDec0;
		double _C = sinTheta * cosDaz + cosTheta * sinDec0;
		double raDegs = zDegs + net.grelf.Maths.atan2Degs (_A, _B);
		double decDegs;
		
		if (dec0Degs > -85.0 && dec0Degs < 85.0)
		{
			decDegs = net.grelf.Maths.asinDegs (_C);
		}
		else // Near a pole:
		{
			decDegs = net.grelf.Maths.acosDegs (StrictMath.sqrt (_A * _A + _B * _B));
		}

		this.ra = new RA (net.grelf.Maths.in360 (raDegs));
		this.dec = new Dec (decDegs);
		this.epoch = newEpoch;
		computeXYZ ();
	} // changeEpoch

	/** Calculate position angle (PA) and spherical separation from this to another SkyPoint.
		* If the other SkyPoint is for a different epoch it is first converted to the epoch of this point.<br>
		* 10.2.1: New method used because previous one involved inverse cosine to get the separation which is
		* inaccurate for small angles. Method is as given in Chapter 17 of Astronomical Algorithms by
		* Jan Meeus, the algorithm supplied by Thierry Pauwels. */
	public SkyVector calculateSeparation (SkyPoint other)
	{
		if (!other.epoch.equals (this.epoch))
		{
			other.changeEpoch (this.epoch);
		}

		double daDegs = (this.ra.toDegrees () - other.ra.toDegrees ());
		double d2Degs = this.dec.toDegrees ();
		double d1Degs = other.dec.toDegrees ();
		double cosD1 = net.grelf.Maths.cosDegs (d1Degs);
		double cosD2 = net.grelf.Maths.cosDegs (d2Degs);
		double cosDa = net.grelf.Maths.cosDegs (daDegs);
		double sinD1 = net.grelf.Maths.sinDegs (d1Degs);
		double sinD2 = net.grelf.Maths.sinDegs (d2Degs);
		double sinDa = net.grelf.Maths.sinDegs (daDegs);
		double xx = cosD1 * sinD2 - sinD1 * cosD2 * cosDa;
		double yy = cosD2 * sinDa;
		double zz = sinD1 * sinD2 + cosD1 * cosD2 * cosDa;
		double separationDegs = net.grelf.Maths.atan2Degs (StrictMath.sqrt (xx * xx + yy * yy), zz);
		double paDegs = net.grelf.Maths.in360 (net.grelf.Maths.atan2Degs (-sinDa, cosD2 * sinD1 / cosD1 - sinD2 * cosDa));
		return new SkyVector (separationDegs, paDegs);
	} // calculateSeparation

	@Override
	public String toString ()
	{
			return ("RA " + this.ra.toString () + " Dec " + this.dec.toString () + " (" + this.epoch.toString () + ")");
	} // toString

	/** Return <RA><Dec><Epoch> elements. */
	public StringBuffer toXML ()
	{
		StringBuffer sb = new StringBuffer ();
		sb.append ("<RA>" + this.getRA ().toString () + "</RA><Dec>" + this.getDec ().toString () +
						"</Dec><Epoch>" + this.getEpoch ().toString () + "</Epoch>");
		return sb;
	} // toXML

} // SkyPoint