package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Represents a vector on the celestial sphere, eg between two SkyPoints. */
public class SkyVector implements Cloneable, java.io.Serializable
{
	/** Get spherical separation in degrees. */
	public double getSeparation () { return this.separation; }
	private double separation;

	/** Get position angle in degrees (anticlockwise from north). */
	public double getPA () { return this.pa; }
	private double pa;

	private static final double EPSILON = 1.0E-7;

	/** The order of the parameters is like polar coordinates (r, theta). If separation is negative
	 * the sign is removed and 180 added to PA. PA is then converted, if necessary, to lie in range
	 * [0..360). */
	public SkyVector (double separationDegs, double paDegs)
	{
		this.separation = separationDegs;
		this.pa = net.grelf.Maths.in360 (paDegs);

		if (this.separation < 0)
		{
/****
			net.grelf.grip.GRIP.getLogger ().info ("SkyVector.sep < 0");
****/
			this.separation = - this.separation;
			this.pa = net.grelf.Maths.in360 (this.pa + 180.0);
		}
	} // SkyVector

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		SkyVector otherVector = (SkyVector) other;

		if (Math.abs (otherVector.pa - this.pa) > EPSILON) return false;
		if (Math.abs (otherVector.separation - this.separation) > EPSILON) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) (this.pa * 37  + this.separation * 11);
	} // hashCode

	@Override
	public SkyVector clone ()
	{
		return new SkyVector (this.pa, this.separation);
	} // clone

	@Override
	public String toString ()
	{
		return ("PA " + this.pa + "degrees, separation " + this.separation + " degrees");
	} // toString

} // SkyVector