package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Representation of declination (celestial latitude) in a compact form, just 4 bytes of data. Accurate to 0.1 seconds
	* of arc. */
public class Dec implements Cloneable, java.io.Serializable
{
	private boolean positive;
	private byte degree;	// Range 0..90
	private byte min;			// Range 0..59
	private byte secint;	// Range 0..59
	private byte secfrac; // Fractional part x 10. Range 0..9

	/** Range -90..+90 */
	public byte getDegree ()
	{
		return this.positive ? this.degree : (byte) -this.degree;
	} // getDegree

	/** Range -59..59 */
	public byte getMin ()
	{
		return this.positive ? this.min : (byte) -this.min;
	} // getMin

	/** Range -59.9..59.9 */
	public float getSec ()
	{
		float sec = (float) this.secint + 0.1F * (float) this.secfrac;
		return this.positive ? sec : -sec;
	} // getSec

	private static final java.text.DecimalFormat DF2 = new java.text.DecimalFormat ("00");
	private static final java.text.DecimalFormat DF1 = new java.text.DecimalFormat ("0");

	/** Can pass in fractional degrees or minutes but will be held in normalised form with integer degrees and minutes
		* plus fractional seconds.<br>
		* 10.2.1 Important change: previously the degrees part could be negative but min and sec were expected to
		* be positive (as from a user dialogue). BUT that will not work if the degrees part is zero. So...<br>
		* VERY IMPORTANT: If the declination is negative every field in this constructor must be negative.
		* Note that in a user dialogue (eg, in net.grelf.astro.StarChart) it can be different because each text
		* field holds a String rather than a number so the sign is detectable on "-0". */
	public Dec (double degrees, double mins, double secs)
	{
		double totalSecs = (degrees * 60.0 + mins) * 60.0 + secs;

		if (totalSecs < 0.0)
		{
			this.positive = false;
			totalSecs = -totalSecs;
		}
		else
		{
			this.positive = true;
		}

		// totalSecs must now be positive
		double wholeSecs = Math.floor (totalSecs);
		this.secfrac = (byte) Math.round (10.0 * (totalSecs - wholeSecs));
		int intSecs = (int) wholeSecs;
		this.secint = (byte) (intSecs % 60);
		int intMins = intSecs / 60;
		this.min = (byte) (intMins % 60);
		this.degree = (byte) (intMins / 60);
	} // Dec

	public Dec (double degrees)
	{
		this (degrees, 0.0, 0.0);
	} // Dec

	public double toDegrees ()
	{
		double deg = this.degree + this.min / 60.0 + (this.secint + this.secfrac / 10.0) / 3600.0;
		return this.positive ? deg : -deg;
	} // toDegrees

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		Dec otherDec = (Dec) other;

		if (otherDec.positive != this.positive) return false;
		if (otherDec.degree != this.degree) return false;
		if (otherDec.min != this.min) return false;
		if (otherDec.secint != this.secint) return false;
		if (otherDec.secfrac != this.secfrac) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		int pos = 91;

		if (!this.positive) pos = 7;

		return (int) pos + this.degree * 23  + (int) this.min * 17 + (int) this.secint * 13 + (int) this.secfrac * 11;
	} // hashCode

	@Override
	public Dec clone ()
	{
		Dec copy = new Dec ();
		copy.positive = this.positive;
		copy.degree = this.degree;
		copy.min = this.min;
		copy.secint = this.secint;
		copy.secfrac = this.secfrac;
		return copy;
	} // clone

	private Dec () {} // Only to support perfect clone ()

	@Override
	public String toString ()
	{
		return (this.positive ? "+" : "-") + DF2.format (this.degree) + "d" + DF2.format (this.min) + "m" +
		        DF2.format (this.secint) + "." + DF1.format (this.secfrac) + "s";
	} // toString

} // Dec