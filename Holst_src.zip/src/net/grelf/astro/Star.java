package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** A star can have several ids, from different catalogues. The commonId is for the brightest stars, comprising the
	* constellation abbreviation and Flamsteed number and/or Bayer letter. If the user enters a reference of their own
	* it is held in the otherId field.<br><br>
	* 9.12.20: Enabled star to have multiple magnitudes in different bands, held in a list. */
public class Star implements Cloneable, java.io.Serializable
{
	/** If the star has a commonId return that; otherwise if it has a hipparcosId return that; otherwise if it has a
		* tychoId return that; otherwise if it has an otherId return that; otherwise return an empty string. */
	public String getId ()
	{
		if (null != this.commonId && 0 < this.commonId.length ()) return this.commonId;
		if (null != this.hipparcosId && 0 < this.hipparcosId.length ()) return this.hipparcosId;
		if (null != this.tychoId && 0 < this.tychoId.length ()) return this.tychoId;
		if (null != this.otherId && 0 < this.otherId.length ()) return this.otherId;
		return "";
	}

	private String commonId = "";
	/** Comprising the constellation abbreviation and Flamsteed number and/or Bayer letter (only brightest stars have these). */
	public String getCommonId () { return this.commonId; }
	public void setCommonId (String id) { this.commonId = id; }

	private String hipparcosId = "";
	public String getHipparcosId () { return this.hipparcosId; }
	public void setHipparcosId (String id) { this.hipparcosId = id; }

	private String tychoId = "";
	public String getTychoId () { return this.tychoId; }
	public void setTychoId (String id) { this.tychoId = id; }

	private String otherId = "";
	public String getOtherId () { return this.otherId; }
	/** For user-entered reference of their own devising. */
	public void setOtherId (String id) { this.otherId = id; }

	private String typeOfStellarObject = "";
	public String getTypeOfStellarObject () { return this.typeOfStellarObject; }
	/** Some data sources will provide some kind of description to be set here. */
	public void setTypeOfStellarObject (String type) { this.typeOfStellarObject = type; }

	/** If the star's position is unknown this returns null. */
	public SkyPoint getPosition () { return this.position; }
	public void setPosition (SkyPoint pt) { this.position = pt; }
	private SkyPoint position = null;

	/** Get the list of magnitudes */
	public java.util.List <Magnitude> getMagnitudes () { return this.magnitudes; }
	private java.util.List <Magnitude> magnitudes = new java.util.ArrayList <Magnitude> ();

	/** Add another magnitude for this star. A star can have multiple magnitudes, in different bands. */
	public void addMagnitude (Magnitude m) { this.magnitudes.add (m); }

	/** For entering a manual magnitude value to replace all others (as in BlobMenu). NB: REPLACES ALL. */
	public void setMagnitude (Magnitude m)
	{
		this.magnitudes = new java.util.ArrayList <Magnitude> ();
		this.magnitudes.add (m);
	} // setMagnitude

	/** Get the "principal" magnitude. If the star has only one magnitude value that is returned.
		* Otherwise the list of magnitudes is scanned. If one is found that has band id "V" or "v"
		* that is returned. Otherwise the first one in the list is returned.
		* If the star's magnitude is unknown (the magnitudes list is empty) this returns null, not
		* a special value. */
	public Magnitude getMagnitude ()
	{
		if (this.magnitudes.size () == 0) return null;

		for (Magnitude mag : magnitudes)
		{
      if (null != mag)
      {
        String id = mag.getBandId ();

        if (null != id && id.toUpperCase ().equals ("V")) return mag;
      }
		}

		return this.magnitudes.get (0);
	} // getMagnitude

	/** Get the magnitude with given band id, or null if not found. */
	public Magnitude getMagnitude (String bandId)
	{
		for (Magnitude mag : magnitudes)
		{
			if (mag.getBandId ().equals (bandId)) return mag;
		}

		return null;
	} // getMagnitude

	/** If the star's variability is unknown this returns null, not a special value. */
	public Variability getVariability () { return this.variability; }
	public void setVariability (Variability v) { this.variability = v; }
	private Variability variability = null;

	/** If the star's proper motion is unknown this returns a ProperMotion object in which both components
	 * are zero. */
	public ProperMotion getProperMotion () { return this.properMotion; }
	public void setProperMotion (ProperMotion pm) { this.properMotion = pm; }
	private ProperMotion properMotion = new ProperMotion (0.0, 0.0);

	/** Recalculated for different star charts. */
	public transient double xdd, zdd;

	/** Does not involve the fields xdd and zdd because a given star may be plotted in different positions on different StarCharts. */
	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		Star otherStar = (Star) other;

		if (!otherStar.commonId.equals (this.commonId)) return false;
		if (!otherStar.hipparcosId.equals (this.hipparcosId)) return false;
		if (!otherStar.tychoId.equals (this.tychoId)) return false;
		if (!otherStar.otherId.equals (this.otherId)) return false;

		if (null == otherStar.position && null != this.position) return false;
		if (null != otherStar.position && null == this.position) return false;
		if (null != otherStar.position && null != this.position && !otherStar.position.equals (this.position)) return false;
		// Equal if both were null

		if (null == otherStar.magnitudes && null != this.magnitudes) return false;
		if (null != otherStar.magnitudes && null == this.magnitudes) return false;
		if (null != otherStar.magnitudes && null != this.magnitudes
			&& !otherStar.magnitudes.equals (this.magnitudes)) return false;
		// Equal if both were null

		if (null == otherStar.variability && null != this.variability) return false;
		if (null != otherStar.variability && null == this.variability) return false;
		if (null != otherStar.variability && null != this.variability
			&& !otherStar.variability.equals (this.variability)) return false;
		// Equal if both were null

		if (null == otherStar.properMotion && null != this.properMotion) return false;
		if (null != otherStar.properMotion && null == this.properMotion) return false;
		if (null != otherStar.properMotion && null != this.properMotion
			&& !otherStar.properMotion.equals (this.properMotion)) return false;
		// Equal if both were null

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys.
		* NB: Does not involve the fields xdd and zdd because a given star may be plotted in different positions on different StarCharts. */
	@Override
	public int hashCode ()
	{
		return this.commonId.hashCode () * 7 + this.hipparcosId.hashCode () * 11 + this.tychoId.hashCode () * 13 +
					 this.otherId.hashCode () * 17 + this.position.hashCode () * 19 + this.magnitudes.hashCode () * 23 +
					 this.variability.hashCode () * 29 + this.properMotion.hashCode () * 97;
	} // hashCode

	@Override
	public Star clone ()
	{
		Star star = new Star ();
		star.commonId = this.commonId;
		star.hipparcosId = this.hipparcosId;
		star.tychoId = this.tychoId;
		star.otherId = this.otherId;

		if (null == this.position)
		{
			star.position = null;
		}
		else
		{
			star.position = this.position.clone ();
		}

		java.util.List <Magnitude> copyMags = new java.util.ArrayList <Magnitude> ();

		for (Magnitude mag : this.magnitudes)
		{
			copyMags.add (mag);
		}

		star.magnitudes = copyMags;
		star.variability = this.variability;
		star.properMotion = this.properMotion.clone ();
		star.xdd = this.xdd;
		star.zdd = this.zdd;
		return star;
	} // clone

	/** Generally two of the ids passed in will be expected to be null; they may get set after construction. If magnitude or variability
		* are unknown enter null for each. */
	public Star (String commonId, String hipparcosId, String tychoId, RA ra, Dec dec, Epoch epoch,
					     Magnitude magnitude, Variability variability)
	{
		if (null != commonId)	this.commonId = commonId;
		if (null != hipparcosId)	this.hipparcosId = hipparcosId;
		if (null != tychoId)	this.tychoId = tychoId;

		this.position = new SkyPoint (ra, dec, epoch);
		this.magnitudes.add (magnitude);
		this.variability = variability;
	} // Star

	/** Generally two of the ids passed in will be expected to be null. They may get set after construction. If magnitude or variability
		* are unknown enter null for each. This constructor also takes the transformed coordinates (xdd, zdd) for plotting on a star chart.
		* See class StarChart for details of the transformation. */
	public Star (String commonId, String hipparcosId, String tychoId, RA ra, Dec dec, Epoch epoch,
					     Magnitude magnitude, Variability variability, double xdd, double zdd)
	{
		this (commonId, hipparcosId, tychoId, ra, dec, epoch, magnitude, variability);
		this.xdd = xdd;
		this.zdd = zdd;
	} // Star

	/** Generally two of the ids passed in will be expected to be null; they may get set after construction. If magnitude or variability
		* are unknown enter null for each. */
	public Star (String commonId, String hipparcosId, String tychoId, RA ra, Dec dec, Epoch epoch,
					     Magnitude magnitude, Variability variability, ProperMotion pm)
	{
		this (commonId, hipparcosId, tychoId, ra, dec, epoch, magnitude, variability);
		this.properMotion = pm;
	} // Star

	/** Generally two of the ids passed in will be expected to be null. They may get set after construction. If magnitude or variability
		* are unknown enter null for each. This constructor also takes the transformed coordinates (xdd, zdd) for plotting on a star chart.
		* See class StarChart for details of the transformation. */
	public Star (String commonId, String hipparcosId, String tychoId, RA ra, Dec dec, Epoch epoch,
					     Magnitude magnitude, Variability variability, ProperMotion pm, double xdd, double zdd)
	{
		this (commonId, hipparcosId, tychoId, ra, dec, epoch, magnitude, variability, pm);
		this.xdd = xdd;
		this.zdd = zdd;
	} // Star

	/** Set the fields individually after construction, if you really must. */
	public Star () {}

	private static final java.text.DecimalFormat DF = new java.text.DecimalFormat ("0.00");

	/** Simplified summary */
	@Override
	public String toString ()
	{
		StringBuffer magList = new StringBuffer ();

		for (Magnitude mag : this.magnitudes)
		{
			magList.append (mag.toString () + " ");
		}

		return this.getId () + " at " + this.position.toString () +
		       ", magnitude " + magList.toString () +
		       ", variability " + this.variability.toString ().toLowerCase ();
	} // toString

	/** More detailed and more suitable for display to the user - reasonably formatted multi-line text. */
	public String toFoldedString ()
	{
		StringBuffer sb = new StringBuffer ();

		if (null != this.commonId && this.commonId.length () > 0)
		{
			sb.append (this.commonId);
			sb.append ("\n");
		}

		if (null != this.hipparcosId && this.hipparcosId.length () > 0)
		{
			sb.append ("Hipparcos ");
			sb.append (this.hipparcosId);
			sb.append ("\n");
		}

		if (null != this.tychoId && this.tychoId.length () > 0)
		{
			sb.append ("Tycho ");
			sb.append (this.tychoId);
			sb.append ("\n");
		}

		if (null != this.otherId && this.otherId.length () > 0)
		{
			sb.append ("Entered ref ");
			sb.append (this.otherId);
			sb.append ("\n");
		}

		if (null != this.position)
		{
			sb.append ("at ");
			sb.append (this.position.toString ());
			sb.append ("\n");
		}

		sb.append ("magnitude ");

		if (0 == this.magnitudes.size ())
		{
			sb.append ("unknown\n");
		}
		else
		{
			StringBuffer magList = new StringBuffer ();

			for (Magnitude mag : this.magnitudes)
			{
				sb.append (mag.toString () + "\n");
			}
		}

		if (this.properMotion.isKnown ())
		{
			sb.append ("Proper motion ");
			sb.append (this.properMotion.toString ());
			sb.append ("\n");
		}

		sb.append ("Hipparcos variability ");

		if (null == this.variability)
		{
			sb.append ("unknown\n");
		}
		else
		{
			sb.append (this.variability.toString ().toLowerCase ());
			sb.append ("\n");
		}

		if (null != this.typeOfStellarObject && this.typeOfStellarObject.length () > 0)
		{
			sb.append ("Type of object: ");
			sb.append (this.typeOfStellarObject);
			sb.append ("\n");
		}

		return sb.toString ();
	} // toFoldedString

	/** The indent string would typically contain some tab characters (\t). */
	public StringBuffer toXML (String indent)
	{
		StringBuffer sb = new StringBuffer ();
		sb.append (indent);
		sb.append ("<Star>\n");

		if (null != this.commonId && this.commonId.length () > 0)
		{
			sb.append (indent);
			sb.append ("\t<CommonId>" + this.commonId + "</CommonId>\n");
		}

		if (null != this.hipparcosId && this.hipparcosId.length () > 0)
		{
			sb.append (indent);
			sb.append ("\t<HipparcosId>" + this.hipparcosId + "</HipparcosId>\n");
		}

		if (null != this.tychoId && this.tychoId.length () > 0)
		{
			sb.append (indent);
			sb.append ("\t<TychoId>" + this.tychoId + "</TychoId>\n");
		}

		if (null != this.otherId && this.otherId.length () > 0)
		{
			sb.append (indent);
			sb.append ("\t<OtherId>" + otherId + "</OtherId>\n");
		}

		if (null != this.position)
		{
			sb.append (indent);
			sb.append ("\t<SkyPt>");
			sb.append (this.position.toXML ());
			sb.append ("</SkyPt>\n");
		}

		if (0 != this.magnitudes.size ())
		{
			for (Magnitude mag : this.magnitudes)
			{
				sb.append (indent);
				sb.append ("\t");
				sb.append (mag.toXML ());
				sb.append ("\n");
			}
		}

		if (this.properMotion.isKnown ())
		{
			sb.append (indent);
			sb.append ("\t");
			sb.append (this.properMotion.toXML ());
			sb.append ("\n");
		}

		if (null != this.variability)
		{
			sb.append (indent);
			sb.append ("\t<Var>");
			sb.append (this.variability.toString ());
			sb.append ("</Var>\n");
		}

		if (this.typeOfStellarObject.length () > 0)
		{
			sb.append (indent);
			sb.append ("\t<Type>");
			sb.append (net.grelf.XmlUtil.escape (new StringBuffer (this.typeOfStellarObject)));
			sb.append ("</Type>\n");
		}

		// No need to output xdd and zdd because those would only be used in StarChart and that does not use BlobMeas
		sb.append (indent);
		sb.append ("</Star>\n");
		return sb;
	} // toXML

	/** Set by StarChart when first plotting the star. */
	public void setPlotPoint (java.awt.Point pt) { this.plotPoint = pt; }
	public java.awt.Point getPlotPoint () { return this.plotPoint; }
	private java.awt.Point plotPoint;

} // Star