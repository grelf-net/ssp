package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Categorise variable stars, compatible with VarFlag in the Hipparcos data set. */
public enum Variability
{
	NONE,

	/** < 0.06 magnitude */
	SMALL,  //

	/** 0.06 - 0.6 magnitude */
	MEDIUM,

	/**  > 0.6 magnitude */
	LARGE;

	@Override
	public String toString ()
	{
		switch (this)
		{
			case NONE: return "none";
			case SMALL: return "small (less than 0.06 magnitude)";
			case MEDIUM: return "medium (0.06 - 0.6 magnitude)";
			case LARGE: return "large (more than 0.6 magnitude)";
		}

		return "unknown";
	} // toString

} // Variability