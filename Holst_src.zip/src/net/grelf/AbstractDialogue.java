package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Provide some methods for GRIP dialogues to inherit: they should extend this rather than JDialog. */
public abstract class AbstractDialogue extends javax.swing.JDialog
{
	public AbstractDialogue () { super (); }
	public AbstractDialogue (java.awt.Frame owner, String title) { super (owner, title); }
	public AbstractDialogue (java.awt.Frame owner, String title, boolean modal) { super (owner, title, modal); }

	/** Convenient way to place a control in a java.awt.GridBagLayout. This version has HORIZONTAL fill. */
	protected void placeControl (java.awt.Container pane, javax.swing.JComponent component,
														 int gridX, int gridY, int gridWidth, int gridHeight)
	{
		placeControl (pane, component, gridX, gridY, gridWidth, gridHeight,
						      java.awt.GridBagConstraints.HORIZONTAL);
	} // placeControl

	/** Convenient way to place a control in a java.awt.GridBagLayout */
	protected void placeControl (java.awt.Container pane, javax.swing.JComponent component,
														 int gridX, int gridY, int gridWidth, int gridHeight, int fill)
	{
		java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints ();
		gbc.gridx = gridX;
		gbc.gridy = gridY;
		gbc.gridwidth = gridWidth;
		gbc.gridheight = gridHeight;
		gbc.fill = fill;
		gbc.ipady = 6;
		pane.add (component, gbc);
	} // placeControl

} // AbstractDialogue
