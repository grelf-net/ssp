package net.grelf;

/** 3D position represented by Cartesian coordinates, in any convenient units.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class XYZ
{
	public double x, y, z;

	/** May construct without values and set them afterwards. */
	public XYZ () {}

	public XYZ (double x, double y, double z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	} // XYZ

	public double getLatitudeRadians ()
	{
		return StrictMath.atan2 (this.z, StrictMath.sqrt (this.x * this.x + this.y * this.y));
	} // getLatitudeRadians

	public double getLongitudeRadians ()
	{
		return StrictMath.atan2 (this.y, this.x);
	} // getLongitudeRadians

	/** Get the length of the vector in the same units as its components x, y & z. */
	public double getRadius ()
	{
		return StrictMath.sqrt (this.x * this.x + this.y * this.y + this.z * this.z);
	} // getRadius

	public double distance (XYZ other)
	{
    double dx = this.x - other.x;
    double dy = this.y - other.y;
    double dz = this.z - other.z;
    return StrictMath.sqrt (dx * dx + dy * dy + dz * dz);
	} // distance

	@Override
	public String toString ()
	{
		return ("(" + this.x + ", " + this.y + ", " + this.z + ")");
	} // toString

} // XYZ
