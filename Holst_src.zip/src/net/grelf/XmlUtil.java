package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Some static utility methods for working with XML. This class cannot be instantiated. */
public class XmlUtil
{
	// TODO Devise a better way of loading XML so each class can do its bit
	private XmlUtil () {} // Cannot instantiate

	/** Convert the 5 special characters <>'"& to entities wherever they occur in the given text.
		* #39 is used instead of apos so the result works for HTML browsers as well as XML parsers. */
	public static StringBuffer escape (StringBuffer sb)
	{
		StringBuffer newSb = new StringBuffer ();

		for (int i = 0; i < sb.length (); i++)
		{
			char ch = sb.charAt (i);

			switch (ch)
			{
				case '<':  newSb.append ("&lt;"); break;
				case '>':  newSb.append ("&gt;"); break;
				case '\'': newSb.append ("&#39;"); break;
				case '\"': newSb.append ("&quot;"); break;
				case '&':  newSb.append ("&amp;"); break;
				default:   newSb.append (ch);
			}
		}

		return newSb;
	} // escape

	/** Use a dummy XSLT transform to output a DOM document. */
	public static void outputDocument (java.io.PrintWriter out, org.w3c.dom.Document doc)
	{
		try
		{
			javax.xml.transform.Transformer tx =
				javax.xml.transform.TransformerFactory.newInstance ().newTransformer ();
			tx.setOutputProperty ("indent", "yes");
			tx.transform (new javax.xml.transform.dom.DOMSource (doc),
						        new javax.xml.transform.stream.StreamResult (out));
		}
		catch (javax.xml.transform.TransformerConfigurationException ex)
		{
			java.util.logging.Logger.getLogger ("net.grelf").warning (ex.toString ());
		}
		catch (javax.xml.transform.TransformerException ex)
		{
			java.util.logging.Logger.getLogger ("net.grelf").warning (ex.toString ());
 		}
		catch (Exception ex)
		{
			java.util.logging.Logger.getLogger ("net.grelf").warning (ex.toString ());
		}
	} // outputDocument

} // XmlUtil