package net.grelf.planet;

/** Each instance represents the Earth at a given instant, for equinox J2000.0.
 * This uses modified tables as defined in Meeus AA pp172-3
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public final class EarthJ2000 extends Planet
{
	private double eclipticObliquityDegs;
	/** Obliquity of the ecliptic at the current Julian Date (when the EarthJ2000 object was constructed),
	 * calculated by the IAU formula given in Meeus Astronomical Algorithms (2nd edn) on p147. */
	public double getEclipticObliquityDegs () { return this.eclipticObliquityDegs; }

	/** Obliquity of the ecliptic at the given epoch,
	 * calculated by the IAU formula given in Meeus Astronomical Algorithms (2nd edn) on p147. */
	public double getEclipticObliquityDegs (net.grelf.astro.Epoch epoch)
	{
		double julianEphemerisDay = epoch.getJulianDate ().toDouble ();
		double _Tcenturies = (julianEphemerisDay - net.grelf.astro.JulianDate.J2000) / 36525.0;
		return getEclipticObliquityDegs (_Tcenturies);
	} // getEclipticObliquityDegs

	public double getEclipticObliquityDegs (double _Tcenturies)
	{
		double _T2 = _Tcenturies * _Tcenturies;
		double _T3 = _T2 * _Tcenturies;
		return 23.0 + 26.0 / 60.0 +
						(21.448 - 46.8150 * _Tcenturies - 0.00059 * _T2 + 0.001813 * _T3) / 3600.0;
	} // getEclipticObliquityDegs

	public EarthJ2000 (double julianEphemerisDay) throws WrongRowNumberException
	{
		super ("Earth");

		double tauMillennia = (julianEphemerisDay - net.grelf.astro.JulianDate.J2000) / 365250.0;
		this.longitudeHeliocentricDegs = net.grelf.Maths.in360 (calcLDegs (tauMillennia));
		this.latitudeHeliocentricDegs = calcBDegs (tauMillennia);
		this.radiusVectorAU = calcRAU (tauMillennia);
/*
		report ("EarthJ2000 L=" + this.longitudeHeliocentricDegs + " B=" + this.latitudeHeliocentricDegs +
						" R=" + this.radiusVectorAU);
*/
		double _Tcenturies = tauMillennia * 10.0;
		this.eclipticObliquityDegs = getEclipticObliquityDegs (_Tcenturies);
	} // EarthJ2000

	@Override
	protected  double calcLDegs (double tau) throws WrongRowNumberException
	{
		double l0 = sumSeries (EARTH_L0, tau);
		double l1 = sumSeries (EARTH_L1, tau);
		double l2 = sumSeries (EARTH_L2, tau);
		double l3 = sumSeries (EARTH_L3, tau);
		double l4 = sumSeries (EARTH_L4, tau);
		return StrictMath.toDegrees ((((((((l4 * tau) + l3) * tau) + l2) * tau) + l1) * tau + l0) * 1.0e-8);
	} // calcLDegs

	@Override
	protected  double calcBDegs (double tau) throws WrongRowNumberException
	{
		double b0 = sumSeries (EARTH_B0, tau);
		double b1 = sumSeries (EARTH_B1, tau);
		double b2 = sumSeries (EARTH_B2, tau);
		double b3 = sumSeries (EARTH_B3, tau);
		double b4 = sumSeries (EARTH_B4, tau);
		return StrictMath.toDegrees ((((((((b4) * tau) + b3) * tau) + b2) * tau) + b1) * tau + b0) * 1.0e-8;
	} // calcBDegs

	@Override
	protected  double calcRAU (double tau) throws WrongRowNumberException
	{
		double r0 = sumSeries (EARTH_R0, tau);
		double r1 = sumSeries (EARTH_R1, tau);
		double r2 = sumSeries (EARTH_R2, tau);
		double r3 = sumSeries (EARTH_R3, tau);
		double r4 = sumSeries (EARTH_R4, tau);
		return ((((((((r4) * tau) + r3) * tau) + r2) * tau) + r1) * tau + r0) * 1.0e-8;
	} // calcRAU

	private static final double [] EARTH_L0 = new double []
	{
		1,175347046,0,0,
		2,3341656,4.6692568,6283.07585,
		3,34894,4.6261,12566.1517,
		4,3497,2.7441,5753.3849,
		5,3418,2.8289,3.5231,
		6,3136,3.6277,77713.7715,
		7,2676,4.4181,7860.4194,
		8,2343,6.1352,3930.2097,
		9,1324,0.7425,11506.7698,
		10,1273,2.0371,529.691,
		11,1199,1.1096,1577.3435,
		12,990,5.233,5884.927,
		13,902,2.045,26.298,
		14,857,3.508,398.149,
		15,780,1.179,5223.694,
		16,753,2.533,5507.553,
		17,505,4.583,18849.228,
		18,492,4.205,775.523,
		19,357,2.92,0.067,
		20,317,5.849,11790.629,
		21,284,1.899,796.298,
		22,271,0.315,10977.079,
		23,243,0.345,5486.778,
		24,206,4.806,2544.314,
		25,205,1.869,5573.143,
		26,202,2.458,6069.777,
		27,156,0.833,213.299,
		28,132,3.411,2942.463,
		29,126,1.083,20.775,
		30,115,0.645,0.98,
		31,103,0.636,4694.003,
		32,102,0.976,15720.839,
		33,102,4.267,7.114,
		34,99,6.21,2146.17,
		35,98,0.68,155.42,
		36,86,5.98,161000.69,
		37,85,1.3,6275.96,
		38,85,3.67,71430.7,
		39,80,1.81,17260.15,
		40,79,3.04,12036.46,
		41,75,1.76,5088.63,
		42,74,3.5,3154.69,
		43,74,4.68,801.82,
		44,70,0.83,9437.76,
		45,62,3.98,8827.39,
		46,61,1.82,7084.9,
		47,57,2.78,6286.6,
		48,56,4.39,14143.5,
		49,56,3.47,6279.55,
		50,52,0.19,12139.55,
		51,52,1.33,1748.02,
		52,51,0.28,5856.48,
		53,49,0.49,1194.45,
		54,41,5.37,8429.24,
		55,41,2.4,19651.05,
		56,39,6.17,10447.39,
		57,37,6.04,10213.29,
		58,37,2.57,1059.38,
		59,36,1.71,2352.87,
		60,36,1.78,6812.77,
		61,33,0.59,17789.85,
		62,30,0.44,83996.85,
		63,30,2.74,1349.87,
		64,25,3.16,4690.48
	};

	private static final double [] EARTH_L1 = new double []
	{
		1,628307584999.0,0,0,
		2,206059,2.678235,6283.07585,
		3,4303,2.6351,12566.1517,
		4,425,1.59,3.523,
		5,119,5.796,26.298,
		6,109,2.966,1577.344,
		7,93,2.59,18849.23,
		8,72,1.14,529.69,
		9,68,1.87,398.15,
		10,67,4.41,5507.55,
		11,59,2.89,5223.69,
		12,56,2.17,155.42,
		13,45,0.4,796.3,
		14,36,0.47,775.52,
		15,29,2.65,7.11,
		16,21,5.34,0.98,
		17,19,1.85,5486.78,
		18,19,4.97,213.3,
		19,17,2.99,6275.96,
		20,16,0.03,2544.31,
		21,16,1.43,2146.17,
		22,15,1.21,10977.08,
		23,12,2.83,1748.02,
		24,12,3.26,5088.63,
		25,12,5.27,1194.45,
		26,12,2.08,4694,
		27,11,0.77,553.57,
		28,10,1.3,6286.6,
		29,10,4.24,1349.87,
		30,9,2.7,242.73,
		31,9,5.64,951.72,
		32,8,5.3,2352.87,
		33,6,2.65,9437.76,
		34,6,4.67,4690.48
	};

	private static final double [] EARTH_L2 = new double []
	{
    1,8722,1.0725,6283.0758,
    2,991,3.1416,0,
    3,295,0.437,12566.152,
    4,27,0.05,3.52,
    5,16,5.19,26.30,
    6,16,3.69,155.42,
    7,9,0.30,18849.23,
    8,9,2.06,77713.77,
    9,7,0.83,775.52,
    10,5,4.66,1577.34,
    11,4,1.03,7.11,
    12,4,3.44,5573.14,
    13,3,5.14,796.30,
    14,3,6.05,5507.55,
    15,3,1.19,242.73,
    16,3,6.12,529.69,
    17,3,0.30,398.15,
    18,3,2.28,553.57,
    19,2,4.38,5223.69,
    20,2,3.75,0.98
	};

	private static final double [] EARTH_L3 = new double []
	{
    1,289,5.842,6283.076,
    2,21,6.05,12566.15,
    3,3,5.20,155.42,
    4,3,3.14,0,
    5,1,4.72,3.52,
    6,1,5.97,242.73,
    7,1,5.54,18849.23
	};

	private static final double [] EARTH_L4 = new double []
	{
    1,8,4.14,6283.08,
    2,1,3.28,12566.15
	};

	private static final double [] EARTH_B0 = new double []
	{
		1,280,3.199,84334.662,
		2,102,5.422,5507.553,
		3,80,3.88,5223.69,
		4,44,3.7,2352.87,
		5,32,4,1577.34
	};

	private static final double [] EARTH_B1 = new double []
	{
    1,227778,3.413766,6283.075850,
    2,3806,3.3706,12566.1517,
    3,3620,0,0,
    4,72,3.33,18849.23,
    5,8,3.89,5507.55,
    6,8,1.79,5223.69,
    7,6,5.20,2352.87
	};

	private static final double [] EARTH_B2 = new double []
	{
    1,9721,5.1519,6283.07585,
    2,233,3.1416,0,
    3,134,0.644,12566.152,
    4,7,1.07,18849.23
  };

	private static final double [] EARTH_B3 = new double []
	{
    1,276,0.595,6283.076,
    2,17,3.14,0,
    3,4,0.12,12566.15
  };

	private static final double [] EARTH_B4 = new double []
	{
    1,6,2.27,6283.08,
    2,1,0,0
  };

	private static final double [] EARTH_R0 = new double []
	{
		1,100013989,0,0,
		2,1670700,3.0984635,6283.07585,
		3,13956,3.05525,12566.1517,
		4,3084,5.1985,77713.7715,
		5,1628,1.1739,5753.3849,
		6,1576,2.8469,7860.4194,
		7,925,5.453,11506.77,
		8,542,4.564,3930.21,
		9,472,3.661,5884.927,
		10,346,0.964,5507.553,
		11,329,5.9,5223.694,
		12,307,0.299,5573.143,
		13,243,4.273,11790.629,
		14,212,5.847,1577.344,
		15,186,5.022,10977.079,
		16,175,3.012,18849.228,
		17,110,5.055,5486.778,
		18,98,0.89,6069.78,
		19,86,5.69,15720.84,
		20,86,1.27,161000.69,
		21,65,0.27,17260.15,
		22,63,0.92,529.69,
		23,57,2.01,83996.85,
		24,56,5.24,71430.7,
		25,49,3.25,2544.31,
		26,47,2.58,775.52,
		27,45,5.54,9437.76,
		28,43,6.01,6275.96,
		29,39,5.36,4694,
		30,38,2.39,8827.39,
		31,37,0.83,19651.05,
		32,37,4.9,12139.55,
		33,36,1.67,12036.46,
		34,35,1.84,2942.46,
		35,33,0.24,7084.9,
		36,32,0.18,5088.63,
		37,32,1.78,398.15,
		38,28,1.21,6286.6,
		39,28,1.9,6279.55,
		40,26,4.59,10447.39
	};

	private static final double [] EARTH_R1 = new double []
	{
		1,103019,1.10749,6283.07585,
		2,1721,1.0644,12566.1517,
		3,702,3.142,0,
		4,32,1.02,18849.23,
		5,31,2.84,5507.55,
		6,25,1.32,5223.69,
		7,18,1.42,1577.34,
		8,10,5.91,10977.08,
		9,9,1.42,6275.96,
		10,9,0.27,5486.78
	};

	private static final double [] EARTH_R2 = new double []
	{
		1,4359,5.7846,6283.0758,
		2,124,5.579,12566.152,
		3,12,3.14,0,
		4,9,3.63,77713.77,
		5,6,1.87,5573.14,
		6,3,5.47,18849.23
	};

	private static final double [] EARTH_R3 = new double []
	{
		1,145,4.273,6283.076,
		2,7,3.92,12566.15
	};

	private static final double [] EARTH_R4 = new double []
	{
		1,4,2.56,6283.08
	};

} // EarthJ2000
