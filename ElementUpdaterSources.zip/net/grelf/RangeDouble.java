package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Convenience record for holding a pair of doubles indicating the low and high ends of a range.
	* NB: This was intended to be written using generics but (a) base types cannot be used as T in Range&lt;T&gt; and
	* (b) surprisingly, java.lang.Number does not implement Comparable. Range&lt;T extends Number&gt; becomes too
	* cumbersome to write and to use. */
public class RangeDouble
{
	public double low, high;

	public RangeDouble (double lowValue, double highValue)
	{
		low = lowValue;
		high = highValue;
	} // RangeInt

	/** Ensure that low <= high. Swap the values if this is not the case. Returns true if a swap happened. */
	public boolean order ()
	{
		if (low > high)
		{
			double temp = low;
			low = high;
			high = temp;
			return true;
		}

		return false;
	} // order

	/** Get a String representation of the RangeInt */
	@Override
	public String toString ()
	{
		return "RangeDouble: from " + low + " to " + high;
	} // toString

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		RangeDouble otherRangeDouble = (RangeDouble) other;

		if (otherRangeDouble.low != this.low) return false;
		if (otherRangeDouble.high != this.high) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) (this.low * 31.0  + this.high * 11.0);
	} // hashCode

} // RangeDouble