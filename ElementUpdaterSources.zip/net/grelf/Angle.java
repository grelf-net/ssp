package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2010
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** In java.lang.(Strict)Math you have to keep track of whether an angle is in degrees or radians when you use
 * trigonometrical functions; the present class knows what to do, so you can forget about it! This should reduce
 * the potential for errors of the degrees/radians kind.<br><br>
 * <b>Rationale</b><br>
 * A continual refrain in Jean Meeus' excellent series of books on astronomical computation is the risk of errors
 * due to the fact that angles are usually given in degrees but trigonometry requires radians. It is vital to keep
 * track of this in programs and ensure that conversions between units happen correctly. There is nothing to tell
 * from a numerical value by itself what the units are supposed to be.<br>
 * A first defence against radian/degree confusion is to include the unit names in the names of variables. Eg,
 * latitudeDegrees = 45. That helps to keep track of what the units are supposed to be at any point in a
 * calculation but it does not ensure that they are in fact correct.<br>
 * So for taking a cosine you could write<br>
 *  x = cos (toRadians (latitudeDegrees))<br>
 * and the "Degrees" in the variable name helps you to remember to call the function to convert it to radians
 * first. But it does not guarantee that you will do that. Importantly, the compiler cannot detect such an error
 * because whether the toRadians () function is called or not, the argument to cos () is a number and that's all
 * the compiler requires.<br>
 * In object-oriented languages there is a better remedy: make angles into objects rather than merely numbers. The
 * class definition for Angle can then contain trigonometrical functions that know what units the angle is in and
 * therefore can always do the right thing:<br>
 *  Angle latitude = new Angle (45.0, DEGREES);<br>
 *  x = latitude.cos ();<br>
 * Now the conversion to, and use of, appropriate units is hidden inside the class/object. We don't need to know
 * whether internally the value is held in degrees or radians (though for performance in intensive geometrical
 * calculations it probably ought to be radians). Provided that the class has been thoroughly (unit-) tested the
 * kind of mistake we were discussing simply cannot occur. (In the example DEGREES is meant to be a constant - in
 * Java it would be an enum.)<br>
 * Astronomical quantities such as RA and Dec are angles and so they too should be declared as classes: subclasses
 * of Angle.<br>
 * In the object-oriented language Java (and as far as I know in all commonly used programming languages) this
 * idea has NOT been adopted in the standard library. A Java class called Math has (static) trigonometrical
 * functions taking angles in radians as their arguments. I contend that a much better basis for astronomical
 * computing should declare Angle as outlined above. Angle uses Math internally but any further geometrical
 * programming should only use objects of class Angle. The application programmer should never directly use Math
 * for trigonometry. Inverse functions should be defined as functions (in Java, static methods) creating new Angle
 * objects:<br>
 *  Angle phi = Angle.atan (x);<br>
 * A further benefit of using Angle as a class, and therefore as a data type, is that where functions take several
 * parameters which would otherwise just be a list of numbers, it then becomes clear that particular ones are
 * angles. That again reduces errors, of the kind where the parameters are written in the wrong order.
 */
public class Angle implements Cloneable, Comparable <Angle>, java.io.Serializable
{
  public enum Units
  {
    /** 360 in a circle */
    DEGREES,
    
    /** 24 in a circle */
    HOURS,

    /** 2 pi in a circle */
    RADIANS
  }

  public static final double TWO_PI = 2.0 * StrictMath.PI;
  public static final double FOUR_PI = 4.0 * StrictMath.PI;
  public static final char DEGREE_SYMBOL = '\u00b0';


  protected MeasuredValue valueRadians; // Holding in radians should mean fewer conversions for trigomometry.

  private static final String UNITS = "radians";

  /** Get the value in degrees. */
  public double getDegrees () { return StrictMath.toDegrees (this.valueRadians.getValue ()); }

  /** Get the value in hours. */
  public double getHours () { return StrictMath.toDegrees (this.valueRadians.getValue ()) / 15.0; }

  /** Get the value in radians. */
  public double getRadians () { return this.valueRadians.getValue (); }

  /** Get the standard error in degrees. */
  public double getStdErrDegrees () { return StrictMath.toDegrees (this.valueRadians.getStdErr ()); }

  /** Get the standard error in hours. */
  public double getStdErrHours () { return StrictMath.toDegrees (this.valueRadians.getStdErr ()) / 15.0; }

  /** Get the standard error in radians. */
  public double getStdErrRadians () { return this.valueRadians.getStdErr (); }

  /** Cannot allow outside world to use this because they might not set the units as radians. */
  private Angle (MeasuredValue mv)
  {
    this.valueRadians = mv;
  } // Angle

  public Angle (double value, Units units)
  {
    this (value, 0.0, units);
  } // Angle

  public Angle (double value, double stdErr, Units units)
  {
    switch (units)
    {
      case DEGREES:
        this.valueRadians = new MeasuredValue (StrictMath.toRadians (value),
                                               StrictMath.toRadians (stdErr), UNITS);
        break;

      case HOURS:
        this.valueRadians = new MeasuredValue (StrictMath.toRadians (value * 15.0),
                                               StrictMath.toRadians (stdErr * 15.0), UNITS);
        break;
        
      case RADIANS:
        this.valueRadians = new MeasuredValue (value, stdErr, UNITS);
        break;
    }
  } // Angle

  /** Cosine. */
  public double cos ()
  {
    return StrictMath.cos (getRadians ());
  } // cos

  /** Sine. */
  public double sin ()
  {
    return StrictMath.sin (getRadians ());
  } // sin

  /** Tangent. */
  public double tan ()
  {
    return StrictMath.tan (getRadians ());
  } // tan

  /** Inverse cosine. */
  public static Angle acos (double cos)
  {
    return new Angle (StrictMath.acos (cos), 0.0, Units.RADIANS);
  } // acos

  /** Inverse sine. */
  public static Angle asin (double sin)
  {
    return new Angle (StrictMath.asin (sin), 0.0, Units.RADIANS);
  } // asin

  /** Inverse tangent. */
  public static Angle atan (double tan)
  {
    return new Angle (StrictMath.atan (tan), 0.0, Units.RADIANS);
  } // atan

  /** Inverse tangent. */
  public static Angle atan2 (double y, double x)
  {
    return new Angle (StrictMath.atan2 (y, x), 0.0, Units.RADIANS);
  } // atan2

	/** Returns a new Angle whose value lies in range 0..360 degrees (or 0..2pi radians). */
	public Angle in360 ()
	{
		double x360 = this.getRadians () % TWO_PI;

		if (x360 < 0.0) x360 += TWO_PI;

    return new Angle (x360, this.getStdErrRadians (), Units.RADIANS);
  } // in360

  /** Returns new Angle which is the sum of the present one and other. 
   * Result is not necessarily in the range 0..360 degrees. */
  public Angle add (Angle other)
  {
    try
    {
      return new Angle (this.valueRadians.add (other.valueRadians));
    }
    catch (MixedUnitsException ex)
    {
      net.grelf.Util.warning ("Error", "Mixed units in Angle.add");
      return null;
    }
  } // add

  /** Returns a new Angle which is the result of subtracting other from this.
   * Result is not necessarily in the range 0..360 degrees. */
  public Angle subtract (Angle other)
  {
    try
    {
      return new Angle (this.valueRadians.subtract (other.valueRadians));
    }
    catch (MixedUnitsException ex)
    {
      net.grelf.Util.warning ("Error", "Mixed units in Angle.subtract");
      return null;
    }
  } // subtract

  /** Returns a new Angle that is the result of multiplying the current one by a factor.
   * Result is not necessarily in the range 0..360 degrees. */
  public Angle multiply (double factor)
  {
    return new Angle (this.valueRadians.multiply (factor));
  } // multiply

  /** Similar to subtract but the result is in the range -180..180 degrees. */
  public Angle difference (Angle other)
  {
    double diffDegs = Maths.in360 (this.getDegrees () - other.getDegrees ());

    if (diffDegs > 180.0)
    {
      diffDegs -= 360.0;
    }

    return new Angle (diffDegs, Units.DEGREES);
  } // difference

  /** Implements java.lang.Comparable */
  @Override
  public int compareTo (Angle other)
  {
    Angle diff = this.difference (other);

    // Javadoc for java.lang.Comparable says to throw a NullPointerException here:
    if (null == diff) throw new NullPointerException ("Mixed units in Angle.compareTo (other)");

    double degs = diff.getDegrees ();

    if (degs > 0) return 1;
    if (degs < 0) return -1;
    return 0;
  } // compareTo

  /** Calculate the min, max, mean and stdDev (all in degrees) of a set or list of angles, taking into
    * account periodicity.
		* Uses Maths.angleDifference () from a working mean of the first angle. Does NOT use the erroneous
		* method you can find on the web that averages sin and cos and then takes atan2. */
	public static Maths.Statistics angleStatistics (java.util.Collection <Angle> angles)
	{
		double [] a = new double [angles.size ()];
    int i = 0;

		for (Angle angle : angles)
		{
			a [i] = angle.getDegrees ();
      i++;
		}

		return Maths.angleStatistics (a);
	} // angleStatistics

  /** Calculate the min, max, mean and stdDev (all in degrees) of an array of angles, taking into
    * account periodicity.
		* Uses Maths.angleDifference () from a working mean of the first angle. Does NOT use the erroneous
		* method you can find on the web that averages sin and cos and then takes atan2. */
	public static Maths.Statistics angleStatistics (Angle... angles)
	{
		double [] a = new double [angles.length];

		for (int i = 0; i < a.length; i++)
		{
			a [i] = angles [i].getDegrees ();
		}

		return Maths.angleStatistics (a);
	} // angleStatistics

  @Override
  public Angle clone ()
  {
    return new Angle (this.valueRadians);
  } // clone

  /** Units are radians. */
  @Override
  public String toString ()
  {
    return (this.valueRadians.toString ());
  } // toString

  /** Get a String representing the angle in the required units. */
  public String toString (Units requiredUnits)
  {
    switch (requiredUnits)
    {
      case DEGREES: return new MeasuredValue (getDegrees (), getStdErrDegrees (), "degrees").toString ();
      case HOURS:   return new MeasuredValue (getHours (), getStdErrHours (), "hours").toString ();
      case RADIANS:
      default:      return this.valueRadians.toString ();
    }
  } // toString

  @Override
  public int hashCode ()
  {
    return this.valueRadians.hashCode ();
  } // hashCode

  @Override
  public boolean equals (Object obj)
  {
    if (obj == null) return false;
    if (!getClass ().equals (obj.getClass ())) return false;

    Angle other = (Angle) obj;

    if (!this.valueRadians.equals (other.valueRadians)) return false;

    return true;
  } // equals

} // Angle
