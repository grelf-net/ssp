package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2010
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Record to hold a measured value x, its standard error S and its units, so it can be stated as x +/- S units.
  * The theory used is explained in N.C.Barford "Experimental Measurements: Precision, Error and Truth", 
  * Addison-Wesley 1967. */
public class MeasuredValue implements Cloneable, java.io.Serializable
{
  private double value = 0.0;
  /** Value, x. */
  public double getValue () { return this.value; }

  private double stdErr = 0.0;
  /** Standard error, S. */
  public double getStdErr () { return this.stdErr; }

  private String units = "";
  public String getUnits () { return this.units; }

  /** If stdErr is unknown set it to 0.0. That may also be taken to mean that the value is precisely known. */
  public MeasuredValue (double x, double stdErr, String units)
  {
    this.value = x;
    this.stdErr = stdErr;
    this.units = units;
  } // MeasuredValue

  /** Calculates mean value and standard error from the given data.
   * S = sqrt ((sumX2 / n - mean * mean) / (n - 1)) */
  public MeasuredValue (double [] x, String units)
  {
    calculateFields (x, units);
  } // MeasuredValue

  /** Calculates mean value and standard error from the given data.
   * S = sqrt ((sumX2 / n - mean * mean) / (n - 1)) */
  public MeasuredValue (java.util.Collection <Double> x, String units)
  {
    double [] xArray = new double [x.size ()];
    int i = 0;

    for (double xi : x)
    {
      xArray [i] = xi;
      i++;
    }

    calculateFields (xArray, units);
  } // MeasuredValue

  private void calculateFields (double [] x, String units)
  {
    double sumX = 0.0;
    double sumX2 = 0.0;
    int n = x.length;

    for (int i = 0; i < n; i++)
    {
      sumX += x [i];
      sumX2 += x [i] * x [i];
    }

    double mean = sumX / n;
    this.value = mean;
    this.stdErr = Math.sqrt ((sumX2 / n - mean * mean) / (n - 1));
    this.units = units;
  } // calculateFields

  /** Outputs in the form "value +/- stdErr units" (but only "value units" if stdErr is 0.0). */
  @Override
  public String toString ()
  {
    StringBuffer sb = new StringBuffer ();
    sb.append (this.value);

    if (this.stdErr != 0.0)
    {
      sb.append (" \u00b1 ");
      sb.append (this.stdErr);
    }

    sb.append (" ");
    sb.append (this.units);
    return sb.toString ();
  } // toString

  /** Outputs in the form "value +/- sigma units" (but only "value units" if sigma is 0.0).
    * Specify the format of the numbers. */
  public String toString (java.text.DecimalFormat df)
  {
    StringBuffer sb = new StringBuffer ();
    sb.append (df.format (this.value));

    if (this.stdErr != 0.0)
    {
      sb.append (" \u00b1 ");
      sb.append (df.format (this.stdErr));
    }

    sb.append (" ");
    sb.append (this.units);
    return sb.toString ();
  } // toString

  /** Tests for equality of value, sigma and units to 12 decimals. Consider using probablyEquals () instead. */
  @Override
  public boolean equals (Object other)
  {
    if (null == other) return false;
    if (!this.getClass ().equals (other.getClass ())) return false;
    
    MeasuredValue otherMV = (MeasuredValue) other;

    if (StrictMath.abs (otherMV.value - this.value) > StrictMath.abs (this.value) * 1.e-12) return false;
    if (StrictMath.abs (otherMV.stdErr - this.stdErr) > StrictMath.abs (this.stdErr) * 1.e-12) return false;
    if (!otherMV.units.equals (this.units)) return false;    

    return true;
  } // equals

  /** Still experimental - Aims to returns probability of equality, from 0 to 1. Units must be the same.
   * Values and sigmas are then used to estimate probability of the measurement being the same, assuming
   * Gaussian distributions. */
  public double probablyEquals (Object other)
  {
    if (null == other) return 0;

    if (this.getClass () != other.getClass ()) return 0;

    MeasuredValue otherMV = (MeasuredValue) other;

    if (!otherMV.units.equals (this.units)) return 0;

    double dValues = Math.abs (otherMV.getValue () - this.value);

    if (dValues < this.stdErr * 1.0E-5) return 1.0; // To avoid bad behaviour of Maths.erf (x) near x = 0

    // Probability of other being equal to this:
    double pOther = Maths.erf (dValues / this.stdErr / Maths.SQRT2);

    // Probability of this being equal to other:
    double pThis = Maths.erf (dValues / otherMV.getStdErr () / Maths.SQRT2);

    return StrictMath.sqrt (pOther * pThis);
  } // probablyEquals
  
  @Override
  public int hashCode ()
  {
    return (int) (1234 * this.value + 5678 * this.stdErr) + this.units.hashCode ();
  } // hashCode

  @Override
  public MeasuredValue clone ()
  {
    return new MeasuredValue (this.value, this.stdErr, this.units);
  } // clone

  /** Returns a new MeasuredValue in which the value has number a added to it but stdErr is unchanged.
    * The current object is unchanged. */
  public MeasuredValue add (double a)
  {
    return new MeasuredValue (this.value + a, this.stdErr, this.units);
  } // add

  /* Returns a new MeasuredValue which is the sum of the present one and another.
   * The standard error is the root sum of squares of the two initial standard errors.
   * The current object is unchanged. */
  public MeasuredValue add (MeasuredValue x) throws MixedUnitsException
  {
    if (!this.units.equals (x.units)) throw new MixedUnitsException ();

    return new MeasuredValue (this.value + x.value, 
            StrictMath.sqrt (this.stdErr * this.stdErr + x.stdErr * x.stdErr), this.units);
  } // add

  /* Returns a new MeasuredValue which is the present one minus another.
   * The standard error is the root sum of squares of the two initial standard errors.
   * The current object is unchanged. */
  public MeasuredValue subtract (MeasuredValue x) throws MixedUnitsException
  {
    if (!this.units.equals (x.units)) throw new MixedUnitsException ();

    return new MeasuredValue (this.value - x.value, StrictMath.sqrt (this.stdErr * x.stdErr), this.units);
  } // subtract

  /** Returns a new MeasuredValue in which both the value and the standard error have been multiplied by number a.
    * The current object is unchanged. */
  public MeasuredValue multiply (double a)
  {
    return new MeasuredValue (this.value * a, this.stdErr * a, this.units);
  } // multiply

  /* Returns a new MeasuredValue which is the product of the present one and another.
   * The standard error is calculated as follows.
   * If z = x.y,
   * s(z) = z.sqrt (s(x).s(x) / (x.x) + s(y).s(y) / (y.y))
   * The current object is unchanged. */
  public MeasuredValue multiply (MeasuredValue x) throws MixedUnitsException
  {
    if (!this.units.equals (x.units)) throw new MixedUnitsException ();

    double z = this.value * x.value;
    double x2 = this.value * this.value;
    double y2 = x.value * x.value;
    double sz = z * StrictMath.sqrt (this.stdErr * this.stdErr / x2 + x.stdErr * x.stdErr / y2);
    return new MeasuredValue (z, sz, this.units);
  } // multiply

  /* Returns a new MeasuredValue which is the present one divided by another.
   * The standard error is calculated as follows.
   * If z = x.y,
   * s(z) = z.sqrt (s(x).s(x) / (x.x) + s(y).s(y) / (y.y))
   * The current object is unchanged. */
  public MeasuredValue divide (MeasuredValue x) throws MixedUnitsException
  {
    if (!this.units.equals (x.units)) throw new MixedUnitsException ();

    double z = this.value / x.value;
    double x2 = this.value * this.value;
    double y2 = x.value * x.value;
    double sz = z * StrictMath.sqrt (this.stdErr * this.stdErr / x2 + x.stdErr * x.stdErr / y2);
    return new MeasuredValue (z, sz, this.units);
  } // divide

} // MeasuredValue
