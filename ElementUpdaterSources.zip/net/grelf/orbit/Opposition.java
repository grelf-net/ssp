package net.grelf.orbit;

import net.grelf.astro.Dec;
import net.grelf.astro.JulianDate;

/** Record to hold details of an opposition.
 *
 * @author Graham Relf, www,grelf.net
 */
public class Opposition
{
  String name;
  String date; // yyyy-MMM-dd hh'h'
  JulianDate jd;
  double magnitude;
  double decDegs;
  double rAU;
  double deltaAU;
  double phaseDegs;
  double skySpeedDegsPerHr;

  // Orbital elements:
  double e;
  double aAU;
  double iDegs;
  double omegaDegs;
  double periArgDegs;
  double epochJD;
  double _MDegs;
  double _G;
  double _H;
} // Opposition
