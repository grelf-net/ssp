package net.grelf.orbit;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.xml.datatype.DatatypeConfigurationException;
import net.grelf.Angle;
import net.grelf.FileIO;
import net.grelf.Maths;
import net.grelf.Util;
import net.grelf.XYZ;
import net.grelf.astro.Dec;
import net.grelf.astro.Epoch;
import net.grelf.astro.JulianDate;
import net.grelf.astro.Orbit;
import net.grelf.astro.RA;
import net.grelf.astro.SkyPoint;
import net.grelf.planet.EarthJ2000;
import net.grelf.planet.WrongRowNumberException;

/** Get orbital elements for comets and asteroids from the Minor Planet Center
 * and reformat them as properties files for use in ChartGen and Ecliptic
 * 25.6.10-28: Output .js files for project Observable as well as .properties
 * 18.10.7: MPC URL is https:, not http:
 * 15.6.24: Ask user whether wanting comets and/or asteroids
 *
 * @author Graham Relf, www.grelf.net
 */
public class ElementUpdater implements Runnable
{
  public static final String VERSION = "25.7.6";//"18.10.7";//"15.6.24"; //"14.7.27";
  public static String cometDir = "comets";
  public static final String COMET_JS = "_comet.js";
  public static final String COMET_PROPERTIES = "comet.properties";
  public static String asteroidDir = "asteroids";
  public static final String ASTEROID_JS = "_minor.js";
  public static final String ASTEROID_PROPERTIES = "minor.properties";
  public static final String NAMES_FILE = "names.dat";

  private double maxAsteroidMagnitude = 12.0;

	public static void main (String... args)
	{
		try
		{
			UIManager.setLookAndFeel (UIManager.getSystemLookAndFeelClassName ());
			SwingUtilities.invokeAndWait (new ElementUpdater ());
    }
    catch (Exception ex)
    {
      System.out.println (ex.toString ());
      ex.printStackTrace ();
      System.out.println (ex.getCause ().toString ());
      ex.getCause ().printStackTrace ();
    }
	} // main

  @Override
  public void run ()
  {
    System.out.println ("ElementUpdater v" + VERSION);

    if (Util.confirm ("Confirm", "Do you want comet elements?"))
    {
      cometDir = FileIO.selectDirectory ("Select output directory for comets", null);
      StringBuffer comets = getCometElementsFromMPC ();
      Properties cometProps = convertCometElementsToPropertiesAndJS (comets);
      convertCometPropertiesToFiles (cometProps);
    }

    if (Util.confirm ("Confirm", "Do you want asteroid elements?"))
    {
      asteroidDir = FileIO.selectDirectory ("Select output directory for asteroids", null);
      maxAsteroidMagnitude = Util.askInteger ("Max asteroid magnitude?", 12, 9, 30);

      if (maxAsteroidMagnitude >= 9 && maxAsteroidMagnitude <= 30)
      {
        earthEphemeris ();
        StringBuffer asteroids = getAsteroidElementsFromMPC ();
        Properties asteroidProps = convertAsteroidElementsToPropertiesAndJS (asteroids);
        convertAsteroidPropertiesToFiles (asteroidProps);
      }
    }

    System.out.println ("Done");
  } // run

  private StringBuffer getCometElementsFromMPC ()
  {
    try
    {
      URL url = new URL (
        "https://www.minorplanetcenter.net/iau/Ephemerides/Comets/Soft00Cmt.txt");
			return doQuery (url);
    }
    catch (MalformedURLException ex)
    {
      logException (ex);
    }

    return null;
  } // getCometElementsFromMPC

  private Properties convertCometElementsToPropertiesAndJS (StringBuffer comets)
  {
    OutputStream out = null;
    PrintWriter outJS;
    final String COMMA = ",", QUOTE = "\"";
    Properties props = new Properties ();
    int nProcessed = 0;
    int nWithoutEpoch = 0;
    int nShortLines = 0;

    try
    {
      outJS = new PrintWriter (new File (cometDir + File.separator + COMET_JS));
      outJS.println ("const COMETS = [");
      String [] lines = comets.toString ().split ("\n");

      for (String line : lines)
      {
        if (line.length () < 142)
        {
          nShortLines++;
        }
        else
        {
          StringBuilder lineSB = new StringBuilder (line);

          //Remove non-ASCII blanks:
          for (int i = 0; i < lineSB.length (); i++)
          {
            int ch = (int) lineSB.charAt (i);

            if (ch < 32 || ch > 127)
            {
              lineSB.replace (i, i, " ");
            }
          }

          // MPC format:
          String id = lineSB.substring (0, 4);
          // 1 -   4  i4     Periodic comet number
          //String orbitType = lineSB.substring (4, 5);
          // 5        a1     Orbit type (generally `C', `P' or `D')
          //String packedDesig = lineSB.substring (5, 12);
          // 6 -  12  a7     Provisional designation (in packed form)
          String periYear = lineSB.substring (14, 18);
          // 15 -  18  i4     Year of perihelion passage
          String periMonth = lineSB.substring (19, 21);
          // 20 -  21  i2     Month of perihelion passage
          String periDay = lineSB.substring (22, 29);
          // 23 -  29  f7.4   Day of perihelion passage (TT)
          String qAU = lineSB.substring (30, 39);
          // 31 -  39  f9.6   Perihelion distance (AU)
          String e = lineSB.substring (41, 49);
          // 42 -  49  f8.6   Orbital eccentricity
          String periArgDegs = lineSB.substring (51, 59);
          // 52 -  59  f8.4   Argument of perihelion, J2000.0 (degrees)
          String omegaDegs = lineSB.substring (61, 69);
          // 62 -  69  f8.4   Longitude ascend node, J2000.0 (degrees)
          String iDegs = lineSB.substring (71, 79);
          // 72 -  79  f8.4   Inclination, J2000.0 (degrees)
          String epochYear = lineSB.substring (81, 85);
          // 82 -  85  i4     Year of epoch for perturbed solutions
          String epochMonth = lineSB.substring (85, 87);
          // 86 -  87  i2     Month of epoch for perturbed solutions
          String epochDay = lineSB.substring (87, 89);
          // 88 -  89  i2     Day of epoch for perturbed solutions
          String absMagn = lineSB.substring (91, 95);
          // 92 -  95  f4.1   Absolute magnitude
          String slopeParam = lineSB.substring (96, 100);
          // 97 - 100  f5.1   Slope parameter
          String name = lineSB.substring (102, 140).trim ();
          // 103 -     a      Name
          String epochJD;
          String edTrim = epochDay.trim ();

          if (edTrim.length () > 0)
          {
            double epochDayNo = Double.parseDouble (edTrim);
            Calendar epoch = new GregorianCalendar (Integer.parseInt (epochYear),
              Integer.parseInt (epochMonth) - 1, 0, 0, 0, 0);
              // NO day, hour, minute or second
            epochJD = "" + ((epoch.getTimeInMillis () / 86400000L) +
                    epochDayNo + 2440587.5); // 1970.0
          }
          else
          {
            Calendar epoch = new GregorianCalendar (); // Now
            epochJD = "" +
                 ((epoch.getTimeInMillis () / 86400000L) + 2440587.5); // 1970.0
            nWithoutEpoch++;
          }

          if (id.equals ("    ")) // Not periodic
          {
            int idx = name.indexOf (" (");

            if (idx == -1)
            {
              id = spacesToUnderscores (name.substring (2));
            }
            else
            {
              id = spacesToUnderscores (name.substring (2, idx));
            }
          }
          else // Periodic
          {
            try
            {
              id = Integer.parseInt (id) + "P";
            }
            catch (NumberFormatException ex)
            {
              // Nothing to do: just leave id as it is
            }
          }

// Required JS parameters:
//function Orbit (name, symbol, kind, colour,
//  tauY, tauM, tauD, qAU, e, periArgDegs, omegaDegs, iDegs, epochJD, h, g)
          outJS.print (QUOTE);
          outJS.print (name);
          outJS.print (QUOTE);
          outJS.print (COMMA);
          outJS.print (QUOTE);
          outJS.print (id);
          outJS.print (QUOTE);
          outJS.print (COMMA);
          outJS.print (periYear);
          outJS.print (COMMA);
          outJS.print (periMonth);
          outJS.print (COMMA);
          outJS.print (periDay);
          outJS.print (COMMA);
          outJS.print (qAU);
          outJS.print (COMMA);
          outJS.print (e);
          outJS.print (COMMA);
          outJS.print (periArgDegs);
          outJS.print (COMMA);
          outJS.print (omegaDegs);
          outJS.print (COMMA);
          outJS.print (iDegs);
          outJS.print (COMMA);
          outJS.print (epochJD);
          outJS.print (COMMA);
          outJS.print (absMagn);
          outJS.print (COMMA);
          outJS.print (slopeParam);
          outJS.print (COMMA);
          outJS.println ();

          StringBuilder value = new StringBuilder ();
          value.append (id);
          value.append (',');
          value.append (periYear);
          value.append (',');
          value.append (periMonth);
          value.append (',');
          value.append (periDay);
          value.append (',');
          value.append (qAU);
          value.append (',');
          value.append (e);
          value.append (',');
          value.append (periArgDegs);
          value.append (',');
          value.append (omegaDegs);
          value.append (',');
          value.append (iDegs);
          value.append (',');
          value.append (epochJD);
          value.append (',');
          value.append (absMagn);
          value.append (',');
          value.append (slopeParam);
          props.setProperty (name, value.toString ());
          nProcessed++;
        }
      }
      
      outJS.println ("];");
      outJS.flush ();
      outJS.close ();

      out = new BufferedOutputStream (new FileOutputStream (
              cometDir + File.separator + COMET_PROPERTIES));
      props.store (out, "Comet elements");
    }
    catch (FileNotFoundException ex)
    {
      logException (ex);
    }
    catch (IOException ex)
    {
      logException (ex);
    }
    finally
    {
      if (null != out)
      {
        try
        {
          out.close ();
        }
        catch (IOException ex)
        {
          logException (ex);
        }
      }
    }

    JOptionPane.showMessageDialog (null, nProcessed + " comets processed\n" +
            nWithoutEpoch + " with no epoch\n" +
            nShortLines + " lines too short to process");

    return props;
  } // convertCometElementsToPropertiesAnd JS

  private void convertCometPropertiesToFiles (Properties props)
  {
    int n = props.size ();
    String [] names = new String [n];
    int i = 0;

    for (Iterator <Object> it = props.keySet ().iterator (); it.hasNext (); i++)
    {
      names [i] = (String) it.next ();
      String value = props.getProperty (names [i]);
      int idx = value.indexOf (',');

      if (-1 == idx)
      {
        logException (new Exception ("Could not get id for comet " + names [i]));
      }
      else
      {
        String id = value.substring (0, idx);
        PrintWriter out1 = null;

        try
        {
          out1 = new PrintWriter (cometDir + File.separator + id + ".dat");
          out1.print (names [i]);
          out1.print ('=');
          out1.println (value);
        }
        catch (FileNotFoundException ex)
        {
          logException (ex);
        }
        finally
        {
          if (null != out1)
          {
            out1.close ();
          }
        }
      }
    }

    Arrays.sort (names);

    try
    {
      PrintWriter out = new PrintWriter (cometDir + File.separator + NAMES_FILE);

      for (String name : names)
      {
        out.println (name);
      }

      out.close ();
    }
    catch (FileNotFoundException ex)
    {
      logException (ex);
    }
  } // convertCometPropertiesToFiles

  private StringBuffer getAsteroidElementsFromMPC ()
  {
    try
    {
      URL url = new URL (
              "http://www.minorplanetcenter.net/iau/MPCORB/MPCORB.DAT");
			return doQuery (url);
    }
    catch (MalformedURLException ex)
    {
      logException (ex);
    }

    return null;
  } //getAsteroidElementsFromMPC

  private static final int NDAYS = 450; // About a year + 3 months
  private static final XYZ [] EARTH_XYZS = new XYZ [NDAYS * 8];
  private static double START_JD = Math.floor (new JulianDate ().toDouble ()) - 60.5;
  // Start 2 months before now, so asteroids just past opposition are included

  private static double EPSILON_DEGS;
  private static double COS_EPSILON;
  private static double SIN_EPSILON;

  static
  {
    try
    {
      EPSILON_DEGS = new EarthJ2000 (START_JD).getEclipticObliquityDegs (Epoch.J2000);
    }
    catch (WrongRowNumberException ex)
    {
      Logger.getLogger (
              ElementUpdater.class.getName()).log (Level.SEVERE, null, ex);
      EPSILON_DEGS = 0.0;
    }

    COS_EPSILON = Maths.cosDegs (EPSILON_DEGS);
    SIN_EPSILON = Maths.sinDegs (EPSILON_DEGS);
  }

  private int maxLines = 20000;

  protected void earthEphemeris ()
  {
    try
    {
      for (int i = 0; i < NDAYS * 8; i++)
      {
        double jd = START_JD + i;
        EARTH_XYZS [i] = new EarthJ2000 (jd).getHeliocentricCoordinates ();
      }
    }
    catch (WrongRowNumberException ex)
    {
      Logger.getLogger (
              ElementUpdater.class.getName()).log (Level.SEVERE, null, ex);
    }
  } // earthEphemeris

  /** Selects only those asteroids with oppositions within NDAYS after START_JD at
   * magnitude less than maxMag.
   * 25.6.15 Also only process the first 10,000 entries. */
  protected Properties convertAsteroidElementsToPropertiesAndJS (StringBuffer asteroids)
  {
    OutputStream out = null;
    PrintWriter outJS;
    final String COMMA = ",", QUOTE = "\"";
    Properties props = new Properties ();
    int nProcessed = 0;
    int nSelected = 0;
    int nWithoutEpoch = 0;
    int nShortLines = 0;
    int nDots = 0;
    String name = "";//for JS
    int idJS;//for JS

    try
    {
      outJS = new PrintWriter (new File (asteroidDir + File.separator + ASTEROID_JS));
      outJS.println ("const ASTEROIDS = [");
      String [] lines = asteroids.toString ().split ("\n");
      boolean dataStarted = false;

      for (String line : lines)
      {
        dataStarted = dataStarted || line.startsWith ("00001");

        if (dataStarted)
        {
          if (line.length () < 160)
          {
            nShortLines++;
          }
          else
          {
            StringBuilder lineSB = new StringBuilder (line);

            //Remove non-ASCII blanks:
            for (int i = 0; i < lineSB.length (); i++)
            {
              int ch = (int) lineSB.charAt (i);

              if (ch < 32 || ch > 127)
              {
                lineSB.replace (i, i, " ");
              }
            }

            // MPC format:
            String id = lineSB.substring (0, 7).trim ();
            //   1 -  7  a7     Asteroid number or provisional id (packed)
            String sH = lineSB.substring (8, 13);
            //   9 - 13  f5.2   Absolute magnitude, H
            String sG = lineSB.substring (14, 19);
            //  15 - 19  f5.2   Slope parameter, G
            String sEpoch = lineSB.substring (20, 25);
            //  19 - 25  a5     Epoch in packed form (.0 TT)
            String sMDegs = lineSB.substring (26, 35);
            //  27 - 35  f9.5   Mean anomaly at the epoch, in degrees
            String sPeriArgDegs = lineSB.substring (37, 46);
            //  38 -  46  f9.5   Argument of perihelion, J2000.0 (degrees)
            String sOmegaDegs = lineSB.substring (48, 57);
            //  49 -  57  f9.5   Longitude of the ascending node, J2000.0 (degrees)
            String sIDegs = lineSB.substring (59, 68);
            //  60 -  68  f9.5   Inclination to the ecliptic, J2000.0 (degrees)
            String se = lineSB.substring (70, 79);
            //  71 -  79  f9.7   Orbital eccentricity
            String snDegsPerDay = line.substring (80, 91);
            //  81 -  91  f11.8  Mean daily motion (degrees per day)
            String saAU = line.substring (92, 103);
            //  93 - 103  f11.7  Semimajor axis (AU)
/*
  106        i1     Uncertainty parameter, U
                    If this column contains `E' it indicates
                    that the orbital eccentricity was assumed.
                    For one-opposition orbits this column can
                    also contain `D' if a double (or multiple)
                    designation is involved or `F' if an e-assumed
                    double (or multiple) designation is involved.

  108 - 116  a10    Reference
  118 - 122  i5     Number of observations
  124 - 126  i3     Number of oppositions

     For multiple-opposition orbits:
     128 - 131  i4     Year of first observation
     132        a1     '-'
     133 - 136  i4     Year of last observation

     For single-opposition orbits:
     128 - 131  i4     Arc length (days)
     133 - 136  a4     'days'

  138 - 141  f4.2   r.m.s residual (")
  143 - 145  a3     Coarse indicator of perturbers
                    (blank if unperturbed one-opposition object)
  147 - 149  a3     Precise indicator of perturbers
                    (blank if unperturbed one-opposition object)
  151 - 160  a10    Computer name

There may sometimes be additional information beyond column 160
as follows:

  162 - 165  z4.4   4-hexdigit flags
                    The bottom 6 bits (bits 0 to 5) are used to encode
                    a value representing the orbit type (other
                    values are undefined):

                     Value
                        2  Aten
                        3  Apollo
                        4  Amor
                        5  Object with q < 1.665 AU
                        6  Hungaria
                        7  Phocaea
                        8  Hilda
                        9  Jupiter Trojan
                       10  Centaur
                       14  Plutino
                       15  Other resonant TNO
                       16  Cubewano
                       17  Scattered disk

                    Additional information is conveyed by
                    adding in the following bit values:

               Bit  Value
                 6     64  Unused
                 7    128  Unused
                 8    256  Unused
                 9    512  Unused
                10   1024  Unused
                11   2048  Object is NEO
                12   4096  Object is 1-km (or larger) NEO
                13   8192  1-opposition object seen at
                           earlier opposition
                14  16384  Critical list numbered object
                15  32768  Object is PHA

                    Note that the orbit classification is
                      based on cuts in osculating element
                      space and is not 100% reliable.
*/
            idJS = Integer.parseInt (id);
            
            if (line.length () >= 194)
            {
              // Overwrite simpler id:
              id = removeParentheses (line.substring (166, 194).trim ());
              // 167 - 194  a      Readable designation
              name = line.substring (174, 194).trim ();//JS
            }
/*
  195 - 202  i8     Date of last observation included in
                      orbit solution (YYYYMMDD format)
*/

            String epochJD = unpackDate (sEpoch);

            if (null == epochJD)
            {
              Util.logWarning ("Error in line:" + line);
            }
            else
            {
              Opposition oppn = suitableOpposition (id, sH, sG, epochJD,
                      sMDegs, sPeriArgDegs, sOmegaDegs, sIDegs, se, snDegsPerDay, saAU);

              if (null != oppn)
              {
// Required JS parameters:
//"name=id",
//["Date","JD","Mag","Dec (degs J2000)","r (AU)","delta (AU)","Phase (degs)","Sky speed (degs/hr)",]
//"e","a (AU)","i (degs)","Omega (degs)","Peri arg (degs)","epoch (JD)","M (degs)","G","H",

                outJS.print (QUOTE);
                outJS.print (name + "=" + idJS);
                outJS.print (QUOTE);
                outJS.print (COMMA);

//25.6.29                for (int i = 1; i < 9; i++) outJS.print (COMMA);//fields not needed
                
                outJS.print (se);
                outJS.print (COMMA);
                outJS.print (saAU);
                outJS.print (COMMA);
                outJS.print (sIDegs);
                outJS.print (COMMA);
                outJS.print (sOmegaDegs);
                outJS.print (COMMA);
                outJS.print (sPeriArgDegs);
                outJS.print (COMMA);
                outJS.print (new JulianDate (epochJD).toDouble ());
                outJS.print (COMMA);
                outJS.print (sMDegs);
                outJS.print (COMMA);
                outJS.print (sG);
                outJS.print (COMMA);
                outJS.print (sH);
                outJS.print (COMMA);
                outJS.println ();
                
                // Build the properties entry:
//#Name=OppnDate,OppnJD,Mag,Dec (degs J2000),r (AU),delta (AU),Phase (degs),Sky speed (degs/hr),e,a (AU),i (degs),Omega (degs),Peri arg (degs),epoch (JD),M (degs),G,H
                StringBuilder value = new StringBuilder ();
                value.append (oppn.date); // 0
                value.append (',');
                value.append (oppn.jd.toDouble ()); // 1
                value.append (',');
                value.append (oppn.magnitude); // 2
                value.append (',');
                value.append (oppn.decDegs); // 3
                value.append (',');
                value.append (oppn.rAU); // 4
                value.append (',');
                value.append (oppn.deltaAU); // 5
                value.append (',');
                value.append (oppn.phaseDegs); // 6
                value.append (',');
                value.append (oppn.skySpeedDegsPerHr); // 7
                value.append (',');
                value.append (oppn.e); // 8
                value.append (',');
                value.append (oppn.aAU); // 9
                value.append (',');
                value.append (oppn.iDegs); // 10
                value.append (',');
                value.append (oppn.omegaDegs); // 11
                value.append (',');
                value.append (oppn.periArgDegs); // 12
                value.append (',');
                value.append (oppn.epochJD); // 13
                value.append (',');
                value.append (oppn._MDegs); // 14
                value.append (',');
                value.append (oppn._G); // 15
                value.append (',');
                value.append (oppn._H); // 16
                System.out.println ();
                System.out.println (oppn.name);
                props.setProperty (oppn.name, value.toString ());
                nSelected++;
              }
              else
              {
                System.out.print (".");
                nDots++;

                if (nDots > 100)
                {
                  System.out.println ();
                  nDots = 0;
                }
              }
            }

            nProcessed++;
          }
        }
        
        if (nProcessed > 10000) break;
      }

      outJS.println ("];");
      outJS.flush ();
      outJS.close ();

      out = new BufferedOutputStream (new FileOutputStream (
              asteroidDir + File.separator + ASTEROID_PROPERTIES));
      props.store (out,
"Asteroid=oppn date,JD,Mag,Dec degs J2000,r AU,delta AU,Phase degs,Speed degs/hr," +
"e,a AU,i degs,Omega degs,Peri arg degs,Epoch JD,M degs,G,H");
    }
    catch (DatatypeConfigurationException | IOException ex)
    {
      logException (ex);
    }
    finally
    {
      if (null != out)
      {
        try
        {
          out.close ();
        }
        catch (IOException ex)
        {
          logException (ex);
        }
      }
    }

    JOptionPane.showMessageDialog (null, nProcessed + " asteroids processed\n" +
            nWithoutEpoch + " with no epoch\n" +
            nShortLines + " lines too short to process");

    return props;
  } // convertAsteroidElementsToPropertiesAndJS

  protected void convertAsteroidPropertiesToFiles (Properties props)
  {
    int n = props.size ();
    String [] names = new String [n];
    int i = 0;

    for (Iterator <Object> it = props.keySet ().iterator (); it.hasNext (); i++)
    {
      names [i] = (String) it.next ();
      String value = props.getProperty (names [i]);
/*
      int idx = value.indexOf (',');

      if (-1 == idx)
      {
        logException (new Exception ("Could not get id for asteroid " + names [i]));
      }
      else
      {
        String id = value.substring (0, idx);
*/
/**/
String id = spacesToUnderscores (names [i]);
/**/
        PrintWriter out1 = null;

        try
        {
          out1 = new PrintWriter (asteroidDir + File.separator + id + ".dat");
          out1.print (names [i]);
          out1.print ('=');
          out1.println (value);
        }
        catch (FileNotFoundException ex)
        {
          logException (ex);
        }
        finally
        {
          if (null != out1)
          {
            out1.close ();
          }
        }
      }
/*
    }
*/

    Arrays.sort (names);

    try
    {
      PrintWriter out = new PrintWriter (asteroidDir + File.separator + NAMES_FILE);

      for (String name : names)
      {
        out.println (name);
      }

      out.close ();
    }
    catch (FileNotFoundException ex)
    {
      logException (ex);
    }
  } // convertAsteroidPropertiesToFiles

  /** Converts "nnn Name" to "Name=nnn".
   * If the string is not in that format, returns "Name=" instead. */
  private String propertyStart (String name)
  {
    if (Character.isDigit (name.charAt (0)))
    {
      int idx = name.indexOf (" ");

      if (-1 != idx)
      {
        return name.substring (idx + 1) + "=" + name.substring (0, idx);
      }
    }

    return name + "=";
  } // propertyStart

	private StringBuffer doQuery (URL url)
	{
		try
		{
			java.io.InputStream is = url.openStream ();
			java.io.BufferedReader br =
              new java.io.BufferedReader (new java.io.InputStreamReader (is));
			StringBuffer response = new StringBuffer ();
			String line;

			while (null != (line = br.readLine ()))
			{
				response.append (line);
				response.append ('\n');
			}

			br.close ();
			is.close ();
			return response;
		}
		catch (java.io.IOException ex)
    {
      logException (ex);
    }

		return null;
	} // doQuery

  private String unpackDate (String mpcDate) throws NumberFormatException
  {
    StringBuilder xmlDate = new StringBuilder ();

    switch (mpcDate.charAt (0))
    {
      case 'I': xmlDate.append ("18"); break;
      case 'J': xmlDate.append ("19"); break;
      case 'K': xmlDate.append ("20"); break;
      default: net.grelf.Util.warning ("Error", "Unknown century code in epoch field");
    }

    xmlDate.append (mpcDate.substring (1, 3));
    xmlDate.append ('-');

    switch (mpcDate.charAt (3))
    {
      case '1': xmlDate.append ("01"); break;
      case '2': xmlDate.append ("02"); break;
      case '3': xmlDate.append ("03"); break;
      case '4': xmlDate.append ("04"); break;
      case '5': xmlDate.append ("05"); break;
      case '6': xmlDate.append ("06"); break;
      case '7': xmlDate.append ("07"); break;
      case '8': xmlDate.append ("08"); break;
      case '9': xmlDate.append ("09"); break;
      case 'A': xmlDate.append ("10"); break;
      case 'B': xmlDate.append ("11"); break;
      case 'C': xmlDate.append ("12"); break;
      default:
        Util.warning ("Error", "Impossible month character in " + mpcDate);
        return null;
    }

    xmlDate.append ('-');

    switch (mpcDate.charAt (4))
    {
      case '1': xmlDate.append ("01"); break;
      case '2': xmlDate.append ("02"); break;
      case '3': xmlDate.append ("03"); break;
      case '4': xmlDate.append ("04"); break;
      case '5': xmlDate.append ("05"); break;
      case '6': xmlDate.append ("06"); break;
      case '7': xmlDate.append ("07"); break;
      case '8': xmlDate.append ("08"); break;
      case '9': xmlDate.append ("09"); break;
      case 'A': xmlDate.append ("10"); break;
      case 'B': xmlDate.append ("11"); break;
      case 'C': xmlDate.append ("12"); break;
      case 'D': xmlDate.append ("13"); break;
      case 'E': xmlDate.append ("14"); break;
      case 'F': xmlDate.append ("15"); break;
      case 'G': xmlDate.append ("16"); break;
      case 'H': xmlDate.append ("17"); break;
      case 'I': xmlDate.append ("18"); break;
      case 'J': xmlDate.append ("19"); break;
      case 'K': xmlDate.append ("20"); break;
      case 'L': xmlDate.append ("21"); break;
      case 'M': xmlDate.append ("22"); break;
      case 'N': xmlDate.append ("23"); break;
      case 'O': xmlDate.append ("24"); break;
      case 'P': xmlDate.append ("25"); break;
      case 'Q': xmlDate.append ("26"); break;
      case 'R': xmlDate.append ("27"); break;
      case 'S': xmlDate.append ("28"); break;
      case 'T': xmlDate.append ("29"); break;
      case 'U': xmlDate.append ("30"); break;
      case 'V': xmlDate.append ("31"); break;
      default:
        Util.warning ("Error", "Impossible day character in " + mpcDate);
        return null;
    }

    return xmlDate.toString ();
  } // unpackDate

  private String unpackDesig (String mpcDesig) throws NumberFormatException
  {
    StringBuilder sb = new StringBuilder ();
    sb.append (mpcDesig.charAt (0));
    sb.append ('/');

    switch (mpcDesig.charAt (1))
    {
      case 'I': sb.append ("18"); break;
      case 'J': sb.append ("19"); break;
      case 'K': sb.append ("20"); break;
      default: net.grelf.Util.warning ("Error",
              "Unknown century code in packedDesig:" + mpcDesig);
    }

    sb.append (mpcDesig.substring (2, 4));
    sb.append (' ');
    int n;

    try
    {
      n = Integer.parseInt (mpcDesig.substring (4, 6));
    }
    catch (NumberFormatException ex)
    {
      Util.logWarning ("Invalid number in:" + mpcDesig);
      n = 0;
    }

    sb.append (n);


    return sb.toString ();
  } // unpackDesig

  private void logException (Exception ex)
  {
    System.out.println (ex.toString ());
    Logger.getLogger (ElementUpdater.class.getName()).log (Level.SEVERE, null, ex);
  } // logException

  /** Returns null if the opposition is not suitable (darker than maxMag). */
  private Opposition suitableOpposition (String id, String sH, String sG,
          String sEpochJD, String sMDegs, String sPeriArgDegs, String sOmegaDegs,
          String sIDegs, String se, String snDegsPerDay, String saAU)
  {
    String fieldId = "unknown";

    if (sH.length () > 0 && sG.length () > 0) // Otherwise cannot estimate magnitude
    {
      try
      {
        fieldId = "sH";
        double _H = Double.parseDouble (sH);
        fieldId = "sG";
        double _G = Double.parseDouble (sG);
        fieldId = "sEpochJD";
        double epochJD = new JulianDate (sEpochJD).toDouble ();
        fieldId = "sMDegs";
        double _MDegs = Double.parseDouble (sMDegs);
        fieldId = "sPeriArgDegs";
        double periArgDegs = Double.parseDouble (sPeriArgDegs);
        fieldId = "sOmegaDegs";
        double omegaDegs = Double.parseDouble (sOmegaDegs);
        fieldId = "sIDegs";
        double iDegs = Double.parseDouble (sIDegs);
        fieldId = "se";
        double e = Double.parseDouble (se);
//        fieldId = "snDegsPerDay";
//        double nDegsPerDay = Double.parseDouble (snDegsPerDay); // Not used
        fieldId = "saAU";
        double aAU = Double.parseDouble (saAU);

        if (e < 1.0)
        {
          Orbit orbit = new Orbit (Orbit.Kind.ASTEROID)
                .name (id)
                .symbol (".")
                .colour (java.awt.Color.RED)
                .epoch (epochJD)
                .e (e)
                .aAU (aAU)
                .iDegs (iDegs)
                .omegaDegs (omegaDegs)
                .periLongDegs (Maths.in360 (periArgDegs + omegaDegs))
                .meanAnomalyDegs (_MDegs)
                ._G (_G)
                ._H (_H);
          JulianDate oppositionJD = findOpposition (orbit);

          if (null != oppositionJD)
          {
            try
            {
              double jd = oppositionJD.toDouble ();
              EarthJ2000 earth = new EarthJ2000 (jd);
              XYZ earthXYZ = earth.getHeliocentricCoordinates ();
              XYZ objXYZ = orbit.getHeliocentricPositionAU (oppositionJD);
              double dX = objXYZ.x - earthXYZ.x;
              double dY = objXYZ.y - earthXYZ.y;
              double dZ = objXYZ.z - earthXYZ.z;

              //Rotate from ecliptic to equatorial coordinates to get RA and Dec:
              double dXeq = dX;
              double dYeq = dY * COS_EPSILON - dZ * SIN_EPSILON;
              double dZeq = dY * SIN_EPSILON + dZ * COS_EPSILON;
              double objRaDegs = Maths.atan2Degs (dYeq, dXeq);
              double objDecDegs =
                 Maths.atan2Degs (dZeq, StrictMath.sqrt (dXeq * dXeq + dYeq * dYeq));

              double rAU = objXYZ.getRadius ();
              double deltaAU = StrictMath.sqrt (dX * dX + dY * dY + dZ * dZ);
              double scalarProduct = dX * objXYZ.x + dY * objXYZ.y + dZ * objXYZ.z;
              double phaseDegs = Maths.acosDegs (scalarProduct / (rAU * deltaAU));
              double logtanPhase2 = StrictMath.log (
                      net.grelf.Maths.tanDegs (0.5 * phaseDegs));
              double tanB1 = StrictMath.exp (logtanPhase2 * 0.63);
              double tanB2 = StrictMath.exp (logtanPhase2 * 1.22);
              double phi1 = StrictMath.exp (-3.33 * tanB1);
              double phi2 = StrictMath.exp (-1.87 * tanB2);
              double _Halpha = orbit.getH () -
                      2.5 * StrictMath.log10 ((1.0 - orbit.getG ()) * phi1 +
                      orbit.getG () * phi2);
              double magV = _Halpha + 5.0 * StrictMath.log10 (rAU * deltaAU);

              if (magV <= maxAsteroidMagnitude)
              {
                // Calculate apparent speed:
                double degsPerHour;
                {
                  jd++;
                  earth = new EarthJ2000 (jd);
                  earthXYZ = earth.getHeliocentricCoordinates ();
                  objXYZ = orbit.getHeliocentricPositionAU (new JulianDate (jd));
                  dX = objXYZ.x - earthXYZ.x;
                  dY = objXYZ.y - earthXYZ.y;
                  dZ = objXYZ.z - earthXYZ.z;

                  //Rotate from ecliptic to equatorial coordinates to get RA and Dec:
                  dXeq = dX;
                  dYeq = dY * COS_EPSILON - dZ * SIN_EPSILON;
                  dZeq = dY * SIN_EPSILON + dZ * COS_EPSILON;
                  double objRaDegs1 = Maths.atan2Degs (dYeq, dXeq);
                  double objDecDegs1 =
                          Maths.atan2Degs (dZeq,
                          StrictMath.sqrt (dXeq * dXeq + dYeq * dYeq));

                  SkyPoint pt0 =
                          new SkyPoint (new RA (objRaDegs), new Dec (objDecDegs),
                            Epoch.J2000);
                  SkyPoint pt1 =
                          new SkyPoint (new RA (objRaDegs1), new Dec (objDecDegs1),
                            Epoch.J2000);
                  degsPerHour =
                          pt0.calculateSeparation (pt1).
                            getSeparation ().getDegrees () / 24.0;
                }

                Opposition oppn = new Opposition ();
                oppn.name = id;
                oppn.date = YYYYMMDDHH.format (oppositionJD.toGregorianCalendar ().
                        getTime ()) + "h";
                oppn.jd = oppositionJD;
                oppn.magnitude = magV;
                oppn.decDegs = objDecDegs;
                oppn.rAU = rAU;
                oppn.deltaAU = deltaAU;
                oppn.phaseDegs = phaseDegs;
                oppn.skySpeedDegsPerHr = degsPerHour;
                oppn.e = e;
                oppn.aAU = aAU;
                oppn.iDegs = iDegs;
                oppn.omegaDegs = omegaDegs;
                oppn.periArgDegs = periArgDegs;
                oppn.epochJD = epochJD;
                oppn._MDegs = _MDegs;
                oppn._G = _G;
                oppn._H = _H;
                return oppn;
              }
            }
            catch (WrongRowNumberException ex)
            {

            }
          }
        }
      }
      catch (NumberFormatException | DatatypeConfigurationException ex)
      {
        System.out.println ("Invalid " + fieldId + " for " + id);
      }
    }

    return null;
  } // suitableOpposition

  private static final DecimalFormat DF1 = new DecimalFormat ("0.0");
  private static final DecimalFormat DF2 = new DecimalFormat ("0.00");
  private static final DecimalFormat DF4 = new DecimalFormat ("0.0000");
  private static final SimpleDateFormat YYYYMMDDHH =
          new SimpleDateFormat ("yyyy-MMM-dd HH");

  private JulianDate findOpposition (Orbit orbit)
  {
    double prevDiffDegs = 0;
    int nDays = NDAYS;

    // Ensure we always have the first 10 asteroids in our list:
    {
      String asteroidId = orbit.getName ().trim ();
      int iSpace = asteroidId.indexOf (" ");
      int asteroidNumber = Integer.parseInt (asteroidId.substring (0, iSpace));

      if (asteroidNumber <= 10) { nDays = NDAYS * 8; }
    }

    for (int i = 0; i < nDays; i++)
    {
      double jd = START_JD + i;
      XYZ earthXYZ = EARTH_XYZS [i];
      Angle earthLongitude =
              new Angle (earthXYZ.getLongitudeRadians (), Angle.Units.RADIANS);
      XYZ objXYZ = orbit.getHeliocentricPositionAU (new JulianDate (jd));
      Angle objLongitude =
              new Angle (objXYZ.getLongitudeRadians (), Angle.Units.RADIANS);
      double diffDegs = earthLongitude.difference (objLongitude).getDegrees ();

      if (prevDiffDegs < 0)
      {
        if (diffDegs > 0 && diffDegs < 5)
        {
          double interpolatedJD = jd - 1 - prevDiffDegs / (-prevDiffDegs + diffDegs);
          return new JulianDate (interpolatedJD);
        }
      }
      else if (prevDiffDegs > 0)
      {
        if (diffDegs > -5 && diffDegs <= 0)
        {
          double interpolatedJD = jd - prevDiffDegs / (prevDiffDegs - diffDegs);
          return new JulianDate (interpolatedJD);
        }
      }

      prevDiffDegs = diffDegs;
    }

    return null;
  } // findOpposition

  private String removeParentheses (String id)
  {
    StringBuilder sb = new StringBuilder ();

    for (int i = 0; i < id.length (); i++)
    {
      char ch = id.charAt (i);

      if (ch != '(' && ch != ')')
      {
        sb.append (ch);
      }
    }

    return sb.toString ();
  } // removeParentheses

  private String spacesToUnderscores (String s)
  {
    StringBuilder sb = new StringBuilder ();

    for (int i = 0; i < s.length (); i++)
    {
      char ch = s.charAt (i);

      if (ch == ' ')
      {
        sb.append ('_');
      }
      else
      {
        sb.append (ch);
      }
    }

    return sb.toString ();
  } // spacesToUnderscores

} // ElementUpdater
