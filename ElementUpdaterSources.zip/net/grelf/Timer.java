package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** For logging the time taken for any process to run.
	* NB: The starting time is when the Timer object itself is constructed. */
public class Timer
{
	private long startTime;
	private String opName;
	private java.awt.image.BufferedImage bim;

	/** Create a Timer, recording the start time. aBim may be null. */
	public Timer (String anOpName, java.awt.image.BufferedImage aBim)
	{
		opName = anOpName;
		bim = aBim;
		startTime = System.nanoTime ();
	} // Timer

	/** Stop the timer and log the operation name, image size and duration (since the Timer was constructed). */
	public void stop ()
	{
		long duration = System.nanoTime () - startTime;
		StringBuffer log = new StringBuffer (opName + " (");

		if (null != bim)
		{
			log.append (bim.getWidth ());
      log.append ("x");
      log.append (bim.getHeight ());
      log.append ("x");
      log.append (bim.getSampleModel ().getNumBands ());
			log.append ("x");
      log.append (bim.getSampleModel ().getSampleSize (0));
		}

		log.append (") took ");
    log.append (duration / 1.0E9);
    log.append (" s.");
		net.grelf.Util.logInfo (log.toString ());
	} // stop

} // Timer_
