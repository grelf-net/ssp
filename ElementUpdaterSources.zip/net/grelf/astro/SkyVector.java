package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Represents a vector on the celestial sphere, eg between two SkyPoints. */
public class SkyVector implements Cloneable, java.io.Serializable
{
	/** Get spherical separation. */
  public net.grelf.Angle getSeparation () { return this.separation; }
  private net.grelf.Angle separation;

  /** Get position angle (anticlockwise from north). */
  public net.grelf.Angle getPa () { return this.pa; }
	private net.grelf.Angle pa;

	/** Get spherical separation in degrees.<br>
   * Deprecated: instead use getSeparation ().getDegrees (). */
  @Deprecated
  public double getSeparationDegs () { return this.separation.getDegrees (); }
	
	/** Get position angle in degrees (anticlockwise from north).<br>
   * Deprecated: instead use getPa ().getDegrees (). */
  @Deprecated
	public double getPaDegs () { return this.pa.getDegrees (); }

	/** The order of the parameters is like polar coordinates (r, theta). If separation is negative
	 * the sign is removed and 180 added to PA. PA is then converted, if necessary, to lie in range
	 * 0..360. */
	public SkyVector (double separationDegs, double paDegs)
	{
		if (separationDegs < 0)
		{
/****
			net.grelf.grip.GRIP.getLogger ().info ("SkyVector.sep < 0");
****/
			separationDegs = - separationDegs;
			paDegs = net.grelf.Maths.in360 (paDegs + 180.0);
		}

    this.separation = new net.grelf.Angle (separationDegs, net.grelf.Angle.Units.DEGREES);
		this.pa = new net.grelf.Angle (paDegs, net.grelf.Angle.Units.DEGREES);
	} // SkyVector

	/** The order of the parameters is like polar coordinates (r, theta). If separation is negative
	 * the sign is removed and 180 added to PA. PA is then converted, if necessary, to lie in range
	 * 0..360. */
	public SkyVector (net.grelf.Angle separation, net.grelf.Angle pa)
	{
		this.separation = separation;
		this.pa = pa;

		if (this.separation.getRadians () < 0)
		{
/****
			net.grelf.grip.GRIP.getLogger ().info ("SkyVector.sep < 0");
****/
			this.separation = new net.grelf.Angle (- this.separation.getRadians (),
              this.separation.getStdErrRadians (), net.grelf.Angle.Units.RADIANS);
      this.pa = new net.grelf.Angle (this.pa.getDegrees () + 180.0,
              this.pa.getStdErrDegrees (), net.grelf.Angle.Units.DEGREES).in360 ();
		}
	} // SkyVector

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		SkyVector otherVector = (SkyVector) other;

    if (!this.pa.equals (otherVector.pa)) return false;
    if (!this.separation.equals (otherVector.separation)) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) (this.pa.hashCode () * 37  + this.separation.hashCode () * 11);
	} // hashCode

	@Override
	public SkyVector clone ()
	{
		return new SkyVector (this.pa, this.separation);
	} // clone

	@Override
	public String toString ()
	{
		return ("PA " + this.pa.toString () + ", separation " + this.separation.toString ());
	} // toString

  public String toString (net.grelf.Angle.Units units)
	{
		return ("PA " + this.pa.toString (units) + ", separation " + this.separation.toString (units));
	} // toString

} // SkyVector