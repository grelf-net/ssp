package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** This class holds a Julian date/time to an accuracy of 1ms.
	* The Julian date is measured as the number of days since mean NOON on Jan 1st, 4713 BC, UT. It is useful
  * in astronomy because it provides a continuous time axis in units of days without calendar and time zone
  * complications. Graphing variable star magnitudes is particularly usefully done against this scale.
	* Noon on 2010 Jan 1 is JD 2455198.0. Time in Java is based on 1970.0 UT which was JD 2440587.5. */
public class JulianDate implements Cloneable, java.io.Serializable
{
  private double jd;
	
	/** 1970.0 UT was JD 2440587.5 */
	private static final double JD1970_DAYS = 2440587.5;
	private static final double SECS_PER_DAY = 24.0 * 60.0 * 60.0;

  /** Commonly used epoch for star charts, J2000.0, based on Julian years. */
	public static final double J2000 = 2451545.0;
  /** Previously commonly used epoch for star charts, B1950.0, based on Besselian years. */
	public static final double B1950 = 2433282.4235;
	
	/** Construct from a numerical JD value. */
	public JulianDate (double jd)
	{
    this.jd = jd;
	} // JulianDate

	/** Construct from the Java time in milliseconds since 1970.0 UT */
	public JulianDate (long msSince1970)
	{
		double javaSecs = msSince1970 / 1000.0;
		this.jd = JD1970_DAYS + javaSecs / SECS_PER_DAY;
	} // JulianDate

  /** Convert to milliseconds since 1970.0 UT, as used in Java and other programming systems. */
  public long toMsSince1970 ()
  {
    double javaMs = (this.jd - JD1970_DAYS) * SECS_PER_DAY * 1000.0;
    return (long) javaMs;
  } // toMsSince1970

	/** Construct from a Java calendar object (which already includes locale and time zone). */
	public JulianDate (java.util.Calendar dateTime)
	{
		this (dateTime.getTimeInMillis ()); // Since 1970.0 UT - no time zone conversion needed
	} // JulianDate

	public java.util.GregorianCalendar toGregorianCalendar ()
	{
		double jd1970 = this.jd - JD1970_DAYS;
		long javaTime = (long) (jd1970 * SECS_PER_DAY * 1000.0); // ms, UT
		
		java.util.GregorianCalendar calendar = new java.util.GregorianCalendar ();
		// Uses default locale - no time zone conversion needed

		calendar.setTimeInMillis (javaTime);
		return calendar;
	} // toGregorianCalendar

	/** Get the JD now (system time) - uses default locale so no time zone conversion should be needed. */
	public JulianDate ()
	{
		this (new java.util.GregorianCalendar ());
		// Uses default locale - no time zone conversion needed
	} // JulianDate
	
	/** Construct from a xsd:DateTime value, as defined by W3C XML schema (eg, 2009-12-31T23:59:59.9+00:00). */
	public JulianDate (String xmlDateTime) 
	throws javax.xml.datatype.DatatypeConfigurationException
	{
			this (javax.xml.datatype.DatatypeFactory.newInstance ().newXMLGregorianCalendar (xmlDateTime));
	} // JulianDate

	/** Use this instead of constructor if the xmlDateTime may not be in W3C schema style.
	 * Image metadata in particular could be yyyy:mm:dd hh:mm:ss. */
	public static JulianDate createJulianDate (String xmlDateTime)
	{
		try
		{
			return new JulianDate (xmlDateTime);
		}
		catch (javax.xml.datatype.DatatypeConfigurationException ex)
		{
			return createJulianDateNonW3C (xmlDateTime);
		}
		catch (IllegalArgumentException ex)
		{
			return createJulianDateNonW3C (xmlDateTime);
		}
	} // createJulianDate

	/** Assuming the dateTime is in the format yyyy:mm:dd:hh:mm:ss, where colon represents any
	  * separator character, and getting the time zone offset from net.grelf.grip.Config. */
	private static JulianDate createJulianDateNonW3C (String dateTime)
	{
		try
		{
			double timeZoneOffsetHours = 0.0;
/*
			String tzS = net.grelf.grip.Config.getValue ("TimeZone.value");

			if (null != tzS)
			{
				timeZoneOffsetHours = Double.parseDouble (tzS);
			}
			else
 * 
 */
			{
				final double MS_PER_HOUR = 1000.0 * 60.0 * 60.0;
				int tzOffset_ms = java.util.TimeZone.getDefault ().getRawOffset (); // Not allowing for daylight saving
				timeZoneOffsetHours = tzOffset_ms / MS_PER_HOUR;
			}

			int tzH = (int) Math.floor (timeZoneOffsetHours);
			int tzM = (int) Math.floor ((timeZoneOffsetHours - tzH) * 60.0);
			return new JulianDate (new java.util.GregorianCalendar (
							Integer.parseInt (dateTime.substring (0, 4)),
							Integer.parseInt (dateTime.substring (5, 7)) - 1,
							Integer.parseInt (dateTime.substring (8, 10)),
							Integer.parseInt (dateTime.substring (11, 13)) + tzH,
							Integer.parseInt (dateTime.substring (14, 16)) + tzM,
							Integer.parseInt (dateTime.substring (17))
							));
		}
		catch (NumberFormatException ex)
		{
			net.grelf.Util.logWarning ("NumberFormatException in createJulianDateNonW3C");
			return null;
		}
	} // createJulianDateNonW3C
	
	/** Construct from standard Java representation of a W3C xs:dateTime. */
	public JulianDate (javax.xml.datatype.XMLGregorianCalendar xmlCalendar)
	{
		this (xmlCalendar.toGregorianCalendar ());
	} // JulianDate

	private static final java.text.DecimalFormat DF5 = new java.text.DecimalFormat ("0.00000");
	@Override
	public String toString ()
	{
		return DF5.format (this.toDouble ());
	} // toString

	/** Get the numerical JD. */
	public double toDouble ()
	{
    return this.jd;
	} // toDouble

	/** Get the date/time in the format yyyy:MM:dd HH:mm:ss */
	public String toImageTimestampFormat ()
	{
		java.text.DateFormat df = new java.text.SimpleDateFormat ("yyyy:MM:dd HH:mm:ss");
		return df.format (this.toGregorianCalendar ().getTime ());
	} // toImageTimestampFormat

	/** Returns dateTime in W3C schema format. If DatatypeConfigurationException occurs, logs the fact
		* and returns an empty string. */
	public String toXmlDateTime ()
	{
		try
		{
			java.util.GregorianCalendar calendar = this.toGregorianCalendar ();
			javax.xml.datatype.XMLGregorianCalendar xmlCalendar =
												javax.xml.datatype.DatatypeFactory.newInstance ().newXMLGregorianCalendar (calendar);
			return xmlCalendar.toXMLFormat ();
		}
		catch (javax.xml.datatype.DatatypeConfigurationException ex)
		{
			net.grelf.Util.logWarning (
              "DatatypeConfigurationException when converting Julian Date {0} to xs:dateTime", this.toString ());
			return ("");
		}
	} // toXmlDateTime

  /** Uses method given in J.Meeus "Astronomical Algorithms" (2nd Edn) Chapter 12. */
  public double toMeanSiderealTimeAtGreenwichInDegrees ()
  {
    double dJD = this.jd - J2000;
    double _T = dJD / 36525;
    double _Tsq = _T * _T;
    return net.grelf.Maths.in360 (
            280.46061837 + 360.98564736629 * dJD + 0.000387933 * _Tsq - (_T * _Tsq) / 38710000.0);
  } // toMeanSiderealTimeAtGreenwichInDegrees

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;

		if (!this.getClass ().equals (other.getClass ())) return false;

		JulianDate otherJD = (JulianDate) other;

    return (this.jd == otherJD.jd);
	} // equals

	/** Enables JulianDate objects to be used as hash keys. */
	@Override
	public int hashCode ()
	{
    return (int) (this.jd * 123456.789);
	} // hashCode

	@Override
	public JulianDate clone ()
	{
		return new JulianDate (this.jd);
	} // clone

} // JulianDate
