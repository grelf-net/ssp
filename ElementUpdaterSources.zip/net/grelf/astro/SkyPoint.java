package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Representing a celestial position by equatorial coordinates (RA and Dec) for a given Epoch. */
public class SkyPoint implements Cloneable, java.io.Serializable
{
	public RA getRA () { return this.ra; }
	private RA ra;

	public Dec getDec () { return this.dec; }
	private Dec dec;

  /** Deprecated: name changed to getEquinox. */
  @Deprecated
	public Epoch getEpoch () { return this.equinox; }
	public Epoch getEquinox () { return this.equinox; }
	private Epoch equinox;

	/** Equatorial coordinates for unit radius, held to avoid computing them more than once. */
	protected double x, y, z;

	private static final double EPSILON = 1.0E-7;

	public SkyPoint (RA ra, Dec dec, Epoch equinox)
	{
		this.ra = ra;
		this.dec = dec;
		this.equinox = equinox;
		computeXYZ ();
	} // SkyPoint

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		SkyPoint otherPt = (SkyPoint) other;
		if (!otherPt.ra.equals (this.ra)) return false;
		if (!otherPt.dec.equals (this.dec)) return false;
		if (!otherPt.equinox.equals (this.equinox)) return false;
		if (Math.abs (otherPt.x - this.x) > EPSILON) return false;
		if (Math.abs (otherPt.y - this.y) > EPSILON) return false;
		if (Math.abs (otherPt.z - this.z) > EPSILON) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return this.ra.hashCode () * 17  + this.dec.hashCode () * 41 + this.equinox.hashCode () * 83;
	} // hashCode

	@Override
	public SkyPoint clone ()
	{
		return new SkyPoint (this.ra.clone (), this.dec.clone (), this.equinox.clone ());
	} // clone

	private void computeXYZ ()
	{
    double cosDec = this.dec.cos ();
    this.x = this.ra.cos () * cosDec;
    this.y = this.ra.sin () * cosDec;
    this.z = this.dec.sin ();
	} // computeXYZ

  /** Deprecated: name changed to changeEquinoxLowAccuracy. */
  @Deprecated
	public void changeEpochLowAccuracy (Epoch newEpoch)
	{
    changeEquinoxLowAccuracy (newEpoch);
  } // changeEpochLowAccuracy

	/** This adjusts the fields of the current object to the given new equinox, low accuracy version.
		* Uses the approximate formulae:<br>
		* Annual precession in RA = 3.0730 + 1.3362.sin(RA).tan(Dec) seconds of time<br>
		* Annual precession in Dec = 20.043.cos(RA) seconds of arc. */
	public void changeEquinoxLowAccuracy (Epoch newEquinox)
	{
		float dY = newEquinox.getYear () - this.equinox.getYear ();

		if (0.0001F > Math.abs (dY)) return;

    double dRaSecs = dY * (3.0730 + 1.3362 * this.ra.sin () * this.dec.tan ());
		RA newRA = new RA (this.ra.toHours (), 0.0, dRaSecs);
		double dDecSecs = dY * 20.043 * this.ra.cos ();
		Dec newDec = new Dec (this.dec.toDegrees () + dDecSecs / 3600.0);

    this.ra = newRA;
		this.dec = newDec;
		this.equinox = newEquinox;
		computeXYZ ();
	} // changeEpochLowAccuracy

	private static final double ARCSECS_TO_DEGS = 1.0 / 3600.0;

  /** Deprecated: name changed to changeEquinox. */
  @Deprecated
 	public void changeEpoch (Epoch newEquinox)
  {
    changeEquinox (newEquinox);
  } // changeEpoch

	/** This adjusts the fields of the current object to the given new epoch, high accuracy version.
		* Uses the method given in Astronomical Algorithms by Jean Meeus (2nd edition, corrected Aug 09),
		* Chapter 21 (Precession), the section headed "Rigorous method". */
	public void changeEquinox (Epoch newEquinox)
	{
		double jd0 = this.equinox.getJulianDate ().toDouble ();
		double jd = newEquinox.getJulianDate ().toDouble ();
		double _T = (jd0 - 2451545.0) / 36525.0;
		double t = (jd - jd0) / 36525.0;
		double _T2 = _T * _T;
		double t2 = t * t;
		double t3 = t2 * t;
		net.grelf.Angle zeta = new net.grelf.Angle (((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
						           (0.30188 - 0.000344 * _T) * t2 + 0.017998 * t3) * ARCSECS_TO_DEGS,
                       net.grelf.Angle.Units.DEGREES);
		net.grelf.Angle zed = new net.grelf.Angle (((2306.2181 + 1.39656 * _T - 0.000139 * _T2) * t +
						        (1.09468 + 0.000066 * _T) * t2 + 0.018203 * t3) * ARCSECS_TO_DEGS,
                    net.grelf.Angle.Units.DEGREES);
		net.grelf.Angle theta = new net.grelf.Angle (((2004.3109 - 0.85330 * _T - 0.000217 * _T2) * t -
						            (0.42665 + 0.000217 * _T) * t2 - 0.041833 * t3) * ARCSECS_TO_DEGS,
                        net.grelf.Angle.Units.DEGREES);
		RA ra0 = this.ra;
		Dec dec0 = this.dec;
		double cosDec0 = dec0.cos ();
		double sinDec0 = dec0.sin ();
		net.grelf.Angle ra0PlusZeta = ra0.add (zeta).in360 ();
		double cosDaz = cosDec0 * ra0PlusZeta.cos ();
		double cosTheta = theta.cos ();
		double sinTheta = theta.sin ();
		double _A = cosDec0 * ra0PlusZeta.sin ();
		double _B = cosTheta * cosDaz - sinTheta * sinDec0;
		double _C = sinTheta * cosDaz + cosTheta * sinDec0;
    this.ra = new RA (zed.add (net.grelf.Angle.atan2 (_A, _B)).in360 ());
    double dec0Degs = dec0.toDegrees ();
		
		if (dec0Degs > -85.0 && dec0Degs < 85.0)
		{
      this.dec = new Dec (net.grelf.Angle.asin (_C));
		}
		else // Near a pole:
		{
      this.dec = new Dec (net.grelf.Angle.acos (StrictMath.sqrt (_A * _A + _B * _B)));
		}

		this.equinox = newEquinox;
		computeXYZ ();
	} // changeEquinox

	/** Calculate position angle (PA) and spherical separation from this to another SkyPoint.
		* If the other SkyPoint is for a different equinox it is first precessed to the equinox of this point.<br>
		* Method is as given in Chapter 17 of Astronomical Algorithms by Jan Meeus, the algorithm supplied
    * by Thierry Pauwels. */
	public SkyVector calculateSeparation (SkyPoint other)
	{
		if (!other.equinox.equals (this.equinox))
		{
			other.changeEquinox (this.equinox);
		}

    net.grelf.Angle dRA = this.ra.clone ().subtract (other.ra);
    double cosD1 = other.dec.cos ();
    double cosD2 = this.dec.cos ();
		double cosDa = dRA.cos ();
		double sinD1 = other.dec.sin ();
		double sinD2 = this.dec.sin ();
		double sinDa = dRA.sin ();
		double xx = cosD1 * sinD2 - sinD1 * cosD2 * cosDa;
		double yy = cosD2 * sinDa;
		double zz = sinD1 * sinD2 + cosD1 * cosD2 * cosDa;
		net.grelf.Angle separation = net.grelf.Angle.atan2 (StrictMath.sqrt (xx * xx + yy * yy), zz);
		net.grelf.Angle pa = net.grelf.Angle.atan2 (-sinDa, cosD2 * sinD1 / cosD1 - sinD2 * cosDa).in360 ();
		return new SkyVector (separation, pa);
	} // calculateSeparation

	@Override
	public String toString ()
	{
    StringBuffer sb = new StringBuffer ();
    sb.append ("RA ");
    sb.append (this.ra.toString ());
    sb.append (" Dec ");
    sb.append (this.dec.toString ());
    sb.append (" (");
    sb.append (this.equinox.toString ());
    sb.append (")");
    return sb.toString ();
	} // toString

	/** Return <RA><Dec><Epoch> elements. */
	public StringBuffer toXML ()
	{
		StringBuffer sb = new StringBuffer ();
		sb.append ("<RA>");
    sb.append (this.getRA ().toString ());
    sb.append ("</RA><Dec>");
    sb.append (this.getDec ().toString ());
    sb.append ("</Dec><Epoch>");
    sb.append (this.getEquinox ().toString ());
    sb.append ("</Epoch>");
		return sb;
	} // toXML

  /** Returns an array of 3 fractions of a day, representing respectively the local times of rising, transit and
    * setting for the given latitude and refraction offset (h0 = -0.5667 for stars and planets, -0.8333 for the
    * Sun, +0.125 for the Moon). Uses the method in J.Meeus "Astronomical Algorithms" (2nd Edn), Chapter 15.
    * The JD for which these are required is NOT assumed to be for 0h UT - any JD is adjusted as necessary.
    * The rising and setting times are set to -1.0 if the point is circumpolar at the given latitude. */
  public double [] calculateRiseTransitSet (JulianDate jd, BodyKind kind, net.grelf.Angle latitude)
  {
    double jd0 = StrictMath.round (jd.toDouble ()) + 0.5; // 0.5 converts to 0h UT
    double theta0Degs = new JulianDate (jd0).toMeanSiderealTimeAtGreenwichInDegrees ();
    double h0Degs = -0.5667;

    switch (kind)
    {
      case SUN:  h0Degs = -0.8333; break;
      case MOON: h0Degs = +0.125;  break;
      default: h0Degs = -0.5667;
    }

    net.grelf.Angle h0 = new net.grelf.Angle (h0Degs, net.grelf.Angle.Units.DEGREES);

    net.grelf.Angle delta = this.getDec ();
    double sinPhiSinDelta = latitude.sin () * delta.sin ();
    net.grelf.Angle _H0 = net.grelf.Angle.acos ((h0.sin () - sinPhiSinDelta) / latitude.cos () * delta.cos ());
    double m0 = (this.getRA ().toDegrees () - theta0Degs) / 360.0;
    double m1, m2;

    if (sinPhiSinDelta < -1.0 || sinPhiSinDelta > 1.0)
    {
      m1 = m2 = -1.0;
    }
    else
    {
      double _H0360 = _H0.getDegrees () / 360.0;
      m1 = in01 (m0 - _H0360);
      m2 = in01 (m0 + _H0360);
    }

    double [] dayFractions = new double [3];

    dayFractions [0] = m1;
    dayFractions [1] = in01 (m0);
    dayFractions [2] = m2;
    return dayFractions;
  } // calculateRiseTransitSet

  private double in01 (double x)
  {
    if (x > 1.0) return x - 1.0;

    if (x < 0.0) return x + 1.0;

    return x;
  } // in01

} // SkyPoint