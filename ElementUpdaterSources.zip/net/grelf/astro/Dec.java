package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Representation of declination (celestial latitude). */
public class Dec extends net.grelf.Angle implements Cloneable, java.io.Serializable
{
	/** Range -90..+90 */
	public byte getDegree ()
	{
    byte deg = (byte) StrictMath.floor (getDegrees ());

    if (deg < 0) deg++;

    return deg;
	} // getDegree

	/** Range -59..59 */
	public byte getMinute ()
	{
		double totalMins = getDegrees () * 60.0;
		int wholeMins = (int) Math.floor (totalMins);

    if (wholeMins < 0) wholeMins++;
    
    return (byte) (wholeMins % 60);
	} // getMinute

	/** Range -59.99999..59.99999 */
	public float getSecond ()
	{
    double degs = getDegrees ();
		double totalMins = Math.abs (degs * 60.0);
		double wholeMins = Math.floor (totalMins);
    double minFrac = totalMins - wholeMins;
    float secs = (float) minFrac * 60.0F;
    return (degs < 0.0) ? -secs : secs;
	} // getSecond

	private static final java.text.DecimalFormat DF1 = new java.text.DecimalFormat ("0");
	private static final java.text.DecimalFormat DF2 = new java.text.DecimalFormat ("00");
	private static final java.text.DecimalFormat DF2_1 = new java.text.DecimalFormat ("00.0");

	/** Can pass in fractional degrees or minutes but will be held in normalised form with integer degrees and minutes
		* plus fractional seconds.<br>
		* 10.2.1 Important change: previously the degrees part could be negative but min and sec were expected to
		* be positive (as from a user dialogue). BUT that will not work if the degrees part is zero. So...<br>
		* VERY IMPORTANT: If the declination is negative every field in this constructor must be negative.
		* Note that in a user dialogue (eg, in net.grelf.astro.StarChart) it can be different because each text
		* field holds a String rather than a number so the sign is detectable on "-0". */
	public Dec (double degrees, double mins, double secs, double sigmaDegrees)
	{
    super (degrees + mins / 60.0 + secs / 3600.0, sigmaDegrees, net.grelf.Angle.Units.DEGREES);
  } // Dec

	/** Can pass in fractional degrees or minutes but will be held in normalised form with integer degrees and minutes
		* plus fractional seconds.<br>
		* 10.2.1 Important change: previously the degrees part could be negative but min and sec were expected to
		* be positive (as from a user dialogue). BUT that will not work if the degrees part is zero. So...<br>
		* VERY IMPORTANT: If the declination is negative every field in this constructor must be negative.
		* Note that in a user dialogue (eg, in net.grelf.astro.StarChart) it can be different because each text
		* field holds a String rather than a number so the sign is detectable on "-0". */
	public Dec (double degrees, double mins, double secs)
	{
    this (degrees, mins, secs, 0.0);
	} // Dec

	public Dec (double degrees, double sigmaDegrees)
	{
    super (degrees, sigmaDegrees, net.grelf.Angle.Units.DEGREES);
	} // Dec

	public Dec (double degrees)
	{
		this (degrees, 0.0, 0.0);
	} // Dec

  public Dec (net.grelf.Angle angle)
  {
    this (angle.getDegrees (), angle.getStdErrDegrees ());
  } // Dec

	public double toDegrees ()
	{
    return getDegrees ();
	} // toDegrees

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		Dec otherDec = (Dec) other;

    return this.valueRadians.equals (otherDec.valueRadians); // Using MeasuredValue.equals ()
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
    return super.hashCode ();
	} // hashCode

	@Override
	public Dec clone ()
	{
    return new Dec (this);
	} // clone

	@Override
	public String toString ()
	{
    String sign = getDegrees () > 0.0 ? "+" : "-";
		return sign + DF2.format (Math.abs (this.getDegree ())) + "d" +
            DF2.format (Math.abs (this.getMinute ())) + "m" +
		        DF2_1.format (Math.abs (this.getSecond ())) + "s";
  } // toString

} // Dec