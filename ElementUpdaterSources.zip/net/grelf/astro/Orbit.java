package net.grelf.astro;

/** Representing a Newtonian elliptical orbit around the sun. Calculation units are solar mass, a.u., days.
 * There are several different ways of defining an orbit by specifying different sets of 6 orbital elements,
 * each of which will be a value of type double. So rather than get into defining a number of new types to
 * be able to have many overloaded constructors, an orbit is created like this:
 * <pre>
Orbit earth = new Orbit (Orbit.Kind.PLANET)
		.name ("Earth")
    .symbol ("E")
		.colour (java.awt.Color.green)
		.epoch (JulianDate.J2000)
		.piDegs (103.075)
	  .omegaDegs (0)
	  .iDegs (0)
	  .e (0.01671)
	  .qAU (0.9833)
	  .tauDays (2008, 1, 2);
 * </pre>
 * All of the determiner methods return a reference to this orbit, so they can be chained like that.
 * The first 3 determiners shown here are optional, for use when displaying the orbit.
 * aAU () may be given instead of qAU (). meanLongDegs () or meanAnomalyDegs () may be used instead of
 * tauDays ().
 * To check that enough elements have been given, then call isSet (). If that returns true it is OK to go
 * on and use the orbit in calculations.
 * @author Graham Relf - www.grelf.net
 * Copyright (c) Graham Relf, UK, 2010
 */
public class Orbit
{
	/**  Gaussian gravitational constant (radians). */
	public static final double K = 0.01720209895;

	/**  G x mass of sun - assume other masses are negligible. */
	private static final double MU = K * K;

	public static enum Kind { SUN, MOON, PLANET, ASTEROID, COMET, CONSTELLATION, GENERAL , STATIC };
	private Kind kind;
	public Kind getKind () { return this.kind; }


	public Orbit (Kind kind)
	{
		this.kind = kind;
	} // Orbit

	private double _H;
	/** Absolute magnitude (at 1 au). */
	public double getH () { return this._H; }
	public Orbit _H (double _H)
	{
		this._H = _H;
		return this;
	}

	private double _G;
	/** Absolute magnitude slope parameter. */
	public double getG () { return this._G; }
	public Orbit _G (double _G)
	{
		this._G = _G;
		return this;
	}

	private String name = "[no name]";
	private boolean nameIsSet = false;
	public Orbit name (String name)
	{
		this.name = name;
		this.nameIsSet = true;
		return this;
	}
	public String getName () { return this.name; }

	private java.awt.Color colour = java.awt.Color.BLACK;
	public Orbit colour (java.awt.Color colour) 
	{
		this.colour = colour;
		return this;
	}
	public java.awt.Color getColour () { return this.colour; }

	private String symbol = "+";
	public Orbit symbol (String symbol)
	{
		this.symbol = symbol;
		return this;
	}
	public String getSymbol () { return this.symbol; }

	private double epochJD;
	private boolean epochIsSet = false;
	/** Set epoch of the elements.*/
	public Orbit epoch (double epochJD)
	{
		this.epochJD = epochJD;
		this.epochIsSet = true;
		return this;
	}
  public double getEpochJD () { return this.epochJD; }

	private double omegaDegs;
	private double cosOmega; // Do not compute on every time step.
	private double sinOmega; // Do not compute on every time step.
	private boolean omegaIsSet = false;
	/** Set longitude of the ascending node (in degrees). */
	public Orbit omegaDegs (double omegaDegs)
	{
		this.omegaDegs = omegaDegs;
		this.cosOmega = net.grelf.Maths.cosDegs (this.omegaDegs);
		this.sinOmega = net.grelf.Maths.sinDegs (this.omegaDegs);
		this.omegaIsSet = true;
		return this;
	}
	/** Get longitude of the ascending node (in degrees). */
	public double getOmegaDegs () { return this.omegaDegs; }

	private double periLongDegs;
	private double wRad; // Do not compute on every time step.
	private boolean periLongIsSet = false;
	private boolean wIsSet = false;
	/** Set longitude of perihelion (in degrees). */
	public Orbit periLongDegs (double piDegs)
	{
		this.periLongDegs = piDegs;
		this.periLongIsSet = true;
    this.wIsSet = false;
    this.allIsSet = false;
		return this;
	}
	/** Get longitude of perihelion (in degrees). */
	public double getPeriLongDegs () { return this.periLongDegs; }
	/** Set argument of perihelion (in degrees). */
	public Orbit wDegs (double w)
	{
		this.wRad = StrictMath.toRadians (w);
		this.wIsSet = true;
    this.periLongIsSet = false;
    this.allIsSet = false;
		return this;
	}
  public double getPeriArgDegs () { return StrictMath.toDegrees (wRad); }

	private double iDegs;
	private double cosI; // Do not compute on every time step.
	private double sinI; // Do not compute on every time step.
	private boolean iIsSet = false;
	/** Set orbital inclination to the ecliptic (in degrees). */
	public Orbit iDegs (double iDegs)
	{
		this.iDegs = iDegs;
		this.cosI = net.grelf.Maths.cosDegs (this.iDegs);
		this.sinI = net.grelf.Maths.sinDegs (this.iDegs);
		this.iIsSet = true;
		return this;
	}
	/** Get orbital inclination to the ecliptic (in degrees). */
	public double getIDegs () { return this.iDegs; }

	private double e;
	private double sqrt1_ee; // Do not compute on every time step.
	private boolean eIsSet = false;
	/** Set orbital eccentricity. */
	public Orbit e (double e) 
	{
		this.e = e;
		this.sqrt1_ee = StrictMath.sqrt (1.0 - this.e * this.e);
		this.eIsSet = true;
		return this;
	}
	/** Get orbital eccentricity. */
	public double getE () { return this.e; }

	private double qAU;
	private double aAU; // Do not need to compute at every time step
  double nRadPerDay; // Do not need to compute at every time step
	private boolean qIsSet = false;
	private boolean aIsSet = false;
	private boolean nIsSet = false;
	/** Set perihelion distance (in a.u.). Also sets a = q / (1 - e) so must be used after e (). */
	public Orbit qAU (double qAU)
	{
		this.qAU = qAU;
		this.qIsSet = true;
    this.aIsSet = false;
    this.nIsSet = false;
    this.allIsSet = false;
		return this;
	}
	/** Get perihelion distance (in a.u.). */
	public double getQAU () { return this.qAU; }

	/** Set semi-major axis of orbit. */
	public Orbit aAU (double aAU)
	{
		this.aAU = aAU;
		this.aIsSet = true;
    this.qIsSet = false;
    this.nIsSet = false;
    this.allIsSet = false;
		return this;
	}
	/** Get semi-major axis of orbit. */
	public double getAAU () { return this.aAU; }
	/** Set mean daily motion. */
	public Orbit nDegsPerDay (double n)
	{
		this.nRadPerDay = StrictMath.toRadians (n);
		this.nIsSet = true;
    this.qIsSet = false;
    this.aIsSet = false;
    this.allIsSet = false;
		return this;
	}
  public double getNDegsPerDay () { return StrictMath.toDegrees (nRadPerDay); }

	private JulianDate tauJD;
	private double meanLongDegs;
	private double meanAnomalyDegs;
	private boolean tauIsSet = false;
	private boolean meanLongIsSet = false;
	private boolean meanAnomalyIsSet = false;
	/** Set perihelion date/time. Must be set after piDegs and q (or a). */
	public Orbit tauDays (int year, int month, double day)
	{
		int wholeDays = (int) Math.floor (day);
		int sec = (int) Math.round ((day - wholeDays) * 86400);
		int hour = sec / 3600;
		sec -= hour * 3600;
		int min = sec / 60;
		sec -= min * 60;
		this.tauJD = new JulianDate (new java.util.GregorianCalendar (year, month - 1, wholeDays, hour, min, sec));
		tauIsSet = true;
    meanLongIsSet = false;
    meanAnomalyIsSet = false;
    allIsSet = false;
		return this;
	}
	/** Set perihelion date/time. Must be set after piDegs and q (or a). */
	public Orbit tauDays (JulianDate jd)
	{
		this.tauJD = jd;
		tauIsSet = true;
		tauIsSet = true;
    meanLongIsSet = false;
    meanAnomalyIsSet = false;
    allIsSet = false;
		return this;
	}
	/** Get perihelion date/time. */
	public JulianDate getTauDays () { return this.tauJD; }

	/** Set mean longitude at the epoch (in degrees). Must be set after piDegs and q (or a). */
	public Orbit meanLongDegs (double _LDegs)
	{
		this.meanLongDegs = _LDegs;
		this.meanLongIsSet = true;
		tauIsSet = false;
    meanAnomalyIsSet = false;
    allIsSet = false;
		return this;
	}
	/** Get mean longitude at the epoch (in degrees). */
	public double getMeanLongDegs ()
	{
		return this.meanLongDegs;
	}

	/** Set mean anomaly at the epoch (in degrees). Must be set after piDegs and q (or a). */
	public Orbit meanAnomalyDegs (double _MDegs)
	{
		this.meanAnomalyDegs = _MDegs;
		this.meanAnomalyIsSet = true;
		tauIsSet = false;
    meanLongIsSet = false;
    allIsSet = false;
		return this;
	}
	/** Get mean anomaly at the epoch (in degrees). */
	public double getMeanAnomalyDegs ()
	{
		return this.meanAnomalyDegs;
	}

	private void setLAndMfromTau ()
	{
		this.meanAnomalyDegs = net.grelf.Maths.in360 (
						StrictMath.toDegrees (this.nRadPerDay * (this.epochJD - this.tauJD.toDouble ())));
		this.meanLongDegs = net.grelf.Maths.in360 (this.periLongDegs + this.meanAnomalyDegs);
	} // setLAndMfromTau

	private void setTauAndMFromL ()
	{
		this.meanAnomalyDegs = net.grelf.Maths.in360 (this.meanLongDegs - this.periLongDegs);
		double tau = this.epochJD - StrictMath.toRadians (this.meanAnomalyDegs) / this.nRadPerDay;
		this.tauJD = new JulianDate (tau);
		this.meanAnomalyIsSet = true;
		this.tauIsSet = true;
	} // setTauAndMFromL

	private void setTauAndLFromM ()
	{
		double tau = this.epochJD - StrictMath.toRadians (this.meanAnomalyDegs) / this.nRadPerDay;
		this.tauJD = new JulianDate (tau);
		this.meanLongDegs = net.grelf.Maths.in360 (this.meanAnomalyDegs + this.periLongDegs);
		this.meanLongIsSet = true;
		this.tauIsSet = true;
	} // setTauAndLFromM

	private boolean allIsSet = false;

	/** Check that enough elements have been set to determine the orbit and that it has a name. */
	public boolean isSet ()
	{
		if (this.allIsSet) return true;

		// Else calculate the missing things from the known ones:
		if (this.eIsSet)
		{
			if (this.qIsSet)
			{
				this.aAU = StrictMath.abs (qAU / (1.0 - this.e));
				this.aIsSet = true;
				this.nRadPerDay = K / StrictMath.sqrt (this.aAU * this.aAU * this.aAU);
				this.nIsSet = true;
    	}
			else
			if (this.aIsSet)
			{
				this.qAU = aAU * (1.0 - this.e);
				this.qIsSet = true;
				this.nRadPerDay = K / StrictMath.sqrt (this.aAU * this.aAU * this.aAU);
				this.nIsSet = true;
			}
			else
			if (this.nIsSet)
			{
				this.aAU = StrictMath.cbrt (K * K / (this.nRadPerDay * this.nRadPerDay));
				this.qAU = aAU * (1.0 - this.e);
				this.aIsSet = true;
				this.qIsSet = true;
			}
			else return false;
		}
		else return false;

		if (this.wIsSet && this.omegaIsSet)
		{
			this.periLongDegs = net.grelf.Maths.in360 (StrictMath.toDegrees (wRad) + this.omegaDegs);
			this.periLongIsSet = true;
		}
		else
		if (this.periLongIsSet &&this.omegaIsSet)
		{
			this.wRad = StrictMath.toRadians (net.grelf.Maths.in360 (this.periLongDegs - this.omegaDegs));
			this.wIsSet = true;
		}
		else return false;

		if (this.qIsSet && this.epochIsSet)
		{
			if (this.tauIsSet)
			{
				setLAndMfromTau ();
			}
			else if (this.meanLongIsSet)
			{
				setTauAndMFromL ();
			}
			else if (this.meanAnomalyIsSet)
			{
				setTauAndLFromM ();
			}
		}
		else return false;
//System.out.println (this.toString ());

		this.allIsSet = this.nameIsSet && this.periLongIsSet && this.epochIsSet && this.omegaIsSet && this.iIsSet
						&& this.eIsSet && this.qIsSet && this.tauIsSet;
		return this.allIsSet;
	} // isSet

	@Override
	public String toString ()
	{
		return this.name + "[" + this.symbol + "] pi=" + this.periLongDegs +
						"\u00b0 omega=" + this.omegaDegs + "\u00b0 i=" + this.iDegs +
						"\u00b0 e=" + this.e + " q=" + this.qAU +
						"au epoch=" + this.epochJD + " T=" + this.tauJD.toString ();
	}

	/** Solve Kepler's equation to get the eccentric anomaly (_E) from the mean anomaly (_M) and
	  * eccentricity (e). Angles in radians. */
	public double solveKepler (double _M, double e)
	{
		final double THRESHOLD = 1.0e-8;
		boolean isNegative = false;

		if (_M == 0.0) return 0.0;

		if (_M < 0.0)
		{
			_M = -_M;
			isNegative = true;
		}

		double estimate = _M;
		double error;
		double abs1e = StrictMath.abs (1.0 - e);
		double threshold = THRESHOLD * abs1e;

		if (e > 0.8 && _M < StrictMath.PI / 3.0 || e > 1.0) // up to 60 degrees
		{
			double trial = _M / abs1e;

			if (trial * trial > 6.0 * abs1e) // cubic term is dominant
			{
				if (_M < StrictMath.PI)
				{
					trial = StrictMath.cbrt (6.0 * _M);
				}
				else // hyperbolic, 5th & higher-order terms predominant
				{
					trial = net.grelf.Maths.asinh (_M / e);
				}
			}

			estimate = trial;
		}

		if (e < 1.0)
		{
			error = estimate - e * StrictMath.sin (estimate) - _M;

			while (StrictMath.abs (error) > threshold)
			{
				estimate -= error / (1.0 - e * StrictMath.cos (estimate));
				error = estimate - e * StrictMath.sin (estimate) - _M;
			}
		}
		else
		{
			error = e * StrictMath.sinh (estimate) - estimate - _M;

			while (StrictMath.abs (error) > threshold)
			{
				estimate -= error / (e * StrictMath.cosh (estimate) - 1.0);
				error = e * StrictMath.sinh (estimate) - estimate - _M;
			}
		}

		if (isNegative) return -estimate;

		return estimate;
	} // solveKepler

	/** Get heliocentric cartesian coordinates (in a.u.) at given Julian date. */
	public net.grelf.XYZ getHeliocentricPositionAU (JulianDate jd)
	{
		if (!isSet ()) return null; // Sets everything that can be set

		double _Mrad = this.nRadPerDay * (jd.toDouble () - this.tauJD.toDouble ()); // Mean anomaly

    double rAU, fRad;

    if (this.e < 1.0) // Ellipse
    {
      double _Erad = solveKepler (_Mrad, this.e); // Eccentric anomaly
      double cosE = StrictMath.cos (_Erad);
      rAU = this.aAU * (1.0 - this.e * cosE);
      double rSinF = this.aAU * this.sqrt1_ee * StrictMath.sin (_Erad);
      double rCosF = this.aAU * (cosE - this.e);
      fRad = StrictMath.atan2 (rSinF, rCosF); // True anomaly
		}
    else
//    if (this.e > 1.0) // Hyperbola
    {
      double _F;

      if (_Mrad <= 5.0 * (this.e - 0.5))
      {
        double _Y = StrictMath.sqrt (8.0 - 8.0 / this.e);
        double sinh3w = 3.0 * _Mrad /(_Y * (this.e - 1.0));
        double w = net.grelf.Maths.asinh (sinh3w) / 3.0;
        _F = _Y * StrictMath.sinh (w);
      }
      else
      {
        _F = StrictMath.log (2.0 * _Mrad / this.e);
      }

      rAU = this.aAU * (this.e * StrictMath.cosh (_F) - 1.0);
      fRad = 2.0 * StrictMath.atan2 (StrictMath.sqrt (this.e + 1.0) * StrictMath.tanh (_F * 0.5),
                                     StrictMath.sqrt (this.e - 1.0));
/****
System.out.println ("aAU=" + aAU);
System.out.println ("_F=" + _F);
System.out.println ("fRad=" + fRad);
System.out.println ("rAU=" + rAU) ;
/****/
    }

		double wfRad = this.wRad + fRad;
		double cosWF = StrictMath.cos (wfRad);
		double sinWF = StrictMath.sin (wfRad);
		double x = rAU * (this.cosOmega * cosWF - this.sinOmega * sinWF * this.cosI);
		double y = rAU * (this.sinOmega * cosWF + this.cosOmega * sinWF * this.cosI);
		double z = rAU * sinWF * this.sinI;
		return new net.grelf.XYZ (x, y, z);
	} // getHeliocentricPositionAU
	
} // Orbit
