package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Representation of Right Ascension (celestial longitude). */
public class RA extends net.grelf.Angle implements Cloneable, java.io.Serializable
{
	/** Range 0..23 */
	public byte getHour () 
  {
    return (byte) Math.floor (this.toHours ());
  } // getHour

	/** Range 0..59 */
	public byte getMinute ()
  {
		double totalMins = toHours () * 60.0;
		int wholeMins = (int) Math.floor (totalMins);

    if (wholeMins < 0) wholeMins++;
    
    return (byte) (wholeMins % 60);
  } // getMinute

	/** Range 0.0..59.99999 */
	public float getSecond () 
  {
    double hours = toHours ();
		double totalMins = Math.abs (hours * 60.0);
		double wholeMins = Math.floor (totalMins);
    double minFrac = totalMins - wholeMins;
    float secs = (float) minFrac * 60.0F;
    return secs;
  } // getSecond

	private static final java.text.DecimalFormat DF2 = new java.text.DecimalFormat ("00");
	private static final java.text.DecimalFormat DF2_2 = new java.text.DecimalFormat ("00.00");
	
	/** Can pass in fractional hours or minutes but will be held in normalised form with integer hours and minutes
		* plus fractional seconds. */
	public RA (double hour, double min, double sec, double sigmaDegs)
	{
    super (HOUR_TO_DEG * (hour + min / 60.0 + sec / 3600.0), sigmaDegs, net.grelf.Angle.Units.DEGREES);
  } // RA

	/** Can pass in fractional hours or minutes but will be held in normalised form with integer hours and minutes
		* plus fractional seconds. */
	public RA (double hour, double min, double sec)
	{
    this (hour, min, sec, 0.0);
	} // RA

	private static final double DEG_TO_HOUR = 24.0 / 360.0;
	private static final double HOUR_TO_DEG = 360.0 / 24.0;

	public RA (double degrees, double sigmaDegs)
	{
    super (degrees, sigmaDegs, net.grelf.Angle.Units.DEGREES);
  } // RA

	public RA (double degrees)
	{
		this (degrees, 0.0);
	} // RA

  public RA (net.grelf.Angle angle)
  {
    this (angle.in360 ().getDegrees (), angle.getStdErrDegrees ());
  } // RA

	public double toHours ()
	{
    return DEG_TO_HOUR * getDegrees ();
	} // toHours

	public double toDegrees ()
	{
    return getDegrees ();
	} // toDegrees

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		RA otherRA = (RA) other;

    return this.valueRadians.equals (otherRA.valueRadians); // Using MeasuredValue.equals ()
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
    return super.hashCode ();
	} // hashCode

	@Override
	public RA clone ()
	{
    return new RA (this);
	} // clone

	@Override
	public String toString ()
	{
		return DF2.format (getHour ()) + "h" + DF2.format (getMinute ()) + "m" +
		        DF2_2.format (getSecond ()) + "s";
	} // toString

} // RA