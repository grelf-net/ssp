package net.grelf.astro;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Represent astronomical epochs, such as B1950.0 or J2010.0.
	* The IAU changed the standard from Besselian to Julian as from 1984. Besselian epochs use
	* tropical years of 365.2421988 days. The Julian system is in some ways simpler because it uses
	* years of exactly 365.25 days. Epoch B1950.0 was JDE 2433282.4235. Epoch J2000.0 was JDE 2451545.0
	* exactly. */
public class Epoch implements Cloneable, java.io.Serializable
{
	public static final Epoch J2000 = new Epoch ('J', 2000);
	
	public float getYear () { return this.year; }
	private float year;

	/** 'J' or 'B'. */
	public char getType () { return this.type; }
	private char type = 'J'; // Unless set to 'B'

	/** Creates an Epoch assuming the type letter is 'J'. */
	public Epoch (float year)
	{
		this ('J', year);
	} // Epoch

	/** Creates an Epoch with any type letter (but it must be 'B' or 'J' to make sense astronomically). */
	public Epoch (char type, float year)
	{
		this.type = type;
		this.year = year;
	} // Epoch

	/** Returns null if the epoch type is not 'B' or 'J'. */
	public JulianDate getJulianDate ()
	{
		switch (this.type)
		{
			case 'B':
			{
				double years = this.year - 1950.0;
				return new JulianDate (2433282.4235 + years * 365.2421988);
			}

			case 'J':
			{
				double years = this.year - 2000.0F;
				return new JulianDate (2451545.0 + years * 365.25);
			}
		}

		return null;
	} // getJulianDate

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		Epoch otherEpoch = (Epoch) other;

		if (otherEpoch.year != this.year) return false;
		if (otherEpoch.type != this.type) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) (this.year * 1234567 + (int) this.type);
	} // hashCode

	@Override
	public Epoch clone ()
	{
		return new Epoch (this.type, this.year);
	} // clone

	private static final java.text.DecimalFormat DF2 = new java.text.DecimalFormat ("0.00");

	@Override
	public String toString ()
	{
		return this.type + DF2.format (this.year);
	} // toString

} // Epoch