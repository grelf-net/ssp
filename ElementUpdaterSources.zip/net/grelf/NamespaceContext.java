package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** For use with javax.xml.xpath.XPath.<br>
	* NB: Unprefixed namespaces cause great complications with XPath - typically nodes are not found when you expect
	* them to be. So when processing XML that uses an unprefixed namespace, pretend there is one and set it in this
	* context. Eg, AstroGrid's VOTABLE XML has xmlns="http://www.ivoa.net/xml/VOTable/v1.1" so all of its elements
	* are unprefixed. That's fine but when using XPath to analyse the structure it is necessary to invent a prefix.
	* The following code snippet finds all the TR elements in a VOTABLE, which is a common requirement.
	* <pre>
	*		String xpathToTR = "/vot:VOTABLE/vot:RESOURCE/vot:TABLE/vot:DATA/vot:TABLEDATA/vot:TR";
	*
	*		try
	*		{
	*			net.grelf.grip.NamespaceContext nsContext =
	*         new net.grelf.NamespaceContext ("vot", "http://www.ivoa.net/xml/VOTable/v1.1");
	*			XPATH.setNamespaceContext (nsContext);   // XPATH is a static constant, to avoid repeated construction
	*			javax.xml.xpath.XPathExpression compiledXPath = XPATH.compile (xpathToTR);
	*			org.w3c.dom.NodeList trElements =
	*         (org.w3c.dom.NodeList) compiledXPath.evaluate (voTable, javax.xml.xpath.XPathConstants.NODESET);
	* </pre><br>
	* (org.w3c.dom is supplied in Java SE but it's right down at the end of the package list in the API documentation.)
	*/
public class NamespaceContext implements javax.xml.namespace.NamespaceContext
{
	private java.util.Map <String, String> map; // Keyed on prefix, values are namespace URIs

	/** Construct a context containing one prefix-URI pair. */
	public NamespaceContext (String prefix, String namespaceURI)
	{
		this.map = new java.util.HashMap <String, String> ();
		this.map.put (prefix, namespaceURI);
	} // NamespaceContext

	/** Add a further prefix-URI pair to the context. */
	public void addNamespace (String prefix, String namespaceURI)
	{
		this.map.put (prefix, namespaceURI);
	} // addNamespace

	@Override
	public String getNamespaceURI (String prefix)
	{
		return this.map.get (prefix);
	} // getNamespaceURI

	/** Returns null if namespaceURI is not found. */
	@Override
	public String getPrefix (String namespaceURI)
	{
		for (String key : this.map.keySet ())
		{
			if (this.map.get (key).equals (namespaceURI))
			{
				return key;
			}
		}

		return null;
	} // getPrefix

	@Override
	public java.util.Iterator getPrefixes (String namespaceURI)
	{
		java.util.List <String> prefixes = new java.util.ArrayList <String> ();

		for (String key : this.map.keySet ())
		{
			if (this.map.get (key).equals (namespaceURI))
			{
				prefixes.add (key);
			}
		}

		return prefixes.iterator ();
	} // getPrefixes

} // NamespaceContext
