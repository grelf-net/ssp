package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Calculate values of the Gaussian curve. For use in convolutions. */
public class Gaussian_ implements Gaussian
{
	private float mean, oneOverSSquared;
	// Radius at half maximum is s / 1.2011224

	/** Create a Gaussian curve of given mean x-value and half-height radius. */
	public Gaussian_ (float mean, float halfHeightRadius)
	{
		this.mean = mean;
		float s = halfHeightRadius / (float) StrictMath.sqrt (-StrictMath.log (0.5));
		oneOverSSquared = 1.0F / (s * s);
	} // Gaussian_

	/** Calculate a y value, given x */
	@Override
	public float calc (float x)
	{
		float xmm = x - mean;
		return (float) StrictMath.exp (-xmm * xmm * oneOverSSquared);
	} // calc

	/** Get a String representation of the Gaussian */
	@Override
	public String toString ()
	{
		return "Gaussian: mean = " + mean + ", 1 / S-squared = " + oneOverSSquared;
	} // toString

} // Gaussian_