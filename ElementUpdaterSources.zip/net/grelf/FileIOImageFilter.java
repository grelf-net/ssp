package net.grelf;

// This Java source file is part of the application GRIP, for processing and
// measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in
// connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle
// ones. The author has tested this software to the best of his abilities to
// ensure that it is generally fit for its purpose of processing and measuring
// digital photographs. The author makes absolutely no claims and gives no
// guarantees whatsoever as to the accuracy of any output from this software.
// Anyone making decisions based on any output from this software has a
// responsibility to first convince themselves of the appropriateness of so
// doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory
// documentation are available for that purpose.

/** Support class for FileIO. Provides image file type selection for users
  * of the file chooser in FileIO. */
public class FileIOImageFilter extends FileFilterExtra
{
	public static final int ANY = 0;
	public static final int BMP = 1;
	public static final int GIF = 2;
	public static final int JPG = 3;
	public static final int PNG = 4;
	public static final int TIF = 5;
	public static final int RAW = 6;
  public static final int FITS = 7;
	public static final int ACCUM = 8;

  public static final FileIOImageFilter BMP_FILTER = new FileIOImageFilter (BMP);
  public static final FileIOImageFilter GIF_FILTER = new FileIOImageFilter (GIF);
  public static final FileIOImageFilter JPG_FILTER = new FileIOImageFilter (JPG);
  public static final FileIOImageFilter PNG_FILTER = new FileIOImageFilter (PNG);
  public static final FileIOImageFilter TIF_FILTER = new FileIOImageFilter (TIF);
  public static final FileIOImageFilter RAW_FILTER = new FileIOImageFilter (RAW);
  public static final FileIOImageFilter FITS_FILTER = new FileIOImageFilter (FITS);
  public static final FileIOImageFilter ACCUM_FILTER = new FileIOImageFilter (ACCUM);

//  private int kind; // Now in superclass FileFilterExtra

	/** Filter to select any image kind for which we have JAI plug-ins. */
	public FileIOImageFilter ()
	{
		super ();
		this.kind = ANY;
    this.extension = "";
	} // FileIOImageFilter

	/** Filter to select a specific image kind. */
	public FileIOImageFilter (int aKind)
	{
		super ();
		this.kind = aKind;

    switch (this.kind)
    {
      case ACCUM: this.extension = ".accum"; break;
      case BMP:   this.extension = ".bmp";   break;
      case FITS:  this.extension = ".fits";  break;
      case GIF:   this.extension = ".gif";   break;
      case JPG:   this.extension = ".jpg";   break;
      case PNG:   this.extension = ".png";   break;
      case TIF:   this.extension = ".tif";   break;
      default:    this.extension = ""; // ANY, RAW
    }
	} // FileIOImageFilter

	/** Whether the filter can accept the given file. */
	@Override
	public boolean accept (java.io.File f)
	{
		if (f.isDirectory ()) { return true; } // To enable navigation

		String name = f.getName ().toLowerCase ();

		switch (kind)
		{
			case ACCUM: return name.endsWith (".accum");
			case BMP: return name.endsWith (".bmp");
			case GIF: return name.endsWith (".gif");
			case JPG: return name.endsWith (".jpg");
			case PNG: return name.endsWith (".png");
			case RAW: return name.endsWith (".crw")
              || name.endsWith (".cr2")
              || name.endsWith (".dng")
			        || name.endsWith (".mrw")
              || name.endsWith (".nef")
			        || name.endsWith (".pef")
              || name.endsWith (".srf");
			case TIF: return name.endsWith (".tif");
      case FITS: return name.endsWith (".fits")
              || name.endsWith (".fit")
              || name.endsWith (".fts");
			default:  return name.endsWith (".accum")
              || name.endsWith (".fits")
              || name.endsWith (".fit")
              || name.endsWith (".fts")
							|| name.endsWith (".bmp")
              || name.endsWith (".crw")
              || name.endsWith (".cr2")
			        || name.endsWith (".dng")
              || name.endsWith (".gif")
              || name.endsWith (".jpg")
			        || name.endsWith (".mrw")
              || name.endsWith (".nef")
              || name.endsWith (".pef")
			        || name.endsWith (".png")
              || name.endsWith (".srf")
              || name.endsWith (".tif");
		}
	} // accept

	/** Get a concise description of what the filter can accept. */
	@Override
	public String getDescription ()
	{
		switch (kind)
		{
			case BMP:
        return "BMP image (*.bmp)";

			case GIF:
        return "GIF image (*.gif)";

			case JPG:
        return "JPEG image (*.jpg)";

			case PNG:
        return "PNG image (*.png)";

			case RAW: return
              "RAW image (*.crw, *.cr2, *.dng, *.mrw, *.nef, *.pef, *.srf)";

			case TIF:
        return "TIFF image (*.tif)";

      case FITS:
        return "FITS image (*.fits, *.fit, .fts)";

			case ACCUM:
        return "Accumulator image (*.accum)";

			default:  return
        "Image (*.accum, *.bmp, *.crw, *.cr2, *.dng, *.fits, *.fit, *.fts, "
              + "*.gif, *.jpg, *.mrw, *.nef, *.pef, *.png, *.srf, *.tif)";
		}
	} // getDescription

	public static String [] getAllKnownExtensions ()
	{
		return new String []
		{
			".accum", ".bmp", ".gif", ".jpg", ".png", ".tif", ".fits", ".fit", ".fts",
			".crw", ".cr2", ".dng", ".mrw", ".nef", ".pef", ".srf"
		};
	} // getAllKnownExtensions

} // FileIOImageFilter