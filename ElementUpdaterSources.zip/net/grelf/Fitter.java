package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Fits data to particular curves. */
public interface Fitter
{
	boolean isFitted ();

	/** Fit a straight line y = Mx + C to the given data points by the least squares method. The two arrays must be of
		* the same length and that is the number of data points. After fitting the results are obtainable via the other
		* methods of this class. The third parameter is a further array of the same length containing kown standard
		* deviations of the measured values y, as weighting factors. If sigmaY is null all points are given equal weight. */
	void leastSquaresStraightLine (double [] x, double [] y, double [] sigmaY);

	/** Get the slope of the fitted straight line, as in y = Mx + C */
	double getM ();

	/** Get the intercept of the fitted straight line, as in y = Mx + c */
	double getC ();

	/** Get the standard deviation of the slope of the fitted line. */
	double getSigmaM ();

	/** Get the standard deviation of the intercept of the fitted line. */
	double getSigmaC ();

	/** Get the chi-squared fitting factor. */
	double getChiSq ();

	/** Get quality factor Q. */
	double getQ ();

	/** Calculate y for given x, using the fitted parameters, y = Mx + C. Returns 0.0 if not fitted. */
	double y (double x);
	
	/** Calculate the inverse: x for given y, using the fitted parameters, x = (y - C) / M. Returns 0.0 if not fitted. */
	double x (double y);
	
} // Fitter