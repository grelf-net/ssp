package net.grelf;

// This Java source file is part of the application GRIP, for processing and
// measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in
// connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle
// ones. The author has tested this software to the best of his abilities to
// ensure that it is generally fit for its purpose of processing and measuring
// digital photographs. The author makes absolutely no claims and gives no
// guarantees whatsoever as to the accuracy of any output from this software.
// Anyone making decisions based on any output from this software has a
// responsibility to first convince themselves of the appropriateness of so
// doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory
// documentation are available for that purpose.

/** Support class for FileIO. Provides CSV file type selection for users
  * of the file chooser in FileIO. */
public class FileIO_XMLFilter extends FileFilterExtra
{
	public static final int ANY = 0;
	public static final int XML = 1;

	public FileIO_XMLFilter ()
	{
		super ();
		this.kind = ANY;
    this.extension = "";
	} // FileIO_XMLFilter

	public FileIO_XMLFilter (int aKind)
	{
		super ();
		this.kind = aKind;

    if (this.kind == XML)
    {
      this.extension = ".xml";
    }
    else
    {
      this.extension = "";
    }
	} // FileIO_XMLFilter

	/** Whether the filter can accept the given file. */
	@Override
	public boolean accept (java.io.File f)
	{
		if (f.isDirectory ()) { return true; } // To enable navigation

		String name = f.getName ().toLowerCase ();

		switch (kind)
		{
			case XML: return name.endsWith (".xml");
			default:  return false;
		}
	} // accept

	/** Get a concise description of what the filter can accept. */
	@Override
	public String getDescription ()
	{
		switch (kind)
		{
			case XML: return "XML files (*.xml)";
			default:  return "Any file (*.*)";
		}
	} // getDescription

} // FileIO_XMLFilter
