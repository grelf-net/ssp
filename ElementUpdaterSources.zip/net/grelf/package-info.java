/** This package contains general-purpose Java classes: non-astronomical and not specific to GRIP. */
package net.grelf;
