package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** A 2D geometrical point with coordinates of type float. Supports VectorFloat. */
public class PointFloat implements Cloneable, java.io.Serializable
{
	public float x, y;

	public PointFloat (float aX, float aY) { this.x = aX; this.y = aY; }

	public PointFloat (java.awt.Point pt) { this.x = pt.x; this.y = pt.y; }

	/** Offset the current point by a vector. */
	public PointFloat offset (VectorFloat vector)
	{
		PointFloat pt = new PointFloat (this.x + vector.getDx (), this.y + vector.getDy ());
		return pt;
	} // offset

	public double distanceFrom (PointFloat other)
	{
		double dx = this.x - other.x;
		double dy = this.y - other.y;
		return StrictMath.sqrt (dx * dx + dy * dy);
	} // distanceFrom

	private static final double EPSILON = 1.0E-7;

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (!other.getClass ().equals (this.getClass ())) return false;

		PointFloat otherPt = (PointFloat) other;

		if (Math.abs (otherPt.x - this.x) > EPSILON) return false;
		if (Math.abs (otherPt.y - this.y) > EPSILON) return false;

		return true;
	} //equals

	/** Enable objects of this class to be used as hash keys. */
	@Override
	public int hashCode ()
	{
		return (int) (this.x * 23  + this.y * 17);
	} // hashCode

	@Override
	public PointFloat clone ()
	{
		return new PointFloat (this.x, this.y);
	} // clone

	/** Get a simple description of the PointFloat */
	@Override
	public String toString ()
	{
		return "PointFloat: at (" + this.x + ", " + this.y + ")";
	} // toString

} // PointFloat
