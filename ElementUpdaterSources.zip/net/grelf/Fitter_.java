package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Fits data to particular curves. */
public class Fitter_ implements Fitter
{
	private boolean fitted = false;
	@Override
	public boolean isFitted () { return this.fitted; }

	private double m;
	@Override
	public double getM () { return this.m; }

	private double c;
	@Override
	public double getC () { return this.c; }

	private double sigmaM;
	@Override
	public double getSigmaM () { return this.sigmaM; }

	private double sigmaC;
	@Override
	public double getSigmaC () { return this.sigmaC; }

	private double chiSq;
	@Override
	public double getChiSq () { return this.chiSq; }

	private double q;
	@Override
	public double getQ () { return this.q; }

	/** Fit a straight line y = mx + c to the given data points by the least squares method. The two arrays must be of
		* the same length and that is the number of data points. After fitting the results are obtainable via the other
		* methods of this class. The third parameter is a further array of the same length containing kown standard
		* deviations of the measured values y, as weighting factors. If sigmaY is null all points are given equal weight. */
	@Override
	public void leastSquaresStraightLine (double [] x, double [] y, double [] sigmaY)
	{
		int n = x.length;

		if (n != y.length)
		{
			net.grelf.Util.warning ("Sorry", "The data arrays for least squares fitting are of different lengths");
			return;
		}

		if (null != sigmaY && n != sigmaY.length)
		{
			net.grelf.Util.warning ("Sorry", "The sigmaY array is not the same length as the data arrays.");
			return;
		}

		double sumX = 0.0;
		double sumY = 0.0;
		double sumS = 0.0;
		this.m = 0.0;

		if (null == sigmaY)
		{
			for (int i = 0; i < n; i++)
			{
				sumX += x [i];
				sumY += y [i];
			}

			sumS = n;
		}
		else
		{
			for (int i = 0; i < n; i++)
			{
				double wt = 1.0 / (sigmaY [i] * sigmaY [i]);
				sumS += wt;
				sumX += x [i] * wt;
				sumY += y [i] * wt;
			}
		}

		double sumXoverSumS = sumX / sumS;
		double sumTSq = 0.0;

		if (null == sigmaY)
		{
			for (int i = 0; i < n; i++)
			{
				double t = x [i] - sumXoverSumS;
				sumTSq += t * t;
				this.m += t * y [i];
			}
		}
		else
		{
			for (int i = 0; i < n; i++)
			{
				double t = (x [i] - sumXoverSumS) / sigmaY [i];
				sumTSq += t * t;
				this.m += t * y [i] / sigmaY [i];
			}
		}

		this.m /= sumTSq;
		this.c = (sumY - sumX * this.m) / sumS;
		this.sigmaM = StrictMath.sqrt (1.0 / sumTSq);
		this.sigmaC = StrictMath.sqrt ((1.0 + sumX * sumX / (sumS * sumTSq)) / sumS);

		this.chiSq = 0.0;

		if (null == sigmaY)
		{
			for (int i = 0; i < n; i++)
			{
				double err = y [i] - (this.m * x [i] + this.c);
				this.chiSq += err * err;
			}

			double sigmaData = StrictMath.sqrt (this.chiSq / (n - 2));
			this.sigmaM *= sigmaData;
			this.sigmaC *= sigmaData;
			this.q = 1.0;
		}
		else
		{
			for (int i = 0; i < n; i++)
			{
				double err = (y [i] - (this.m * x [i] + this.c))  / sigmaY [i];
				this.chiSq += err * err;
			}

			this.q = gammaQ (0.5 * (n - 2), 0.5 * this.chiSq);
		}

		fitted = true;
	} // leastSquaresStraightLine

	/** Calculate y for given x, using the fitted parameters, y = mx + c. Returns 0.0 if not fitted. */
	@Override
	public double y (double x)
	{
		if (!this.fitted) return 0.0;

		return this.m * x + this.c;
	} // y

	/** Calculate the inverse: x for given y, using the fitted parameters, x = (y - c) / m. Returns 0.0 if not fitted. */
	@Override
	public double x (double y)
	{
		if (!this.fitted) return 0.0;

		return (y - this.c) / this.m;
	} // x

	/** Incomplete gamma function Q (a, x) = 1 - P (a, x) */
	private double gammaQ (double a, double x)
	{
		if (x < 0.0 || a <= 0.0)
		{
			net.grelf.Util.logWarning ("Fitter: invalid arguments to gammaQ ()");
			return 1.0;
		}

		if (x < a + 1.0)
		{
			return 1.0 - gser (a, x);
		}
		else
		{
			return gcf (a, x);
		}
	} // gammaQ

	private static final int MAX_ITERATIONS = 100;
	private static final double EPSILON = 1.0E-7;
	private static final double MIN_VALUE = 1.0E-30;

	private double gser (double a, double x)
	{
		if (x < 0.0)
		{
			net.grelf.Util.logWarning ("Fitter: x < 0 in gser ()");
			return 0.0;
		}

		double gln = lnGamma (a);
		double ap = a;
		double del = 1.0 / a;
		double sum = del;

		for (int n = 1; n <= MAX_ITERATIONS; n++)
		{
			ap++;
			del *= x / ap;
			sum += del;

			if (StrictMath.abs (del) < StrictMath.abs (sum) * EPSILON)
			{
				return sum * StrictMath.exp (-x + a * StrictMath.log (x) - gln);
			}
		}

		net.grelf.Util.logWarning ("Fitter: settings exceeded in gamser ()");
		return 0.0;
	} // gser

	private double gcf (double a, double x)
	{
		double gln = lnGamma (a);
		double b = x + 1.0 - a;
		double cc = Double.MAX_VALUE;
		double d = 1.0 / b;
		double h = d;
		int i;

		for (i = 1; i <= MAX_ITERATIONS; i++)
		{
			double an = -i * (i -a);
			b += 2.0;
			d = an * d + b;

			if (StrictMath.abs (d) < MIN_VALUE)
			{
				d = Double.MIN_VALUE;
			}

			cc = b + an / cc;

			if (StrictMath.abs (cc) < MIN_VALUE)
			{
				cc = MIN_VALUE;
			}

			d = 1.0 / d;
			double del = d * cc;
			h *= del;

			if (StrictMath.abs (del - 1.0) < EPSILON) break;
		}

		if (i > MAX_ITERATIONS)
		{
			net.grelf.Util.logWarning ("Fitter: settings exceeded in gcf ()");
		}

		return StrictMath.exp (-x + a * StrictMath.log (x) - gln) * h;
	} // gcf

	private final static double cof [] =
	{
		76.18009172947146,
		-86.50532032941677,
		24.01409824083091,
		-1.231739572450155,
		0.1208650973866179E-2,
		-0.5395239384953E-5
	};

	private double lnGamma (double x)
	{
		double y = x;
		double tmp = x + 5.5;
		tmp -= (x + 0.5) * StrictMath.log (tmp);
		double ser = 1.000000000190015;

		for (int j = 0; j < cof.length; j++)
		{
			ser += cof [j] / ++y;
		}

		return -tmp + StrictMath.log (2.5066282746310005 * ser / x);
	} // lnGamma

} // Fitter_