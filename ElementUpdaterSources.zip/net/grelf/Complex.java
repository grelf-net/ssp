package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Complex numbers and operations upon them. */
public class Complex implements Cloneable, java.io.Serializable
{
	/** Real part. */
	public double re;
	/** Imaginary part. */
	public double im;

	public Complex (double re, double im)
	{
		this.re = re;
		this.im = im;
	}	// Complex

	@Override
	public Complex clone ()
	{
		return new Complex (this.re, this.im);
	} // clone

	@Override
	public String toString ()
	{
		if (this.im >= 0.0)
		{
			return this.re + " + " + this.im + "i";
		}
		else
		{
			return this.re + " - " + -this.im + "i";

		}
	} // toString

	@Override
	public boolean equals (Object other)
	{
		if (null == other) return false;
		if (this.getClass () != other.getClass ()) return false;

		Complex z = (Complex) other;

		if (StrictMath.abs (this.re - z.re) > this.re * 1.0e-15) return false;
		if (StrictMath.abs (this.im - z.im) > this.im * 1.0e-15) return false;

		return true;
	} // equals

	@Override
	public int hashCode ()
	{
		return (int) (17171717.0 * this.re - 232323.0 * this.im);
	} // hashCode

	/** Returns |z| = root sum of squares of real and imaginary parts. */
	public double mod ()
	{
		return StrictMath.sqrt (this.re * this.re + this.im * this.im);
	} // mod

	/** Returns polar angle. */
	public Angle arg ()
	{
		return Angle.atan2 (this.im, this.re);
	} // arg

	/** Conjugates this and also returns this, to be chainable. */
	public Complex conjugate ()
	{
		this.im = -this.im;
		return this;
	} // conjugate

	/** Sets this from z and also returns this, to be chainable. */
	public Complex assign (Complex z)
	{
		this.re = z.re;
		this.im = z.im;
		return this;
	} // assign

	/** Adds z to this and also returns this, to be chainable. */
	public Complex add (Complex z)
	{
		this.re += z.re;
		this.im += z.im;
		return this;
	} // add

	/** Adds real x to this and also returns this, to be chainable. */
	public Complex add (double x)
	{
		this.re += x;
		return this;
	} // add

	/** Subtracts z from this and also returns this, to be chainable. */
	public Complex subtract (Complex z)
	{
		this.re -= z.re;
		this.im -= z.im;
		return this;
	} // subtract

	/** Subtracts real x from this and also returns this, to be chainable. */
	public Complex subtract (double x)
	{
		this.re -= x;
		return this;
	} // subtract

	/** Multiplies this by z and also returns this, to be chainable. */
	public Complex multiply (Complex z)
	{
		double tempRe = this.re * z.re - this.im * z.im;
		this.im = this.re * z.im + this.im * z.re;
		this.re = tempRe;
		return this;
	} // multiply

	/** Multiplies this by real x and also returns this, to be chainable. */
	public Complex multiply (double x)
	{
		this.re *= x;
		this.im *= x;
		return this;
	} // multiply

	/** Divides this by z and returns this, to be chainable. */
	public Complex divide (Complex z)
	{
		double divisor = z.re * z.re + z.im * z.im;
		double tempRe = this.re * z.re + this.im * z.im;
		this.im = (this.im * z.re - this.re * z.im) / divisor;
		this.re = tempRe / divisor;
		return this;
	} // divide

	/** Divides this by real x and also returns this, to be chainable. */
	public Complex divide (double x)
	{
		this.re /= x;
		this.im /= x;
		return this;
	} // divide

	/** Get exp (i.theta) = cos (theta) + i.sin (theta). */
	public static Complex expi (double theta)
	{
		return new Complex (StrictMath.cos (theta), StrictMath.sin (theta));
	} // expi

	/** Get exp (i.theta) = cos (theta) + i.sin (theta). */
	public static Complex expi (Angle theta)
	{
		return new Complex (theta.cos (), theta.sin ());
	} // expi

} // Complex
