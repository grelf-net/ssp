package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Provides an efficient static method for reading from a non-integer pixel position in an image */
public class Interpolator
{
	private Interpolator () {} // Cannot instantiate.

	public static int [] getPixel (java.awt.image.Raster rr, double x, double y)
	{
		int nBands = rr.getSampleModel ().getNumBands ();
		int [] px = new int [nBands];

    int wd = rr.getWidth ();
    int ht = rr.getHeight ();
    int wd1 = wd - 1;
    int ht1 = ht - 1;

    if ((x < 0.0) || (x > wd1) || (y < 0.0) || (y > ht1))
    {
			for (int b = 0; b < px.length; b++)
			{
				px [b] = 0;
			}

      return px;
    }

    if ((x == wd1) || (y == ht1))
    {
			return rr.getPixel ((int) x, (int) y, px);
		}

		int x00 = (int) x;
		int y00 = (int) y;
		double fracX0 = x - x00;
		double fracX1 = 1.0 - fracX0;
		double fracY0 = y - y00;
		double fracY1 = 1.0 - fracY0;

		int [] px00 = new int [nBands];
		rr.getPixel (x00, y00, px00);

		int [] px10 = new int [nBands];
		rr.getPixel (x00 + 1, y00, px10);

		int [] px01 = new int [nBands];
		rr.getPixel (x00, y00 + 1, px01);

		int [] px11 = new int [nBands];
		rr.getPixel (x00 + 1, y00 + 1, px11);

		for (int b = 0; b < px.length; b++)
		{
			px [b] = (int) (fracX0 * (fracY0 * px11 [b] + fracY1 * px10 [b]) +
			                fracX1 * (fracY0 * px01 [b] + fracY1 * px00 [b]));
		}

		return px;
	} // getPixel

} // Interpolator