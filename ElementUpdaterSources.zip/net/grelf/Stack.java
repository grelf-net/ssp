package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** A simple last-in-first-out (LIFO) stack, to a better OO design than Sun's one: it only exposes the behaviour that a stack should have. */
public interface Stack<E>
{
	boolean isEmpty ();

	/** Look at last value without removing it. */
	E peek ();

	/** Get the last value, removing it from the stack. */
	E pop ();

	/** Put a new last value onto the stack. */
	void push (E obj);

} // Stack