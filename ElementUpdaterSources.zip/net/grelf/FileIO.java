package net.grelf;

// This Java source file is part of the application GRIP, for processing and
// measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in
// connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle
// ones. The author has tested this software to the best of his abilities to
// ensure that it is generally fit for its purpose of processing and measuring
// digital photographs. The author makes absolutely no claims and gives no
// guarantees whatsoever as to the accuracy of any output from this software.
// Anyone making decisions based on any output from this software has a
// responsibility to first convince themselves of the appropriateness of so
// doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory
// documentation are available for that purpose.

/** Various useful static methods for file handling. This class cannot be
  * instantiated. It has a javax.swing.JFileChooser object so that successive
  * calls to methods here keep track of the last directory used, for the
  * user's convenience. */
public class FileIO
{
	private static final javax.swing.JFileChooser JFC =
          new javax.swing.JFileChooser ();

	static
	{
		JFC.setCurrentDirectory (new java.io.File (
            System.getProperty ("user.dir")));
	}

	private FileIO () {} // Cannot instantiate.

	/** Copy any file. */
	public static void copyFile (String srcPath, String dstPath)
  throws java.io.IOException
	{
		java.io.BufferedInputStream in =
            new java.io.BufferedInputStream (
                new java.io.FileInputStream (srcPath));
		java.io.BufferedOutputStream out =
            new java.io.BufferedOutputStream (
                new java.io.FileOutputStream (dstPath));
		int b;

		while (-1 != (b = in.read ()))
		{
			out.write (b);
		}

		in.close ();
		out.close ();
	} // copyFile

	/** Get the file extension, including the dot. Returns an empty string if
    * there is no dot. */
	public static String getExtension (String filename)
	{
		int iDot = filename.lastIndexOf (".");

		if (-1 == iDot) { return ""; }

		return (filename.substring (iDot));
	} // getExtension

	/** Reads the first 5 characters of the given file to see whether they are
    * &gt;?xml<br>
		* New 9.12.3 */
	public static boolean isXmlFile (String filePath)
	{
    try
    {
			char [] buffer = new char [5];
      java.io.FileReader reader = new java.io.FileReader (filePath);
      int nRead = reader.read (buffer, 0, 5);
      reader.close ();

      if (5 != nRead) { return false; }

      String s = new String (buffer, 0, 5);

      if (s.equals ("<?xml"))  { return true; }
    }
    catch (java.io.IOException ex)
    {
      net.grelf.Util.logWarning (ex.toString ());
    }

    return false;
	} // isXmlFile

	/** Remove the file extension, including the dot. */
	public static String removeExtension (String filename)
	{
		int i = filename.lastIndexOf (".");

		if (-1 == i) { return filename; }

		return (filename.substring (0, i));
	} // removeExtension
  
	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
  public static String selectDirectory (String title, String startingDir)
  {
    return selectInputFile (title, startingDir, null, null, true);
  } // selectDirectory

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectInputFile (String title)
	{
		return selectInputFile (title, null, null, null);
	} // selectInputFile

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectInputFile (String title, String folderName)
	{
		return selectInputFile (title, folderName, null, null);
	} // selectInputFile

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectInputFile (String title, String folderName,
	                         javax.swing.filechooser.FileFilter [] filters)
	{
		return selectInputFile (title, folderName, filters, null);
	} // selectInputFile

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectInputFile (String title, String folderName,
                        javax.swing.filechooser.FileFilter [] filters,
												String initialFileName)
	{
    return selectInputFile (title, folderName, filters, initialFileName, false);
  } // selectInputFile
  
	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectInputFile (String title, String folderName,
                        javax.swing.filechooser.FileFilter [] filters,
												String initialFileName, boolean folderRatherThanFile)
	{
		JFC.setDialogTitle (title);

		if (null != initialFileName)
		{
			JFC.setSelectedFile (new java.io.File (initialFileName));
		}

		if (null != folderName)
		{
			JFC.setCurrentDirectory (new java.io.File (folderName));
		}

    if (folderRatherThanFile)
    {
      JFC.setFileSelectionMode (javax.swing.JFileChooser.DIRECTORIES_ONLY);
    }
    else
    {
      JFC.setFileSelectionMode (javax.swing.JFileChooser.FILES_ONLY);
    }
    
		JFC.resetChoosableFileFilters ();

		if (null != filters)
		{
			for (int i = 0; i < filters.length; i++)
			{
				JFC.addChoosableFileFilter (filters [i]);
			}
		}

		if (javax.swing.JFileChooser.APPROVE_OPTION == JFC.showOpenDialog (null))
		{
			return JFC.getSelectedFile ().getPath ();
		}

		return null;
	} // selectInputFile

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static java.io.File [] selectInputFiles (String title)
	{
		return selectInputFiles (title, null, null);
	} // selectInputFiles

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static java.io.File [] selectInputFiles (
          String title, String folderName)
	{
		return selectInputFiles (title, null, null);
	} // selectInputFiles

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static java.io.File [] selectInputFiles (String title,
          String folderName, javax.swing.filechooser.FileFilter [] filters)
	{
		JFC.setDialogTitle (title);

		if (null != folderName)
		{
			JFC.setCurrentDirectory (new java.io.File (folderName));
		}

		JFC.setFileSelectionMode (javax.swing.JFileChooser.FILES_ONLY);
		JFC.setMultiSelectionEnabled (true);
		JFC.resetChoosableFileFilters ();

		if (null != filters)
		{
			for (int i = 0; i < filters.length; i++)
			{
				JFC.addChoosableFileFilter (filters [i]);
			}
		}

		if (javax.swing.JFileChooser.APPROVE_OPTION == JFC.showOpenDialog (null))
		{
			return JFC.getSelectedFiles ();
		}

		return null;
	} // selectInputFiles

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectOutputFile (String title)
	{
		return selectOutputFile (title, null, null, null);
	} // selectOutputFile

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectOutputFile (String title, String folderName)
	{
		return selectOutputFile (title, folderName, null, null);
	} // selectOutputFile

	/** Returns null if user leaves the file selection dialogue by the
    * cancel button. */
	public static String selectOutputFile (String title, String folderName,
	                             javax.swing.filechooser.FileFilter [] filters)
	{
		return selectOutputFile (title, folderName, filters, null);
	} // selectOutputFile

	/** Returns null if user leaves the file selection dialogue by the
   * cancel button. */
	public static String selectOutputFile (String title, String folderName,
	                  javax.swing.filechooser.FileFilter [] filters,
	        					String initialFileName)
	{
    currentFilter = null; // Until user selects
		JFC.setDialogTitle (title);

		if (null != initialFileName)
		{
			JFC.setSelectedFile (new java.io.File (initialFileName));
		}

		if (null != folderName)
		{
			JFC.setCurrentDirectory (new java.io.File (folderName));
		}

		JFC.setFileSelectionMode (javax.swing.JFileChooser.FILES_ONLY);
		JFC.resetChoosableFileFilters ();

		if (null != filters)
		{
			for (int i = 0; i < filters.length; i++)
			{
				JFC.addChoosableFileFilter (filters [i]);
			}
		}
    
		if (javax.swing.JFileChooser.APPROVE_OPTION == JFC.showSaveDialog (null))
		{
			java.io.File out = JFC.getSelectedFile ();
      currentFilter = JFC.getFileFilter ();
      String outPath = out.getPath ();
      boolean ok = true;

      if (currentFilter instanceof FileFilterExtra)
      {
        FileFilterExtra fx = (FileFilterExtra) currentFilter;
        String ext = fx.getExtension ();

        if (!outPath.endsWith (ext))
        {
          outPath += ext;

          ok = net.grelf.Util.confirm (JFC, "Auto-extension OK?",
                  "Adding extension " + ext + "\nto make file\n" + outPath);
        }
      }

      if (ok)
      {
        if (!out.exists ())
        {
          return outPath;
        }
        else
        {
          if (net.grelf.Util.confirm (JFC,
                  "Overwrite?", "<html>" + out.getName () +
                  "<br> already exists. Replace it?</html>"))
          {
            return outPath;
          }
        }
      }
		}

		return null;
	} // selectOutputFile


  public static javax.swing.filechooser.FileFilter getCurrentFilter ()
  { return currentFilter; }

  private static javax.swing.filechooser.FileFilter currentFilter = null;

} // FileIO