package net.grelf;

// This Java source file is part of the application GRIP, for processing and measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//
// All software contains bugs, even if, we hope, they are only extremely subtle ones.
// The author has tested this software to the best of his abilities to ensure that it is generally fit for its
// purpose of processing and measuring digital photographs.
// The author makes absolutely no claims and gives no guarantees whatsoever as to the accuracy of any output
// from this software.
// Anyone making decisions based on any output from this software has a responsibility to first convince them-
// selves of the appropriateness of so doing. They should test the software for themselves and understand how it
// works, sufficiently for their needs. Source code and explanatory documentation are available for that purpose.

/** Objects of this class describe the vector connecting two detected objects (Blobs). The description is in polar
	* coordinates: radius r (pixels) and angle theta (radians). These two values are held as floating point numbers
	* so equality can only be determined within certain tolerances. The tolerances are set fairly wide because for
	* astrophotography the aim is to be able to compare vectors between images taken on a tripod, so the stars will
	* have moved slightly because of the Earth's rotation. The separation will hardly change, particularly if an
	* inverse gnomonic projection (see class Gnomonic) has been done on each image first, but the angle change may be
	* significant.
	* Note: This class deliberately has a natural ordering that is inconsistent with equals. */
public class VectorFloat implements java.io.Serializable, Cloneable, Comparable <VectorFloat>
{
	/** Radius, in pixels. */
	public float r;

	/** Angle anticlockwise from 0x, in radians. */
	public float theta;

	/** Get the x component of this vector (convert from polar to Cartesian coordinates). */
  public float getDx ()
  {
  	return (float) Math.sin (theta) * r;
  } // getDx

	/** Get the y component of this vector (convert from polar to Cartesian coordinates). */
  public float getDy ()
  {
  	return (float) Math.cos (theta) * r;
  } // getDy

	/** Radius tolerance for comparisons, in pixels. */
	public static float getRadiusTolerance () { return radiusTolerance; }
	public static void setRadiusTolerance (float value) { radiusTolerance = value; }
	private static final float DEFAULT_RADIUS_TOLERANCE = 10.0F; // 10.1.15: was 5.0
  private static float radiusTolerance = DEFAULT_RADIUS_TOLERANCE;

	/** Angle tolerance for comparisons, in radians. */
	public static float getAngleTolerance () { return angleTolerance; }
	public static void setAngleTolerance (float value) { angleTolerance = value; }
	private static final float DEFAULT_ANGLE_TOLERANCE = 0.2F; // 10.1.15: was 0.1
	private static float angleTolerance = DEFAULT_ANGLE_TOLERANCE;

	public static void resetDefaultTolerances ()
	{
		radiusTolerance = DEFAULT_RADIUS_TOLERANCE;
		angleTolerance = DEFAULT_ANGLE_TOLERANCE;
	} // resetDefaultTolerances

	/** Construct from polar coordinates. */
	public VectorFloat (float aRadiusPixels, float anAngleRadians)
	{
		r = aRadiusPixels;
		theta = anAngleRadians;
	} // VectorFloat

	/** Construct from two points (each in Cartesian coordinates). */
	public VectorFloat (net.grelf.PointFloat pt1, net.grelf.PointFloat pt2)
	{
		float dx = pt2.x - pt1.x;
		float dy = pt2.y - pt1.y;
		r = (float) Math.sqrt (dx * dx + dy * dy);
		theta = (float) Math.atan2 (dy, dx);
	} // VectorFloat

	/** Test for equality within the radius and angle tolerances. */
	@Override
	public boolean equals (Object other)
	{
		return (other != null
		        && other.getClass ().equals (this.getClass ())
		        && Math.abs (((VectorFloat) other).r - r) < radiusTolerance
		        && Math.abs (((VectorFloat) other).theta - theta) < angleTolerance);
	} // equals

	@Override
	public int hashCode ()
	{
		int hash = 3;
		hash = 29 * hash + Float.floatToIntBits (this.r);
		hash = 13 * hash + Float.floatToIntBits (this.theta);
		return hash;
	} // hashCode

	/** For sorting only on angle, theta. Implements java.lang.Comparable. */
	@Override
	public int compareTo (VectorFloat other)
	{
    double thetaDegs = Maths.toDegrees (theta);
    double otherDegs = Maths.toDegrees (((VectorFloat) other).theta);
    double diff = Maths.angleDifference (thetaDegs, otherDegs);

    if (diff < 0) return -1;
    if (diff > 0) return 1;
/*
    if (theta < ((VectorFloat) other).theta) return -1;

		if (theta > ((VectorFloat) other).theta) return 1;
*/
		return 0;
	} // compareTo

	/** Get a String representation of the VectorFloat */
	@Override
	public String toString ()
	{
		return "VectorFloat: r = " + r + " px, theta = " + (180.0 * theta / Math.PI) + " degrees";
	} // toString

  @Override
  public VectorFloat clone ()
  {
    return new VectorFloat (this.r, this.theta);
  } // clone

} // VectorFloat